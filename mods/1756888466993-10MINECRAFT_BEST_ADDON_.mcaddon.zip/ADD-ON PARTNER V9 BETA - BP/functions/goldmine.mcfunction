execute @s ~~~ detect ~~-1~ coal_ore 0 setblock ~~-1~ air 0 destroy

execute @s ~~~ detect ~~-1~ iron_ore 0 setblock ~~-1~ air 0 destroy

execute @s ~~~ detect ~~-1~ gold_ore 0 setblock ~~-1~ air 0 destroy

execute @s ~~~ detect ~~-1~ diamond_ore 0 setblock ~~-1~ air 0 destroy

execute @s ~~~ detect ~~-1~ emerald_ore 0 setblock ~~-1~ air 0 destroy

execute @s ~~~ detect ~~-1~ lapis_ore 0 setblock ~~-1~ air 0 destroy

execute @s ~~~ detect ~~-1~ redstone_ore 0 setblock ~~-1~ air 0 destroy

execute @s ~~~ detect ~~-1~ quartz_ore 0 setblock ~~-1~ air 0 destroy

execute @s ~~~ detect ~~-1~ nether_gold_ore 0 setblock ~~-1~ air 0 destroy

execute @s ~~~ detect ~~2~ coal_ore 0 setblock ~~2~ air 0 destroy

execute @s ~~~ detect ~~2~ iron_ore 0 setblock ~~2~ air 0 destroy

execute @s ~~~ detect ~~2~ gold_ore 0 setblock ~~2~ air 0 destroy

execute @s ~~~ detect ~~2~ diamond_ore 0 setblock ~~2~ air 0 destroy

execute @s ~~~ detect ~~2~ emerald_ore 0 setblock ~~2~ air 0 destroy

execute @s ~~~ detect ~~2~ lapis_ore 0 setblock ~~2~ air 0 destroy

execute @s ~~~ detect ~~2~ redstone_ore 0 setblock ~~2~ air 0 destroy

execute @s ~~~ detect ~~2~ quartz_ore 0 setblock ~~2~ air 0 destroy

execute @s ~~~ detect ~~2~ nether_gold_ore 0 setblock ~~2~ air 0 destroy

execute @s ~~~ detect ~~3~ coal_ore 0 setblock ~~3~ air 0 destroy

execute @s ~~~ detect ~~3~ iron_ore 0 setblock ~~3~ air 0 destroy

execute @s ~~~ detect ~~3~ gold_ore 0 setblock ~~3~ air 0 destroy

execute @s ~~~ detect ~~3~ diamond_ore 0 setblock ~~3~ air 0 destroy

execute @s ~~~ detect ~~3~ emerald_ore 0 setblock ~~3~ air 0 destroy

execute @s ~~~ detect ~~3~ lapis_ore 0 setblock ~~3~ air 0 destroy

execute @s ~~~ detect ~~3~ redstone_ore 0 setblock ~~3~ air 0 destroy

execute @s ~~~ detect ~~3~ quartz_ore 0 setblock ~~3~ air 0 destroy

execute @s ~~~ detect ~~3~ nether_gold_ore 0 setblock ~~3~ air 0 destroy

execute @s ~~~ detect ~~~ lava 0 setblock ~~1~ water 0 replace

execute @s ~~~ detect ~~~ water 0 setblock ~~~ air 0 replace