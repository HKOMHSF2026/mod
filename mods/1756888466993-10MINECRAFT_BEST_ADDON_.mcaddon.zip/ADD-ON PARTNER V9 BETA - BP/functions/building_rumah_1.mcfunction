fill ~1 ~ ~1 ~5 ~3 ~5 cobblestone 0 outline
fill ~2 ~ ~2 ~4 ~ ~4 planks
fill ~ ~4 ~ ~6 ~4 ~6 planks
fill ~1 ~5 ~1 ~5 ~5 ~5 planks
fill ~2 ~6 ~2 ~4 ~6 ~4 planks
fill ~2 ~1 ~2 ~4 ~4 ~4 air
setblock ~3 ~5 ~3 air
fill ~ ~4 ~ ~ ~4 ~6 oak_stairs
fill ~ ~4 ~ ~6 ~4 ~ oak_stairs 2
fill ~6 ~4 ~ ~6 ~4 ~6 oak_stairs 1
fill ~ ~4 ~6 ~6 ~4 ~6 oak_stairs 3
fill ~1 ~5 ~1 ~1 ~5 ~5 oak_stairs
fill ~1 ~5 ~1 ~5 ~5 ~1 oak_stairs 2
fill ~5 ~5 ~1 ~5 ~5 ~5 oak_stairs 1
fill ~1 ~5 ~5 ~5 ~5 ~5 oak_stairs 3
fill ~2 ~6 ~2 ~2 ~6 ~4 oak_stairs
fill ~2 ~6 ~2 ~4 ~6 ~2 oak_stairs 2
fill ~4 ~6 ~2 ~4 ~6 ~4 oak_stairs 1
fill ~2 ~6 ~4 ~4 ~6 ~4 oak_stairs 3
fill ~1 ~ ~1 ~1 ~3 ~1 stripped_oak_log
fill ~5 ~ ~1 ~5 ~3 ~1 stripped_oak_log
fill ~1 ~ ~5 ~1 ~3 ~5 stripped_oak_log
fill ~5 ~ ~5 ~5 ~3 ~5 stripped_oak_log
setblock ~3 ~2 ~1 glass_pane
setblock ~5 ~2 ~3 glass_pane
setblock ~3 ~2 ~5 glass_pane
setblock ~1 ~1 ~3 wooden_door
setblock ~ ~ ~3 oak_stairs
setblock ~4 ~1 ~4 oak_stairs