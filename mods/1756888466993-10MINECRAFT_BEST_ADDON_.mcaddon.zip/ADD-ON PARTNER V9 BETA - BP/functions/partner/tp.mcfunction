execute @e[type=aerell:partner_cewe] ~~~ tp @p
execute @e[type=aerell:partner_cowo] ~~~ tp @p
execute @e[type=aerell:partner_cewe_mati] ~~~ tp @p
execute @e[type=aerell:partner_cowo_mati] ~~~ tp @p