kill @e[type=aerell:partner_cewe_mati]
kill @e[type=aerell:partner_cowo_mati]