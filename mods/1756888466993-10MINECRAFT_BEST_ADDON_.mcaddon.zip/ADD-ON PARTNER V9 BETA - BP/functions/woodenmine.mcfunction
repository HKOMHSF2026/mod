execute @s ~~~ detect ~~-1~ coal_ore 0 setblock ~~-1~ air 0 destroy

execute @s ~~~ detect ~~2~ coal_ore 0 setblock ~~2~ air 0 destroy

execute @s ~~~ detect ~~3~ coal_ore 0 setblock ~~3~ air 0 destroy

execute @s ~~~ detect ~~~ lava 0 setblock ~~1~ water 0 replace

execute @s ~~~ detect ~~~ water 0 setblock ~~~ air 0 replace