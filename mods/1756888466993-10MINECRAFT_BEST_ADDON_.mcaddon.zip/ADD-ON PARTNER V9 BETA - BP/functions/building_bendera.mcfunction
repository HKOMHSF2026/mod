fill ~~~ ~~8~ fence
fill ~1~8~ ~3~8~ wool 14
fill ~1~7~ ~3~7~ wool