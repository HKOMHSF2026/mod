fill ~ ~ ~ ~6 ~ ~8 log
fill ~1 ~ ~1 ~5 ~ ~7 farmland 1
fill ~3 ~ ~1 ~3 ~ ~7 water