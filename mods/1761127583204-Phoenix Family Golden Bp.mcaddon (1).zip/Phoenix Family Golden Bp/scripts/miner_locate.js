import { world } from '@minecraft/server';

export function searchNearbyBlocks(player, entity) {
    const location = entity.location;

    const minY = -59; // Altura mínima válida del mundo en bloques
    const maxY = 320; // Altura máxima válida del mundo en bloques
    const radius = 6;
    const mineralTypes = ['gold_ore', 'iron_ore', 'emerald_ore', 'diamond_ore', 'ancient_debris', 'redstone_ore', 'copper_ore', 'lapis_ore'];

    // Crear un objeto para almacenar la ubicación más cercana de cada mineral
    let closestLocations = {
        gold: null,
        iron: null,
        emerald: null,
        diamond: null,
        ancient_debris: null,
        redstone: null,
        copper: null,
        lapis: null
    };

    // Crear un bucle para buscar en un área alrededor de la entidad
    for (let xOffset = -radius; xOffset <= radius; xOffset++) {
        for (let yOffset = -radius; yOffset <= radius; yOffset++) {
            for (let zOffset = -radius; zOffset <= radius; zOffset++) {
                // Obtener las coordenadas del bloque dentro del radio de búsqueda
                const blockLocation = {
                    x: Math.round(location.x) + xOffset,
                    y: Math.round(location.y) + yOffset,
                    z: Math.round(location.z) + zOffset
                };

                // Verificar si la coordenada y está dentro de los límites válidos del mundo
                if (isValidYCoordinate(blockLocation.y, minY, maxY)) {
                    const block = world.getDimension(entity.dimension.id).getBlock(blockLocation).typeId;

                    // Verificar si el tipo de bloque es uno de los minerales buscados
                    mineralTypes.forEach(mineral => {
                        if (block.endsWith(mineral)) {
                            // Calcular la distancia entre el jugador y el bloque
                            const distance = Math.sqrt(
                                Math.pow(location.x - blockLocation.x, 2) +
                                Math.pow(location.y - blockLocation.y, 2) +
                                Math.pow(location.z - blockLocation.z, 2)
                            );

                            // Actualizar la ubicación más cercana si es la primera vez o si es más cercana que la anterior
                            if (!closestLocations[mineral.replace('_ore', '')] || distance < closestLocations[mineral.replace('_ore', '')].distance) {
                                closestLocations[mineral.replace('_ore', '')] = {
                                    location: blockLocation,
                                    distance: distance
                                };
                            }
                        }
                    });
                }
            }
        }
    }

    // Enviar los mensajes al jugador
    let foundMinerals = false; // Variable para rastrear si se encontraron minerales
    Object.keys(closestLocations).forEach(mineral => {
        if (closestLocations[mineral]) {
            foundMinerals = true;
            const closestLocation = closestLocations[mineral].location;
            entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "entity.minerals.search.${mineral}"}]}`);
            if (entity.hasTag('premiumMinerWork')) {
                entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"text": "(${closestLocation.x}, ${closestLocation.y}, ${closestLocation.z})"}]}`);
            }
        }
    });
    if (foundMinerals) {
        player.playSound('mob.villager.minerals_found');
        entity.removeTag('premiumMinerWork');
    }
    // Si no se encontraron minerales, enviar un mensaje indicándolo
    if (!foundMinerals) {
        player.playSound('mob.villager.minerals_not_found');
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "player.message.no.minerals"}]}`);
    }
}

// Función para verificar si la coordenada y está dentro de los límites válidos del mundo
function isValidYCoordinate(y, minY, maxY) {
    return y >= minY && y <= maxY;
}
