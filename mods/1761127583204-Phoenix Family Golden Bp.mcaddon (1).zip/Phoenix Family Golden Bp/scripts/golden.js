import { world, system, ItemStack, ItemLockMode, EntityComponentTypes } from '@minecraft/server';
import { ModalFormData, ActionFormData } from '@minecraft/server-ui';
import { actionInteractUi, actionInteractUiParent, actionInteractPlayerUi } from "./interact";
import { specialUi, specialUiBeforeGettingMarried, cancelMarriageProposalUi, growBaby, entityMinerWork, specialUiParent, workFletcher } from "./especial_actions";
import { assignRandomPhysicalTrait, assignRandomPhobia, assignRandomEmotionalTrait, reassignPhobia } from "./assign_personality";
import { generateRandomMaleName, generateRandomFemaleName } from "./assign_name";

let civilStatus = 's';
let titleWorking = 'farmer';
let humanNature = 'adopt';
let spawnedAdditionalVillager = false;
const clonedItems = {};
const babyToys = ['pf:pacifier', 'pf:feeding_bottle'];

world.afterEvents.dataDrivenEntityTrigger.subscribe(data => {
    const entity = data.entity;
    const event = data.eventId;
    if (!entity || !entity.id) return;
    if (entity.typeId === 'phoenix:cooldown_librarian' && event === 'ready') {
        const entityId = entity.id;
        const playersWithTag = entity.dimension.getPlayers({
            tags: [`cooldown_librarian${entityId}`],
            location: entity.location
        });

        if (playersWithTag.length > 0) {
            playersWithTag.forEach(player => {
                if (entity.typeId.includes('cooldown_librarian') && event === 'ready') {
                    librarianCloneBook(entity, player);
                }
            });
        }
    } else if (entity.typeId === 'pf:humanoid' && event === 'remove_work_librarian_cooldown') {
        const playersWithTag2 = entity.dimension.getPlayers();
        playersWithTag2.forEach(player => {
            const tags2 = player.getTags();
            tags2.forEach(gtags => {
                if (gtags.startsWith('cooldown_librarian')) {
                    player.removeTag(gtags);
                    const entityWithTags2 = world.getDimension(entity.dimension.id).getEntities({
                        tags: [`cooldown_librarian${player.id}`],
                        location: player.location
                    });
                    if (entityWithTags2.length > 0) {
                        entityWithTags2.forEach(gEntitys => {
                            gEntitys.triggerEvent('remove');
                        });
                    }
                }
            });
        });

    } else if (entity.typeId === 'pf:humanoid' && event === 'minecraft:entity_born') {
        entity.addTag('createdBySocialization');
        if (!entity.hasTag(`active_physical_trait`)) {
            assignRandomPhysicalTrait(entity);
            if (!entity.hasTag(`active_emotional_trait`)) {
                assignRandomEmotionalTrait(entity);
                if (!entity.hasTag(`active_phobia`)) {
                    assignRandomPhobia(entity);
                }
            }
        }
        const skinIdComponent = entity.getComponent("minecraft:skin_id");
        const skinIdValue = skinIdComponent.value;
        // Verificar si el skin_id es impar
        if (skinIdValue % 2 !== 0) {
            const femaleName = generateRandomFemaleName();
            entity.nameTag = femaleName;
        } else {
            const randomName = generateRandomMaleName();
            entity.nameTag = randomName;
        }
    } else if (entity.typeId === 'pf:humanoid' && (event === 'armorable_remove' || event === 'trading_remove')) {
        entity.runCommand(`playsound mob.villager.close_interactions @a[r=4] ~~~`);
    } else if (entity.typeId === 'pf:humanoid' && (event === 'tamed')) {
        const tags = entity.getTags();
        const marriedTag = tags.find(tag => tag.startsWith('married_'));
        if (marriedTag) {
            const playerName = marriedTag.replace('married_', '');
            const player = world.getAllPlayers().find(p => p.name === playerName);
            if (player) {
                player.addTag('pf:married');
            }
        }
    }
});
world.afterEvents.entityDie.subscribe(data => {
    try {
        const entity = data.deadEntity;
        const playersWithTag2 = entity.dimension.getPlayers();
        playersWithTag2.forEach(player => {
            const tags2 = player.getTags();
            tags2.forEach(gtags => {
                if (gtags.startsWith('cooldown_librarian')) {
                    player.removeTag(gtags);
                    const entityWithTags2 = world.getDimension(entity.dimension.id).getEntities({
                        tags: [`cooldown_librarian${player.id}`],
                        location: player.location
                    });
                    if (entityWithTags2.length > 0) {
                        entityWithTags2.forEach(gEntitys => {
                            gEntitys.triggerEvent('remove');
                        });
                    }
                }
            });
        });
        if (entity.typeId === "pf:humanoid") {
            const tags = entity.getTags();
            const marriedTag = tags.find(tag => tag.startsWith('married_'));
            if (marriedTag) {
                const playerName = marriedTag.replace('married_', '');
                const player = world.getAllPlayers().find(p => p.name === playerName);
                if (player) {
                    player.removeTag('pf:married');
                }
            }
        }
    } catch { }
});
world.afterEvents.itemUse.subscribe(data => {
    const { source: player, itemStack: item } = data;
    player.runCommand(`scoreboard objectives add timeGrow dummy`);
    player.runCommand(`scoreboard players add @s timeGrow 0`);
    const hasInventory = player.hasComponent("minecraft:inventory");
    if (item.typeId == 'pf:call_family' && hasInventory) {
        player.playSound('mob.villager.call');
        callFamiliar(player);
    } else if (player.hasTag(`pregnant`) && hasInventory) {
        const inventory = player.getComponent("minecraft:inventory");
        const heldItem = inventory.container.getItem(0);
        if (heldItem) {
            if (item.typeId == babyToys[1] && (heldItem.typeId == 'pf:baby_boy_crying' || heldItem.typeId == 'pf:baby_girl_crying')) {
                if (player.getGameMode() == "survival") {
                    player.runCommand(`clear @s ${babyToys[1]} -1 1`);
                }
                player.playSound('mob.villager.feeding_bottle');
                let timeGrow = world.scoreboard.getObjective('timeGrow').getScore(player) || 0;
                let newItem = heldItem.typeId.includes('girl') ? 'pf:baby_girl' : 'pf:baby_boy';
                const newItemStack = new ItemStack(newItem, 1);
                newItemStack.lockMode = ItemLockMode.slot;
                newItemStack.keepOnDeath = true;
                newItemStack.setLore([
                    'time to grow: ',
                    `${timeGrow}%`,
                    'Emotion: Happy'
                ]);
                inventory.container.setItem(0, newItemStack)
            } else if (item.typeId == babyToys[0] && (heldItem.typeId == 'pf:baby_girl_angry' || heldItem.typeId == 'pf:baby_boy_angry')) {
                if (player.getGameMode() == "survival") {
                    player.runCommand(`clear @s ${babyToys[0]} -1 1`);
                }
                player.playSound('mob.villager.pacifier');
                let timeGrow = world.scoreboard.getObjective('timeGrow').getScore(player) || 0;
                let newItem = heldItem.typeId.includes('girl') ? 'pf:baby_girl' : 'pf:baby_boy';
                const newItemStack = new ItemStack(newItem, 1);
                newItemStack.lockMode = ItemLockMode.slot;
                newItemStack.keepOnDeath = true;
                newItemStack.setLore([
                    'time to grow: ',
                    `${timeGrow}%`,
                    'Emotion: Happy'
                ]);
                inventory.container.setItem(0, newItemStack)
            }
        }
    }
    if (item.typeId === 'minecraft:bell' && item.nameTag === 'devDhark') {
        player.runCommand('say hola dharkcraft');
        if (player.hasTag('pregnant')) {
            growBaby(player);
        }
        const entities = player.dimension.getEntities({ tags: ["work_miner"] });
        if (entities.length > 0) {
            entities.forEach(entity => {
                entityMinerWork(player, entity);
            });
        }
        const entitiesFollow = player.dimension.getEntities({ tags: [`"follow_${player.name}"`] });
        if (entitiesFollow.length > 0) {
            entitiesFollow.forEach(entitys => {
                followMe(entitys, player);
            });
        }
    }
});
world.beforeEvents.itemUseOn.subscribe(async data => {
    const { source: player, itemStack: item, block } = data;
    player.runCommandAsync(`scoreboard objectives add timeGrow dummy`);
    player.runCommandAsync(`scoreboard players add @s timeGrow 0`);
    system.runTimeout(() => {
        let timeGrow = world.scoreboard.getObjective('timeGrow').getScore(player);
        if (item.typeId == 'pf:baby_boy' && timeGrow >= 101) {
            player.playSound('mob.villager.baby_place');
            player.runCommandAsync(`summon pf:humanoid ${block.location.x} ${block.location.y + 1} ${block.location.z} facing @s minecraft:entity_baby_spawned_boy`);
            player.runCommandAsync(`clear @s pf:baby_boy -1 1`);
            player.runCommandAsync(`tag @s remove pregnant`);
            player.runCommandAsync(`scoreboard players set @s timeGrow 0`);
        } else if (item.typeId == 'pf:baby_girl' && timeGrow >= 101) {
            player.playSound('mob.villager.baby_place');
            player.runCommandAsync(`summon pf:humanoid ${block.location.x} ${block.location.y + 1} ${block.location.z} facing @s minecraft:entity_baby_spawned_girl`);
            player.runCommandAsync(`clear @s pf:baby_girl -1 1`);
            player.runCommandAsync(`tag @s remove pregnant`);
            player.runCommandAsync(`scoreboard players set @s timeGrow 0`);
        }
    }, 8);
});
world.afterEvents.playerSpawn.subscribe(data => {
    const player = data.player;
    if (player.hasTag('pregnant')) {
        growBaby(player);
    }
    const entities = player.dimension.getEntities({ tags: ["work_miner"] });
    if (entities.length > 0) {
        entities.forEach(entity => {
            entityMinerWork(player, entity);
        });
    }
    const entitieslibrarian = player.dimension.getEntities({ tags: [`cooldown_librarian${player.id}`] });
    if (entitieslibrarian.length > 0) {
        entitieslibrarian.forEach(entity => {
            player.removeTag(`cooldown_librarian${entity.id}`);
            player.removeTag(`cooldown_librarian_bookCreate`);
            entity.triggerEvent('remove');
        });
    }
    const entitiesFollow = player.dimension.getEntities({ tags: [`"follow_${player.name}"`] });
    if (entitiesFollow.length > 0) {
        entitiesFollow.forEach(entitys => {
            followMe(entitys, player);
        });
    }
});
world.afterEvents.entitySpawn.subscribe(data => {
    const entity = data.entity;
    const baby = entity.getComponent('minecraft:is_baby');
    const cause = data.cause;
    if (entity.typeId == 'pf:humanoid' && !baby) {
        if (!entity.hasTag(`active_physical_trait`)) {
            assignRandomPhysicalTrait(entity);
            if (!entity.hasTag(`active_emotional_trait`)) {
                assignRandomEmotionalTrait(entity);
                if (!entity.hasTag(`active_phobia`)) {
                    assignRandomPhobia(entity);
                }
            }
        }
        const skinIdComponent = entity.getComponent("minecraft:skin_id");
        const skinIdValue = skinIdComponent.value;
        // Verificar si el skin_id es impar
        if (skinIdValue % 2 !== 0) {
            const femaleName = generateRandomFemaleName();
            entity.nameTag = femaleName;
        } else {
            const randomName = generateRandomMaleName();
            entity.nameTag = randomName;
        }
    }
});

world.afterEvents.playerInteractWithEntity.subscribe(data => {
    const { target: entity, itemStack: item, player } = data;
    let levelLove = '';

    if (entity.typeId === 'pf:humanoid') {
        if (item && item.typeId === 'pf:civil_certificate' && player.hasTag(`parent${entity.id}`)) {
            setParent(player, entity);
            return;
        }
        if (entity.hasTag('work_miner') && !entity.hasTag('premiumMinerWork') && !player.isSneaking) {
            if (item && item.typeId === 'minecraft:emerald') {
                premiumMinerWork(player, entity);
            } else {
                entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "action.caution.premiumminer"}]}`);
            }
            return;
        }
        const baby = entity.getComponent('minecraft:is_baby');
        if ((baby && !entity.hasTag(`createdBySocialization`)) && !entity.hasTag('nameBabySet')) {
            setNameBaby(player, entity);
        }
        const heal = ['porkchop', 'cooked_porkchop', 'fish', 'salmon', 'cooked_fish', 'cooked_salmon', 'beef', 'cooked_beef', 'chicken', 'cooked_chicken', 'muttonRaw', 'muttonCooked', 'rabbit', 'cooked_rabbit', 'rabbit_stew', 'mushroom_stew', 'bread', 'beetroot_soup', 'beetroot', 'baked_potato', 'carrot', 'potato', 'golden_apple', 'enchanted_golden_apple', 'golden_carrot', 'pumpkin_pie', 'cake', 'cookie', 'sweet_berries', 'dried_kelp', 'honey_bottle', 'melon_slice', 'glow_berries'];
        if (!player.hasTag('male') && !player.hasTag('female') && !player.hasTag('other')) {
            playergender(player);
        } else {
            const playerName = player.name;
            const playerHeartsScore = `"PF_${playerName}_hearts"`;
            const playerHeartsScore2 = `PF_${playerName}_hearts`;
            player.runCommand(`scoreboard objectives add ${playerHeartsScore} dummy`);
            entity.runCommand(`scoreboard players add @s ${playerHeartsScore} 0`);
            entity.runCommand(`execute as @s[scores={${playerHeartsScore}=101..}] run scoreboard players set @s ${playerHeartsScore} 100`);
            entity.runCommand(`execute as @s[scores={${playerHeartsScore}=-999..-1}] run scoreboard players set @s ${playerHeartsScore} 0`);

            const score = world.scoreboard.getObjective(playerHeartsScore2).getScore(entity);
            levelLove = score !== undefined ? score : '';

            civilStatus = entity.hasComponent('is_tamed') ? 'm' : 's';
            hasFamilyWorking(entity);

            const hasVariantComponent = entity.hasComponent('minecraft:variant');
            if (hasVariantComponent) {

                const variantComponent = entity.getComponent('minecraft:variant');
                const variantValue = variantComponent.value;

                const markVariantComponent = entity.getComponent('minecraft:mark_variant');
                const markVariantValue = markVariantComponent.value;

                if (variantValue === 15) {
                    entity.removeTag('trading');
                    entity.triggerEvent('variant_0');
                }
                if (markVariantValue === 15) {
                    const familyComponent = entity.getComponent('minecraft:type_family');
                    const family = familyComponent.getTypeFamilies();
                    const inventoryComponent = entity.getComponent('minecraft:inventory');
                    const invSize = inventoryComponent.container.size;
                    if (family.includes('farmer')) {
                        let isEmpty = true;
                        for (let i = 0; i < invSize; i++) {
                            const inventoryContainer = inventoryComponent.container.getItem(i);
                            if (inventoryContainer) {
                                isEmpty = false;
                            }
                            if (i === 26) {
                                emptyInventory(player, entity, isEmpty);
                            }
                        }
                    } else if (family.includes('fletcher')) {
                        let isEmpty = true;
                        for (let i = 0; i < invSize; i++) {
                            const inventoryContainer = inventoryComponent.container.getItem(i);
                            if (inventoryContainer) {
                                isEmpty = false;
                            }
                            if (i === 26) {
                                emptyInventoryFletcher(player, entity, isEmpty);
                            }
                        }
                    } else if (family.includes("stone_miner")) {
                        player.playSound('mob.villager.close_interactions');
                        entity.triggerEvent('remove_work_miner');
                        entity.removeTag(`work_miner`);
                        entity.removeTag('working');
                    } else if (family.includes("librarian")) {
                        player.playSound('mob.villager.close_interactions');
                        entity.triggerEvent('remove_work_librarian');
                        entity.removeTag(`work_librarian`);
                        entity.removeTag('working');
                    } else if (family.includes("cleric")) {
                        player.playSound('mob.villager.close_interactions');
                        entity.triggerEvent('remove_work_cleric');
                        entity.removeTag(`work_cleric`);
                        entity.removeTag('working');
                    }
                }
            } else {
                entity.triggerEvent('nowork');
            }
            if (entity.hasTag('guardian')) {
                if (item) {
                    const isHeal = heal.some(healItem => item.typeId.includes(healItem));
                    if (!isHeal) {
                        exitGuardianUi(player, entity, levelLove);
                    }
                } else {
                    exitGuardianUi(player, entity, levelLove);
                }
            } else if (entity.hasTag('work_librarian')) {
                if (item && item.typeId.includes('enchanted_book') && !player.hasTag(`cooldown_librarian_bookCreate`)) {
                    player.runCommandAsync('testfor @s[lm=10]').then(xpLevelResult => {
                        if (xpLevelResult.successCount === 1) {
                            const dimension = player.dimension;
                            const cloneItem = item.clone();
                            const playerId = player.id;
                            player.playSound('mob.villager.give_book');
                            player.runCommand('xp -10l @s');
                            entity.runCommand(`ride @s summon_rider phoenix:cooldown_librarian`);
                            entity.runCommand(`playsound mob.villager.writing_book @a[r=4] ~~~`);
                            const entityCooldown = world.getDimension(dimension.id).getEntities({
                                type: 'phoenix:cooldown_librarian',
                                location: entity.location,
                                minDistance: 0,
                                maxDistance: 2
                            });
                            entityCooldown.forEach(entityLib => {
                                const entityId = entityLib.id;
                                clonedItems[entityId] = cloneItem;
                                player.addTag(`cooldown_librarian${entityId}`);
                                player.addTag(`cooldown_librarian_bookCreate`);
                                entityLib.addTag(`cooldown_librarian${playerId}`);
                            });
                        } else {
                            player.playSound('mob.villager.fail');
                            entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "action.noCloneBook.level"}]}`);
                        }
                    })
                } else if (player.hasTag(`cooldown_librarian_bookCreate`)) {
                    entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "action.noCloneBook.haveBook"}]}`);
                } else {
                    entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "action.noCloneBook.booknt"}]}`);
                }
            } else if (entity.hasTag('work_cleric')) {
                if (item && item.typeId === 'minecraft:rotten_flesh') {
                    if (player.getGameMode() == "survival") {
                        player.runCommand(`clear @s rotten_flesh -1 1`);
                    }
                    entity.dimension.spawnItem(new ItemStack("pf:fresh_flesh", 1), entity.location);
                } else {
                    entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "message.rotten_flesh.warning"}]}`);
                }
            } else if (entity.hasTag('socialize')) {
                if (item) {
                    if (item.typeId !== 'pf:love_potion') {
                        exitSocializeUi(player, entity, levelLove);
                    }
                } else {
                    exitSocializeUi(player, entity, levelLove);
                }
            }
            if (entity.hasTag('armorable')) {
                const equipmentCompPlayer = player.getComponent(EntityComponentTypes.Equippable);
                const heldItem = equipmentCompPlayer.getEquipment("Mainhand");
                const itemHeldProperty = entity.getProperty("pf:helditem");
                if (itemHeldProperty) {
                    entity.setProperty("pf:helditem", false);
                } else if (
                    heldItem &&
                    !(
                        heldItem.typeId.endsWith("helmet") ||
                        heldItem.typeId.endsWith("chestplate") ||
                        heldItem.typeId.endsWith("leggings") ||
                        heldItem.typeId.endsWith("boots")
                    )
                ) {
                    entity.setProperty("pf:helditem", true);
                }
            }

            if (entity.hasTag('trading') || entity.hasTag('socialize') || entity.hasTag('working') || entity.hasTag('guardian') || entity.hasTag('armorable')) return;

            if (!item || (item.typeId !== 'pf:wedding_ring' && item.typeId !== 'minecraft:name_tag' && item.typeId !== 'pf:feeding_bottle')) {
                if (entity.hasComponent('minecraft:tameable')) {
                    cancelMarriageProposalUi(player, entity);
                } else if (entity.hasTag('active_physical_trait') && entity.hasTag('active_emotional_trait') && entity.hasTag('active_phobia')) {
                    actionUi(player, entity, levelLove);
                }
            }
        }
    }
});

function premiumMinerWork(player, entity) {
    player.runCommandAsync(`testfor @s[hasitem={item=emerald,quantity=8..}]`)
        .then(premiumResult => {
            if (premiumResult.successCount === 1) {
                player.playSound('mob.villager.premium_miner');
                if (player.getGameMode() == "survival") {
                    player.runCommandAsync(`clear @s emerald -1 8`);
                }
                entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "message.thankyou.minerpremiuns"}]}`);
                entity.addTag('premiumMinerWork');
            }
        })
}
function setNameBaby(player, entity) {
    let setName = new ModalFormData()
        .textField({ translate: 'modal.name.textField' }, { translate: 'modal.setname.textField' })
        .show(player)
        .then(r => {
            if (r.canceled) {
                setNameBaby(player, entity);
                return;
            }
            let textField = r.formValues[0];
            if (textField.trim() === '') {
                setNameBaby(player, entity);
                return;
            }
            entity.addTag('nameBabySet');
            entity.addTag(`parent${player.name}`);
            entity.triggerEvent('baby');
            entity.triggerEvent('move');
            entity.nameTag = textField;
            player.addTag(`parent${entity.id}`);
            if (!entity.hasTag(`active_physical_trait`)) {
                assignRandomPhysicalTrait(entity);
                if (!entity.hasTag(`active_emotional_trait`)) {
                    assignRandomEmotionalTrait(entity);
                    if (!entity.hasTag(`active_phobia`)) {
                        assignRandomPhobia(entity);
                    }
                }
            }
        });
}
function setParent(player, entity) {
    let wp = world.getAllPlayers();
    let playerNames = wp.map(player => player.name);
    let setParent = new ModalFormData()
        .dropdown({ translate: 'modal.players.dropdown' }, playerNames)
        .toggle({ translate: 'modal.parents.toggle' }, true)
        .show(player)
        .then(r => {
            if (r.canceled) return;
            let selectedPlayerName = playerNames[r.formValues[0]];
            let addParent = r.formValues[1];
            if (addParent) {
                entity.addTag(`"parent${selectedPlayerName}"`);
                player.runCommand(`tag @a[name="${selectedPlayerName}"] add relative${entity.id}`);
            } else {
                entity.removeTag(`"parent${selectedPlayerName}"`);
                player.runCommand(`tag @a[name="${selectedPlayerName}"] remove relative${entity.id}`);
            }
        })
}
function callFamiliar(player) {
    let dimension = player.dimension;
    let entities = dimension.getEntities();
    let entityNames = [];

    entities = entities.filter(entity => entity !== player && (entity.hasTag(`parent${player.name}`) || entity.hasTag(`married_${player.name}`)));
    if (entities.length === 0) return;

    for (let entity of entities) {
        if (entity.nameTag) { // Verificar si el nombre de la entidad está definido
            entityNames.push(String(entity.nameTag)); // Convertir el nombre de la entidad a una cadena y agregarlo al array
        }
    }
    let callfamiliar = new ModalFormData()
        .dropdown({ translate: 'modal.entityFamiliar.dropdown' }, entityNames)
        .toggle({ translate: 'modal.call.toggle' }, true)
        .show(player)
        .then(r => {
            if (r.canceled) return;
            let selectedEntityName = entityNames[r.formValues[0]];
            let call = r.formValues[1];
            const playerRotation = player.getRotation();
            let zOffset = 0;
            let xOffset = 0;
            // Aproximar la rotación a una de las cuatro rotaciones deseadas
            const roundedRotation = Math.round(playerRotation.y / 90) * 90;
            switch (roundedRotation) {
                case 0:
                    zOffset = 1.5;
                    xOffset = +0;
                    break;
                case 90:
                    zOffset = +0;
                    xOffset = -1.5;
                    break;
                case -90:
                    zOffset = +0;
                    xOffset = +1.5;
                    break;
                case -180:
                    zOffset = -1.5;
                    xOffset = +0;
                    break;
            }
            if (call) {
                player.playSound('mob.villager.teleport');
                player.runCommand(`tp @e[type=pf:humanoid,name="${selectedEntityName}",tag="parent${player.name}"] ~${xOffset} ~ ~${zOffset}`);
                player.runCommand(`tp @e[type=pf:humanoid,name="${selectedEntityName}",tag="married_${player.name}"] ~${xOffset} ~ ~${zOffset}`);
            }
        })
}
function playergender(player) {
    const playerJoin = new ActionFormData()
        .body({ translate: 'action.select.gender' })
        .button({ translate: 'action.male.button' })
        .button({ translate: 'action.female.button' })
        .button({ translate: 'action.other.button' })
        .show(player)
        .then(r => {
            if (r.canceled) {
                if (!player.hasTag(`male`) && !player.hasTag(`female`) && !player.hasTag(`other`)) {
                    playergender(player);
                }
            } else {
                let response = r.selection;
                switch (response) {
                    case 0:
                        player.addTag('male');
                        break;
                    case 1:
                        player.addTag('female');
                        break;
                    case 2:
                        player.addTag('other');
                        break;
                }
            }
        });
}
function hasFamilyWorking(entity) {
    const familyComponent = entity.getComponent("minecraft:type_family");
    const family = familyComponent.getTypeFamilies();
    if (family.includes("farmer")) {
        titleWorking = 'farmer';
    } else if (family.includes("stone_miner")) {
        titleWorking = 'miner';
    } else if (family.includes("librarian")) {
        titleWorking = 'librarian';
    } else if (family.includes("cleric")) {
        titleWorking = 'cleric';
    } else if (family.includes("fletcher")) {
        titleWorking = 'fletcher';
    }
}
function librarianCloneBook(entity, player) {
    const entityId = entity.id;
    const clonedItem = clonedItems[entityId];
    player.playSound('mob.villager.finished_book');
    entity.dimension.spawnItem(clonedItem, entity.location);
    player.removeTag(`cooldown_librarian_bookCreate`);
    player.removeTag(`cooldown_librarian${entityId}`);
    entity.runCommand(`event entity @s remove`);
}
function emptyInventory(player, entity, isEmpty) {
    const playerName = player.name;
    if (isEmpty) {
        entity.removeTag('working');
        entity.triggerEvent('remove_work_farmer');
        player.playSound('mob.villager.close_interactions');
    } else {
        entity.runCommand(`tellraw "${playerName}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "action.inventory.hasFarmerItems"}]}`);
        entity.triggerEvent('remove_15_farmer');
    }
}
function emptyInventoryFletcher(player, entity, isEmpty) {
    const temporaryBow = entity.getDynamicProperty("temporaryBow");
    const playerName = player.name;
    if (isEmpty) {
        entity.removeTag('working');
        entity.triggerEvent('remove_work_fletcher');
        player.playSound('mob.villager.close_interactions');
        if (temporaryBow) {
            entity.runCommand(`replaceitem entity @s slot.weapon.mainhand 0 air`)
        }
    } else {
        entity.runCommand(`tellraw "${playerName}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "action.inventory.hasFletcherItems"}]}`);
        entity.triggerEvent('remove_15_fletcher');
    }
}
function exitGuardianUi(player, entity, levelLove) {
    const action = new ActionFormData()
        .title(`${titleWorking}`)
        .body(`${civilStatus}${levelLove}`)
        .button({ translate: 'action.offGuardian.button' })
        .button({ translate: 'action.close.button' })
        .show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    player.playSound('mob.villager.close_interactions');
                    entity.removeTag('guardian');
                    entity.triggerEvent('minecraft:off_attack');
                    reassignPhobia(entity);
                    break;
                case 1:
                    break;
                default:
                    break;
            }
        })
}
function exitSocializeUi(player, entity, levelLove) {
    const action = new ActionFormData()
        .title(`${titleWorking}`)
        .body(`${civilStatus}${levelLove}`)
        .button({ translate: 'action.exitSocializeUi.button' })
        .button({ translate: 'action.close.button' })
        .show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    player.playSound('mob.villager.close_interactions');
                    entity.removeTag('socialize');
                    entity.triggerEvent('remove_socialize');
                    break;
                case 1:
                    break;
                default:
                    break;
            }
        })
}
export function actionUi(player, entity, levelLove) {
    const baby = entity.getComponent('minecraft:is_baby');
    const action = new ActionFormData()
        .title(`${titleWorking}`)
        .body(`${civilStatus}${levelLove}`)
        .button({ translate: 'action.interact.button' })
        .button({ translate: 'action.movement.button' })
        .button({ translate: 'action.trading.button' })
        .button({ translate: 'action.ride_a_mob.button' })
        .button({ translate: 'action.special.button' })
        .button({ translate: 'action.close.button' })
        .show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    if ((player.hasTag(`parent${entity.id}`) || player.hasTag(`relative${entity.id}`))) {
                        actionInteractUiParent(player, entity, levelLove, civilStatus, titleWorking);
                    } else if (!baby) {
                        actionInteractUi(player, entity, levelLove, civilStatus, titleWorking);
                    } else {
                        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "player.menssage.Imbaby"}]}`);
                    }
                    break;
                case 1:
                    actionMovementUi(player, entity, levelLove);
                    break;
                case 2:
                    if (!baby) {
                        player.playSound('mob.villager.trade');
                        entity.addTag(`trading`);
                        entity.triggerEvent('trading');
                    } else {
                        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "player.menssage.Imbaby"}]}`);
                    }
                    break;
                case 3:
                    actioRideMob(player, entity, levelLove);
                    break;
                case 4:
                    if (entity.hasComponent('is_tamed') && entity.hasTag(`married_${player.name}`)) {
                        specialUi(player, entity, levelLove, civilStatus, titleWorking);
                    } else if ((player.hasTag(`relative${entity.id}`) || player.hasTag(`parent${entity.id}`))) {
                        specialUiParent(player, entity, levelLove, civilStatus, titleWorking);
                    } else if (entity.hasComponent('is_tamed') && !entity.hasTag(`married_${player.name}`)) {
                        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "player.menssage.noOwner.specialAccess"}]}`);
                    } else {
                        specialUiBeforeGettingMarried(player, entity, levelLove, civilStatus, titleWorking);
                    }
                    break;
                case 5:
                    break;
                default:
                    break;
            }
        })
}
export function actionMarriedUiPlayer(player, entity, levelLove, item) {
    const inventory = player.getComponent("minecraft:inventory");
    const heldItem = inventory.container.getItem(0);
    if (player.hasTag(`female`) && entity.hasTag(`male`)) {
        humanNature = 'pregnant';
    } else if (entity.hasTag(`female`) && player.hasTag(`male`)) {
        humanNature = 'pregnant';
    } else {
        humanNature = 'adopt';
    }
    const actionPlayer = new ActionFormData()
        .title(`${titleWorking}`)
        .body(`${civilStatus}${levelLove}`)
        .button({ translate: 'action.interact.button' })
        .button({ translate: `action.${humanNature}.button` })
        .button({ translate: 'action.close.button' })
        .show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    actionInteractPlayerUi(player, entity, levelLove, civilStatus, titleWorking);
                    break;
                case 1:
                    if (!heldItem) {
                        player.runCommand(`scoreboard players set @s timeGrow 0`);
                        pregnant(player, heldItem);
                    } else {
                        pregnant(player, heldItem);
                        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@s"}, {"translate": "player.message.noItemPregnant"}]}`);
                    }
                    break;
                case 5:
                    break;
                default:
                    break;
            }
        })
}
function marriedPlayer(player, entity) {
    const jokePlayer = new ActionFormData()
        .body({ translate: 'body.married.ask' })
        .button({ translate: 'action.yes.button' })
        .button({ translate: 'action.no.button' })
        .show(entity)
        .then(r => {
            if (r.canceled) jokePlayer(player, entity);
            let response = r.selection;
            if (response == 0) {
                entity.addTag(`married_${player.name}`);
                player.addTag(`married_${entity.name}`)
            } else {
                entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@s"}, {"translate": "message.no.player"}]}`);
            }
        })
}
export function actionUiPlayer(player, entity, levelLove, item) {
    const action = new ActionFormData()
        .title(`${titleWorking}`)
        .body(`${civilStatus}${levelLove}`)
        .button({ translate: 'action.interact.button' })
        .button({ translate: 'action.ask_for_marriage.button' })
        .button({ translate: 'action.close.button' })
        .show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    actionInteractPlayerUi(player, entity, levelLove, civilStatus, titleWorking);
                    break;
                case 1:
                    if (levelLove > 50 && item && item.typeId === 'pf:wedding_ring') {
                        marriedPlayer(player, entity);
                    } else {
                        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"translate": "message.scoreOrRing.player"}]}`);
                    }
                    break;
                case 5:
                    break;
                default:
                    break;
            }
        })
}
function actioRideMob(player, entity, levelLove) {
    const actioRideMob = new ActionFormData()
        .title(`${titleWorking}`)
        .body(`${civilStatus}${levelLove}`)
        .button({ translate: 'action.ride_a_horse.button' })
        .button({ translate: 'action.ride_a_camel.button' })
        .button({ translate: 'action.stop_ride.button' })
        .button({ translate: 'action.return.button' })
        .show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    entity.runCommandAsync(`ride @s start_riding @e[type=horse,c=1,r=8] teleport_ride`)
                        .then(rideHorseResult => {
                            if (rideHorseResult.successCount === 0) {
                                entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "action.noRide.horse"}]}`);
                            }
                        })
                    break;
                case 1:
                    entity.runCommandAsync(`ride @s start_riding @e[type=camel,c=1,r=8] teleport_ride`)
                        .then(rideCamelResult => {
                            if (rideCamelResult.successCount === 0) {
                                entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "action.noRide.camel"}]}`);
                            }
                        })
                    break;
                case 2:
                    entity.runCommandAsync(`ride @s stop_riding`)
                        .then(stopResult => {
                            if (stopResult.successCount === 0) {
                                entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "action.what.message"}]}`);
                            }
                        })
                    break;
                case 3:
                    actionUi(player, entity, levelLove);
                    break;
                default:
                    break;
            }
        });
}
function actionMovementUi(player, entity, levelLove) {
    const move = new ActionFormData()
        .title(`${titleWorking}`)
        .body(`${civilStatus}${levelLove}`)
        .button({ translate: 'action.move.button' })
        .button({ translate: 'action.static.button' })
        .button({ translate: 'action.follow_me.button' })
        .button({ translate: 'action.return.button' })
        .show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    player.playSound('mob.villager.move');
                    entity.triggerEvent('move');
                    if (entity.hasTag(`"follow_${player.name}"`)) {
                        entity.removeTag(`"follow_${player.name}"`);
                    }
                    break;
                case 1:
                    player.playSound('mob.villager.static');
                    entity.triggerEvent('static');
                    if (entity.hasTag(`"follow_${player.name}"`)) {
                        entity.removeTag(`"follow_${player.name}"`);
                    }
                    break;
                case 2:
                    player.playSound('mob.villager.follow');
                    if (!entity.hasTag(`"married_${player.name}"`)) {
                        entity.triggerEvent('follow_me');
                        entity.addTag(`"follow_${player.name}"`);
                        followMe(entity, player);
                    } else {
                        entity.triggerEvent('follow_me_married');
                    }
                    break;
                case 3:
                    actionUi(player, entity, levelLove);
                    break;
                default:
                    if (entity.hasTag(`"follow_${player.name}"`)) {
                        entity.removeTag(`"follow_${player.name}"`);
                    }
                    break;
            }
        })
}
function followMe(entity, player) {
    let lastPlayerLocation = null;
    const follow = system.runInterval(() => {
        if (entity.hasTag(`"follow_${player.name}"`)) {
            const playerLocation = player.location;
            const playerRotation = player.getRotation();

            if (lastPlayerLocation &&
                lastPlayerLocation.x === playerLocation.x &&
                lastPlayerLocation.y === playerLocation.y &&
                lastPlayerLocation.z === playerLocation.z) {
                return;
            }

            lastPlayerLocation = { ...playerLocation };

            let zOffset = 0;
            let xOffset = 0;
            const dimension = player.dimension;
            const roundedRotation = Math.round(playerRotation.y / 90) * 90;
            switch (roundedRotation) {
                case 0:
                    zOffset = -1.5;
                    xOffset = 0;
                    break;
                case 90:
                    zOffset = 0;
                    xOffset = 1.5;
                    break;
                case -90:
                    zOffset = 0;
                    xOffset = -1.5;
                    break;
                case -180:
                case 180:
                    zOffset = 1.5;
                    xOffset = 0;
                    break;
            }
            const followLocation = {
                x: playerLocation.x + xOffset,
                y: playerLocation.y,
                z: playerLocation.z + zOffset
            };
            entity.followLocation = followLocation;
            const block = dimension.getBlock(followLocation);
            if (block && block.typeId === "minecraft:air") {
                entity.teleport(followLocation);
                entity.setRotation(playerRotation);
            }
        } else {
            system.clearRun(follow);
        }
    }, 1);
}


