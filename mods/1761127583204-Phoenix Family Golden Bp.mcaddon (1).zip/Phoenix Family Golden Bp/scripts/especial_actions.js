import { ActionFormData } from '@minecraft/server-ui';
import { system, ItemStack, ItemLockMode, world, EntityComponentTypes } from '@minecraft/server';
import { actionUi } from "./golden";
import { searchNearbyBlocks } from "./miner_locate";
import { personality } from "./assign_personality";
let humanNature = 'adopt';
const soundOptions = {
    volume: 0.1
};

export function specialUi(player, entity, levelLove, civilStatus, titleWorking) {
    const special = new ActionFormData()
        .title(`${titleWorking}`)
        .body(`${civilStatus}${levelLove}`)
        .button({ translate: 'action.set_home.button' })
        .button({ translate: 'action.go_home.button' })
        .button({ translate: 'action.work.button' })
        .button({ translate: 'action.personality.button' })
        .button({ translate: 'action.next.button' })
        .button({ translate: 'action.return.button' })
        .show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    setHome(player, entity);
                    break;
                case 1:
                    goHome(player, entity);
                    break;
                case 2:
                    const familyComponent = entity.getComponent("minecraft:type_family");
                    const family = familyComponent.getTypeFamilies();
                    if (family.includes("farmer")) {
                        entity.addTag(`working`);
                        entity.triggerEvent('work_farmer');
                    } else if (family.includes("stone_miner")) {
                        entity.addTag(`working`);
                        entity.addTag(`work_miner`);
                        entity.triggerEvent('work_miner');
                        entityMinerWork(player, entity);
                    } else if (family.includes("librarian")) {
                        entity.addTag(`working`);
                        entity.addTag(`work_librarian`);
                        entity.triggerEvent('work_librarian');
                    } else if (family.includes("cleric")) {
                        entity.addTag(`working`);
                        entity.addTag(`work_cleric`);
                        entity.triggerEvent('work_cleric');
                    } else if (family.includes("fletcher")) {
                        entity.addTag(`working`);
                        entity.addTag(`work_fletcher`);
                        entity.triggerEvent('work_fletcher');
                        workFletcher(player, entity, levelLove, civilStatus, titleWorking);
                    }
                    break;
                case 3:
                    personality(player, entity);
                    break;
                case 4:
                    specialUiNext(player, entity, levelLove, civilStatus, titleWorking);
                    break;
                case 5:
                    actionUi(player, entity, levelLove);
                    break;
                default:
                    break;
            }
        });
}
export function workFletcher(player, entity, levelLove, civilStatus, titleWorking) {
    const heldItem = entity.getProperty("pf:helditem")
    if (!heldItem) {
        entity.setDynamicProperty("temporaryBow", true);
        entity.runCommand(`replaceitem entity @s slot.weapon.mainhand 0 bow`)
    } else {
        entity.setDynamicProperty("temporaryBow", false);
    }
    const weaponCheckPromises = [
        entity.runCommandAsync(`testfor @s[hasitem={item=bow,location=slot.weapon.mainhand}]`),
        entity.runCommandAsync(`testfor @s[hasitem={item=crossbow,location=slot.weapon.mainhand}]`),
        entity.runCommandAsync(`testfor @s[hasitem={item=trident,location=slot.weapon.mainhand}]`)
    ];
    Promise.all(weaponCheckPromises).then(results => {
        const [bowResult, crossbowResult, tridentResult] = results;
        entity.removeTag('bowActive');
        entity.removeTag('crossbowActive');
        entity.removeTag('tridentActive');
        if (bowResult.successCount === 1) {
            entity.addTag('bowActive');
        } else if (crossbowResult.successCount === 1) {
            entity.addTag('crossbowActive');
        } else if (tridentResult.successCount === 1) {
            entity.addTag('tridentActive');
        }
        const special = new ActionFormData()
            .title(`${titleWorking}`)
            .body(`${civilStatus}${levelLove}`)
            .button({ translate: 'hunt.pig.button' }, "textures/items/porkchop_raw")
            .button({ translate: 'hunt.chicken.button' }, "textures/items/chicken_raw")
            .button({ translate: 'hunt.cow.button' }, "textures/items/beef_raw")
            .button({ translate: 'hunt.sheep.button' }, "textures/items/mutton_raw")
            .button({ translate: 'hunt.rabbit.button' }, "textures/items/rabbit_raw")
            .button({ translate: 'hunt.cod.button' }, "textures/items/fish_raw")
            .button({ translate: 'hunt.salmon.button' }, "textures/items/fish_salmon_raw")
            .show(player)
            .then(r => {
                if (r.canceled) {
                    workFletcher(player, entity, levelLove, civilStatus, titleWorking);
                    return;
                };
                const animalActions = ['pig', 'chicken', 'cow', 'sheep', 'rabbit', 'cod', 'salmon'];
                const selectedAnimal = animalActions[r.selection];

                if (entity.hasTag('bowActive')) {
                    entity.triggerEvent(`bow_${selectedAnimal}`);
                } else if (entity.hasTag('crossbowActive')) {
                    entity.triggerEvent(`crossbow_${selectedAnimal}`);
                } else if (entity.hasTag('tridentActive')) {
                    entity.triggerEvent(`trident_${selectedAnimal}`);
                } else {
                    entity.triggerEvent(`melee_${selectedAnimal}`);
                }
                entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "say.hunting.${selectedAnimal}"}]}`);
            });
    });
}
export function specialUiParent(player, entity, levelLove, civilStatus, titleWorking) {
    const baby = entity.getComponent('minecraft:is_baby');
    const special = new ActionFormData()
        .title(`${titleWorking}`)
        .body(`${civilStatus}${levelLove}`)
        .button({ translate: 'action.set_home.button' })
        .button({ translate: 'action.go_home.button' })
        .button({ translate: 'action.work.button' })
        .button({ translate: 'action.attachable.button' })
        .button({ translate: 'action.guardian.button' })
        .button({ translate: 'action.return.button' })
        .show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    setHome(player, entity);
                    break;
                case 1:
                    goHome(player, entity);
                    break;
                case 2:
                    const familyComponent = entity.getComponent("minecraft:type_family");
                    const family = familyComponent.getTypeFamilies();
                    if (!baby) {
                        if (family.includes("farmer")) {
                            entity.addTag(`working`);
                            entity.triggerEvent('work_farmer');
                        } else if (family.includes("stone_miner")) {
                            entity.addTag(`working`);
                            entity.addTag(`work_miner`);
                            entity.triggerEvent('work_miner');
                            entityMinerWork(player, entity);
                        } else if (family.includes("librarian")) {
                            entity.addTag(`working`);
                            entity.addTag(`work_librarian`);
                            entity.triggerEvent('work_librarian');
                        }
                    } else {
                        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "player.menssage.Imbaby"}]}`);
                    }
                    break;
                case 3:
                    entity.addTag(`armorable`);
                    if ((!player.hasTag(`relative${entity.id}`) && !player.hasTag(`parent${entity.id}`))) {
                        entity.triggerEvent('armorable');
                    } else {
                        entity.triggerEvent('armorableSon');
                    }
                    break;
                case 4:
                    if (!baby) {
                        guardian(player, entity, levelLove, civilStatus, titleWorking);
                    } else {
                        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "player.menssage.Imbaby"}]}`);
                    }
                    break;
                case 5:
                    actionUi(player, entity, levelLove);
                    break;
                default:
                    break;
            }
        });
}
export function entityMinerWork(player, entity) {
    const miner = system.runInterval(() => {
        if (entity.hasTag(`work_miner`)) {
            searchNearbyBlocks(player, entity);
        } else {
            system.clearRun(miner);
        }
    }, 600);
}
export function specialUiNext(player, entity, levelLove, civilStatus, titleWorking) {
    const inventory = player.getComponent("minecraft:inventory");
    const skinIdComponent = entity.getComponent("minecraft:skin_id");
    const skinIdValue = skinIdComponent.value;
    const heldItem = inventory.container.getItem(0);
    if (skinIdValue % 2 !== 0 && !player.hasTag(`male`)) {
        humanNature = 'adopt';
    } if (skinIdValue % 2 !== 0 && player.hasTag(`male`)) {
        humanNature = 'pregnant';
    } else if (player.hasTag(`female`)) {
        humanNature = 'pregnant';
    } else if (!player.hasTag(`female`)) {
        humanNature = 'adopt';
    }
    const specialNext = new ActionFormData()
        .title(`${titleWorking}`)
        .body(`${civilStatus}${levelLove}`)
        .button({ translate: `action.${humanNature}.button` })
        .button({ translate: 'action.attachable.button' })
        .button({ translate: 'action.guardian.button' })
        .button({ translate: 'action.return.button' })
        .show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    if (!heldItem) {
                        player.runCommand(`scoreboard players set @s timeGrow 0`);
                        entity.runCommand(`playanimation @s animation.humanoid.pregnat`);
                        pregnant(player, heldItem);
                    } else {
                        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "player.message.noItemPregnant"}]}`);
                    }
                    break;
                case 1:
                    entity.addTag(`armorable`);
                    entity.triggerEvent('armorable');
                    break;
                case 2:
                    guardian(player, entity, levelLove, civilStatus, titleWorking);
                    break;
                case 3:
                    specialUi(player, entity, levelLove, civilStatus, titleWorking);
                    break;
                default:
                    break;
            }
        });
}
export function pregnant(player) {
    player.addTag(`pregnant`);
    player.runCommand(`scoreboard objectives add timeGrow dummy`);
    player.runCommand(`scoreboard players set @s timeGrow 0`);
    const inventory = player.getComponent("minecraft:inventory").container;
    const baby = ['pf:baby_boy', 'pf:baby_girl'];
    const randomIndex = Math.floor(Math.random() * baby.length);
    const createBaby = new ItemStack(baby[randomIndex], 1);
    createBaby.lockMode = ItemLockMode.slot;
    createBaby.keepOnDeath = true;
    createBaby.setLore([
        'time to grow: ',
        `0`,
        'Emotion: Happy'
    ]);
    inventory.setItem(0, createBaby);
    growBaby(player);
}
export function growBaby(player) {
    const inventory = player.getComponent("minecraft:inventory");
    const updateInterval = system.runInterval(() => {
        const item = inventory.container.getItem(0);
        if (item && (item.typeId === 'pf:baby_girl' || item.typeId === 'pf:baby_boy')) {
            let timeGrow = world.scoreboard.getObjective('timeGrow').getScore(player) || 0;
            if (timeGrow < 101) {
                player.runCommand(`scoreboard players add @s timeGrow 1`);
                if (Math.random() < 0.95) {
                    let newItem = item.typeId.includes('girl') ? 'pf:baby_girl' : 'pf:baby_boy';
                    const newItemStack = new ItemStack(newItem, 1);
                    newItemStack.lockMode = ItemLockMode.slot;
                    newItemStack.keepOnDeath = true;
                    newItemStack.setLore([
                        'time to grow: ',
                        `${timeGrow}%`,
                        'Emotion: Happy'
                    ]);
                    inventory.container.setItem(0, newItemStack);
                } else if (Math.random() < 0.4) {
                    player.playSound('mob.villager_baby.cry');
                    let newItem = item.typeId.includes('girl') ? 'pf:baby_girl_crying' : 'pf:baby_boy_crying';
                    const newItemStack = new ItemStack(newItem, 1);
                    newItemStack.lockMode = ItemLockMode.slot;
                    newItemStack.keepOnDeath = true;
                    newItemStack.setLore([
                        'time to grow: ',
                        `${timeGrow}%`,
                        'Emotion: Crying'
                    ]);
                    inventory.container.setItem(0, newItemStack);
                } else if (Math.random() < 0.3) {
                    player.playSound('mob.villager_baby.angry');
                    let newItem = item.typeId.includes('girl') ? 'pf:baby_girl_angry' : 'pf:baby_boy_angry';
                    const newItemStack = new ItemStack(newItem, 1);
                    newItemStack.lockMode = ItemLockMode.slot;
                    newItemStack.keepOnDeath = true;
                    newItemStack.setLore([
                        'time to grow: ',
                        `${timeGrow}%`,
                        'Emotion: Angry'
                    ]);
                    inventory.container.setItem(0, newItemStack);
                }
            } else {
                system.clearRun(updateInterval);
            }
        }
    }, 180);
}
function guardian(player, entity, levelLove, civilStatus, titleWorking) {
    const weaponCheckPromises = [
        entity.runCommandAsync(`testfor @s[hasitem={item=bow,location=slot.weapon.mainhand}]`),
        entity.runCommandAsync(`testfor @s[hasitem={item=crossbow,location=slot.weapon.mainhand}]`),
        entity.runCommandAsync(`testfor @s[hasitem={item=trident,location=slot.weapon.mainhand}]`)
    ];

    Promise.all(weaponCheckPromises).then(results => {
        const [bowResult, crossbowResult, tridentResult] = results;
        entity.removeTag('bowActive');
        entity.removeTag('crossbowActive');
        entity.removeTag('tridentActive');
        if (bowResult.successCount === 1) {
            entity.addTag('bowActive');
        } else if (crossbowResult.successCount === 1) {
            entity.addTag('crossbowActive');
        } else if (tridentResult.successCount === 1) {
            entity.addTag('tridentActive');
        }
        const guardian = new ActionFormData()
            .title(`${titleWorking}`)
            .body(`${civilStatus}${levelLove}`)
            .button({ translate: 'action.melee.button' })
            .button({ translate: 'action.ranged.button' })
            .button({ translate: 'action.return.button' })
            .show(player)
            .then(r => {
                if (r.canceled) return;
                let response = r.selection;

                switch (response) {
                    case 0:
                        entity.addTag('guardian');
                        entity.triggerEvent('minecraft:melee_attack');
                        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "player.menssage.mode.active.melee"}]}`);
                        player.playSound('mob.villager.melee');
                        break;

                    case 1:
                        if (entity.hasTag('bowActive')) {
                            entity.triggerEvent('minecraft:ranged_attack');
                        } else if (entity.hasTag('crossbowActive')) {
                            entity.triggerEvent('with_crossbow');
                        } else if (entity.hasTag('tridentActive')) {
                            entity.triggerEvent('minecraft:ranged_attack_trident');
                        } else {
                            entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"translate": "player.menssage.noBow"}]}`);
                            return;
                        }
                        entity.addTag('guardian');
                        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "player.menssage.mode.active.ranged"}]}`);
                        player.playSound('mob.villager.ranged');
                        break;

                    case 2:
                        specialUiNext(player, entity, levelLove, civilStatus, titleWorking);
                        break;
                }
            });
    });
}
export function specialUiBeforeGettingMarried(player, entity, levelLove, civilStatus, titleWorking) {
    const baby = entity.getComponent('minecraft:is_baby');
    const specialBeforeGettingMarried = new ActionFormData()
        .title(`${titleWorking}`)
        .body(`${civilStatus}${levelLove}`)
        .button({ translate: 'action.ask_for_marriage.button' })
        .button({ translate: 'action.set_home.button' })
        .button({ translate: 'action.go_home.button' })
        .button({ translate: 'action.personality.button' })
        .button({ translate: 'action.socialize.button' })
        .button({ translate: 'action.return.button' })
        .show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    if (player.hasTag(`pf:married`)) {
                        let points = 50;
                        player.playSound('mob.villager.lose_love_points', soundOptions);
                        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "message.married.angry"}]}`);
                        entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${points} "}, {"translate": "translate.points.text"}]}`);
                        entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players remove @s "PF_${player.name}_hearts" ${points}`);
                    } else if (baby) {
                        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "player.menssage.Imbaby"}]}`);
                    } else {
                        player.playSound('mob.villager.marriage_proposal');
                        checkMarriage(player, entity, levelLove);
                    }
                    break;
                case 1:
                    setHome(player, entity);
                    break;
                case 2:
                    goHome(player, entity);
                    break;
                case 3:
                    if (levelLove >= 30) {
                        personality(player, entity);
                    } else {
                        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "player.menssage.dont_tell_secrets"}]}`);
                    }
                    break;
                case 4:
                    if (baby) {
                        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "player.menssage.Imbaby"}]}`);
                    } else {
                        player.playSound('mob.villager.socialize');
                        entity.addTag(`socialize`);
                        entity.triggerEvent(`socialize`);
                    }
                    break;
                case 5:
                    actionUi(player, entity, levelLove);
                    break;
                default:
                    break;
            }
        });
}
export function cancelMarriageProposalUi(player, entity) {
    const cancelForm = new ActionFormData()
        .title({ translate: 'title.cancel.MarriageProposal' })
        .body({ translate: 'cancel.MarriageProposal.body' })
        .button({ translate: 'yes_button' })
        .button({ translate: 'no_button' })
        .show(player)
        .then(response => {
            if (response.canceled) return;
            if (response.selection === 0 && entity.hasTag(`married_${player.name}`)) {
                player.playSound('mob.villager.close_interactions');
                entity.removeTag(`married_${player.name}`);
                entity.triggerEvent('remove_hearts');
            } else if (response.selection === 0 && !entity.hasTag(`married_${player.name}`)) {
                entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "player.menssage.noOwner.cancelMarriageProposal"}]}`);
            } else if (response.selection === 1) {
                entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "player.menssage.no.cancelMarriageProposal"}]}`);
            }
        });
}
function setHome(player, entity) {
    const playerLocation = player.location;
    const homeLocation = {
        x: Math.round(playerLocation.x),
        y: Math.round(playerLocation.y),
        z: Math.round(playerLocation.z)
    };

    entity.homeLocation = homeLocation;

    // Guardar la ubicación de la casa como un Vector3
    entity.setDynamicProperty("homeLocation", homeLocation);

    player.playSound('mob.villager.sethome');
    entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "player.menssage.sethome"}, {"selector": "@e[name=${player.name},c=1]"}, {"text": "{ ${homeLocation.x}, ${homeLocation.y}, ${homeLocation.z}}"}]}`);
}
function goHome(player, entity) {
    const homeLocation = entity.getDynamicProperty("homeLocation");

    if (homeLocation) {
        player.playSound('mob.villager.teleport');
        entity.teleport(homeLocation);
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "player.menssage.goHome"}, {"text": "\n{ ${homeLocation.x} , ${homeLocation.y}, ${homeLocation.z}}"}]}`);
    } else {
        player.playSound('mob.villager.fail');
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "player.menssage.goHome.fail"}]}`);
    }
}
function checkMarriage(player, entity, levelLove) {
    const minHearts = Math.floor(levelLove / 10) * 10;
    const maxHearts = minHearts + 10;

    entity.runCommandAsync(`testfor @e[r=1,c=1,scores={"PF_${player.name}_hearts"=${minHearts}..${maxHearts}}]`)
        .then(heartResult => {
            if (heartResult.successCount === 1) {
                entity.addTag(`married_${player.name}`);
                entity.triggerEvent(`heart_${minHearts}`);
            }
        });
}