const physicalTraits = [
    "strong",
    "beautiful",
    "unattractive",
    "agile",
    "tall",
    "short",
    "slim",
    "fat",
    "clumsy"
];
const emotionalTraits = [
    "kind",
    "shy",
    "brave",
    "vain",
    "rude",
    "germ_phobia",
    "weird",
    "intelligent",
    "smiling",
    "joker",
    "bored"
];
const phobias = [
    "nophobias",
    "alektorophobia",
    "apiphobia",
    "ailurophobia",
    "arachnophobia",
    "bufonophobia"
];

export function personality(player, entity) {
    for (let i = 0; i < phobias.length; i++) {
        const hasPhobia = phobias[i];
        if (entity.hasTag(hasPhobia)) {
            entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "player.${hasPhobia}.phobia"}]}`);
        }
    }
    for (let i = 0; i < physicalTraits.length; i++) {
        const hasPhysicalTrait = physicalTraits[i]; 
        if (entity.hasTag(hasPhysicalTrait)) {
            entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"translate": "player.${hasPhysicalTrait}.physicalTrait"}]}`);
        }
    }
    for (let i = 0; i < emotionalTraits.length; i++) {
        const hasEmotionalTrait = emotionalTraits[i];
        if (entity.hasTag(hasEmotionalTrait)) {
            entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"translate": "player.${hasEmotionalTrait}.emotionalTrait"}]}`);
        }
    }
}


export function reassignPhobia(entity){
    for (let i = 0; i < phobias.length; i++) {
        const hasPhobia = phobias[i];
        if (entity.hasTag(hasPhobia)) {
            entity.triggerEvent(hasPhobia);
        }
    }
}

export function assignRandomPhysicalTrait(entity) {
    const randomIndex = Math.floor(Math.random() * physicalTraits.length);
    const randomTrait = physicalTraits[randomIndex];
    entity.addTag(randomTrait);
    entity.addTag('active_physical_trait');
}
export function assignRandomPhobia(entity) {
    const randomIndex = Math.floor(Math.random() * phobias.length);
    const randomPhobia = phobias[randomIndex];
    entity.addTag(randomPhobia);
    entity.addTag('active_phobia');
    entity.triggerEvent(randomPhobia);
}
export function assignRandomEmotionalTrait(entity) {
    const randomIndex = Math.floor(Math.random() * emotionalTraits.length);
    const randomTrait = emotionalTraits[randomIndex];
    entity.addTag(randomTrait);
    entity.addTag('active_emotional_trait');
}