import { ActionFormData } from '@minecraft/server-ui';
import { EntityComponentTypes } from '@minecraft/server';
import { actionUi, actionUiPlayer, actionMarriedUiPlayer } from "./golden";

const soundOptions = {
    volume: 0.1
};

export function actionInteractUi(player, entity, levelLove, civilStatus, titleWorking) {
    const interact = new ActionFormData()
        .title(`${titleWorking}`)
        .body(`${civilStatus}${levelLove}`)
        .button({ translate: 'action.joke.button' })
        .button({ translate: 'action.hug.button' })
        .button({ translate: 'action.story.button' })
        .button({ translate: 'action.next.button' })
        .button({ translate: 'action.return.button' })
        .show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    joke(player, entity);
                    break;
                case 1:
                    hug(player, entity);
                    break;
                case 2:
                    story(player, entity);
                    break;
                case 3:
                    actionInteracNextUi(player, entity, levelLove, civilStatus, titleWorking);
                    break;
                case 4:
                    actionUi(player, entity, levelLove);
                    break;
                default:
                    break;
            }
        })
}
function actionInteracNextUi(player, entity, levelLove, civilStatus, titleWorking) {
    const interact = new ActionFormData()
        .title(`${titleWorking}`)
        .body(`${civilStatus}${levelLove}`)
        .button({ translate: 'action.flirt.button' })
        .button({ translate: 'action.handshake.button' })
        .button({ translate: 'action.gift.button' })
        .button({ translate: 'action.kiss.button' })
        .button({ translate: 'action.return.button' })
        .show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    flirt(player, entity);
                    break;
                case 1:
                    handshake(player, entity);
                    break;
                case 2:
                    gift(player, entity);
                    break;
                case 3:
                    kiss(player, entity);
                    break;
                case 4:
                    actionInteractUi(player, entity, levelLove, civilStatus, titleWorking);
                    break;
                default:
                    break;
            }
        })
}
export function actionInteractPlayerUi(player, entity, levelLove, civilStatus, titleWorking) {
    const interact = new ActionFormData()
        .title(`${titleWorking}`)
        .body(`${civilStatus}${levelLove}`)
        .button({ translate: 'action.joke.button' })
        .button({ translate: 'action.hug.button' })
        .button({ translate: 'action.story.button' })
        .button({ translate: 'action.next.button' })
        .button({ translate: 'action.return.button' })
        .show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    jokePlayer(player, entity);
                    break;
                case 1:
                    hugPlayer(player, entity);
                    break;
                case 2:
                    storyPlayer(player, entity);
                    break;
                case 3:
                    actionInteracPlayerNextUi(player, entity, levelLove, civilStatus, titleWorking);
                    break;
                case 4:
                    actionUiPlayer(player, entity, levelLove);
                    break;
                default:
                    break;
            }
        })
}
function actionInteracPlayerNextUi(player, entity, levelLove, civilStatus, titleWorking) {
    const interact = new ActionFormData()
        .title(`${titleWorking}`)
        .body(`${civilStatus}${levelLove}`)
        .button({ translate: 'action.flirt.button' })
        .button({ translate: 'action.handshake.button' })
        .button({ translate: 'action.kiss.button' })
        .button({ translate: 'action.return.button' })
        .show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    flirtPlayer(player, entity);
                    break;
                case 1:
                    handshakePlayer(player, entity);
                    break;
                case 2:
                    kissPlayer(player, entity);
                    break;
                case 3:
                    actionInteractPlayerUi(player, entity, levelLove);
                    break;
                default:
                    break;
            }
        })
}
export function actionInteractPlayerMarriedUi(player, entity, levelLove, civilStatus, titleWorking) {
    const interact = new ActionFormData()
        .title(`${titleWorking}`)
        .body(`${civilStatus}${levelLove}`)
        .button({ translate: 'action.joke.button' })
        .button({ translate: 'action.hug.button' })
        .button({ translate: 'action.story.button' })
        .button({ translate: 'action.next.button' })
        .button({ translate: 'action.return.button' })
        .show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    jokePlayer(player, entity);
                    break;
                case 1:
                    hugPlayer(player, entity);
                    break;
                case 2:
                    storyPlayer(player, entity);
                    break;
                case 3:
                    actionInteracPlayerMarriedNextUi(player, entity, levelLove, civilStatus, titleWorking);
                    break;
                case 4:
                    actionMarriedUiPlayer(player, entity, levelLove);
                    break;
                default:
                    break;
            }
        })
}
function actionInteracPlayerMarriedNextUi(player, entity, levelLove, civilStatus, titleWorking) {
    const interact = new ActionFormData()
        .title(`${titleWorking}`)
        .body(`${civilStatus}${levelLove}`)
        .button({ translate: 'action.flirt.button' })
        .button({ translate: 'action.handshake.button' })
        .button({ translate: 'action.kiss.button' })
        .button({ translate: 'action.return.button' })
        .show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    flirtPlayer(player, entity);
                    break;
                case 1:
                    handshakePlayer(player, entity);
                    break;
                case 2:
                    kissPlayer(player, entity);
                    break;
                case 3:
                    actionInteractPlayerMarriedUi(player, entity, levelLove);
                    break;
                default:
                    break;
            }
        })
}
export function actionInteractUiParent(player, entity, levelLove, civilStatus, titleWorking) {
    const interactP = new ActionFormData()
        .title(`${titleWorking}`)
        .body(`${civilStatus}${levelLove}`)
        .button({ translate: 'action.joke.button' })
        .button({ translate: 'action.hug.button' })
        .button({ translate: 'action.story.button' })
        .button({ translate: 'action.gift.button' })
        .button({ translate: 'action.return.button' })
        .show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    jokeParent(player, entity);
                    break;
                case 1:
                    hugParent(player, entity);
                    break;
                case 2:
                    storyParent(player, entity);
                    break;
                case 3:
                    giftParent(player, entity);
                    break;
                case 4:
                    actionUi(player, entity, levelLove);
                    break;
                default:
                    break;
            }
        })
}
function jokePlayer(player, entity) {
    const jokePlayer = new ActionFormData()
        .body({ translate: 'body.joke.ask' })
        .button({ translate: 'action.yes.button' })
        .button({ translate: 'action.no.button' })
        .show(entity)
        .then(r => {
            if (r.canceled) jokePlayer(player, entity);
            let response = r.selection;
            let points = 0;
            const randomGain = Math.floor(Math.random() * 11) + 1;
            const randomLoss = Math.floor(Math.random() * 5) + 1;

            if (response == 0) {
                points = randomGain;
            } else {
                points = -randomLoss;
            }
            if (points > 0) {
                player.playSound('mob.villager.earn_love_points', soundOptions);
                entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.gain.points"},{"text": " ${points} "}, {"translate": "translate.points.text"}]}`);
            } else if (points < 0) {
                player.playSound('mob.villager.lose_love_points', soundOptions);
                entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
            }
            entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);
        })
}
function hugPlayer(player, entity) {
    const hugPlayer = new ActionFormData()
        .body({ translate: 'body.hug.ask' })
        .button({ translate: 'action.yes.button' })
        .button({ translate: 'action.no.button' })
        .show(entity)
        .then(r => {
            if (r.canceled) hugPlayer(player, entity);
            let response = r.selection;
            let points = 0;
            const randomGain = Math.floor(Math.random() * 11) + 1;
            const randomLoss = Math.floor(Math.random() * 5) + 1;

            if (response == 0) {
                points = randomGain;
            } else {
                points = -randomLoss;
            }
            if (points > 0) {
                player.playSound('mob.villager.earn_love_points', soundOptions);
                entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.gain.points"},{"text": " ${points} "}, {"translate": "translate.points.text"}]}`);
            } else if (points < 0) {
                player.playSound('mob.villager.lose_love_points', soundOptions);
                entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
            }
            entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);
        })
}
function storyPlayer(player, entity) {
    const storyPlayer = new ActionFormData()
        .body({ translate: 'body.story.ask' })
        .button({ translate: 'action.yes.button' })
        .button({ translate: 'action.no.button' })
        .show(entity)
        .then(r => {
            if (r.canceled) storyPlayer(player, entity);
            let response = r.selection;
            let points = 0;
            const randomGain = Math.floor(Math.random() * 11) + 1;
            const randomLoss = Math.floor(Math.random() * 5) + 1;

            if (response == 0) {
                points = randomGain;
            } else {
                points = -randomLoss;
            }
            if (points > 0) {
                player.playSound('mob.villager.earn_love_points', soundOptions);
                entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.gain.points"},{"text": " ${points} "}, {"translate": "translate.points.text"}]}`);
            } else if (points < 0) {
                entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
                player.playSound('mob.villager.lose_love_points', soundOptions);
            }
            entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);
        })
}
function flirtPlayer(player, entity) {
    const flirtPlayer = new ActionFormData()
        .body({ translate: 'body.flirt.ask' })
        .button({ translate: 'action.yes.button' })
        .button({ translate: 'action.no.button' })
        .show(entity)
        .then(r => {
            if (r.canceled) flirtPlayer(player, entity);
            let response = r.selection;
            let points = 0;
            const randomGain = Math.floor(Math.random() * 11) + 1;
            const randomLoss = Math.floor(Math.random() * 5) + 1;

            if (response == 0) {
                points = randomGain;
            } else {
                points = -randomLoss;
            }
            if (points > 0) {
                player.playSound('mob.villager.earn_love_points', soundOptions);
                entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.gain.points"},{"text": " ${points} "}, {"translate": "translate.points.text"}]}`);
            } else if (points < 0) {
                player.playSound('mob.villager.lose_love_points', soundOptions);
                entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
            }
            entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);
        })
}
function handshakePlayer(player, entity) {
    const handshakePlayer = new ActionFormData()
        .body({ translate: 'body.handshake.ask' })
        .button({ translate: 'action.yes.button' })
        .button({ translate: 'action.no.button' })
        .show(entity)
        .then(r => {
            if (r.canceled) handshakePlayer(player, entity);
            let response = r.selection;
            let points = 0;
            const randomGain = Math.floor(Math.random() * 11) + 1;
            const randomLoss = Math.floor(Math.random() * 5) + 1;

            if (response == 0) {
                points = randomGain;
            } else {
                points = -randomLoss;
            }
            if (points > 0) {
                player.playSound('mob.villager.earn_love_points', soundOptions);
                entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.gain.points"},{"text": " ${points} "}, {"translate": "translate.points.text"}]}`);
            } else if (points < 0) {
                player.playSound('mob.villager.lose_love_points', soundOptions);
                entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
            }
            entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);
        })
}
function kissPlayer(player, entity) {
    const kissPlayer = new ActionFormData()
        .body({ translate: 'body.kiss.ask' })
        .button({ translate: 'action.yes.button' })
        .button({ translate: 'action.no.button' })
        .show(entity)
        .then(r => {
            if (r.canceled) kissPlayer(player, entity);
            let response = r.selection;
            let points = 0;
            const randomGain = Math.floor(Math.random() * 11) + 1;
            const randomLoss = Math.floor(Math.random() * 5) + 1;

            if (response == 0) {
                points = randomGain;
            } else {
                points = -randomLoss;
            }
            if (points > 0) {
                player.playSound('mob.villager.earn_love_points', soundOptions);
                entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.gain.points"},{"text": " ${points} "}, {"translate": "translate.points.text"}]}`);
            } else if (points < 0) {
                player.playSound('mob.villager.lose_love_points', soundOptions);
                entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
            }
            entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);
        })
}
function giftParent(player, entity) {
    const goodGifts = ['diamond', 'emerald', 'redstone', 'netherite', 'iron', 'gold', 'golden', 'flower', 'chainmail', 'clock', 'lapis', 'nether_star', 'pumpkin_pie', 'totem_of_undying', 'trident', 'music_disc', 'end_crystal', 'ender_pearl', 'dragon_breath', 'dragon_egg', 'cookie', 'cake'];
    const badGifts = ['bone', 'blaze', 'dye', 'beetroot', 'stone', 'bread', 'brick', 'concretepowder', 'crying_obsidian', 'deadbush', 'dirt', 'feather', 'gravel', 'kelp', 'leather', 'leaves', 'mycelium', 'netherrack', 'paper', 'poisonous_potato', 'sand', 'spider', 'rotten_flesh'];
    let points = 0;
    const randomGain = Math.floor(Math.random() * 11) + 1;
    const randomLoss = Math.floor(Math.random() * 5) + 1;
    const randomMessage = Math.floor(Math.random() * 10) + 1;
    const randomMessageFake = Math.floor(Math.random() * 3) + 1;
    const inventory = player.getComponent("minecraft:inventory")
    const equipmentCompPlayer = player.getComponent(EntityComponentTypes.Equippable);
    const heldItem = equipmentCompPlayer.getEquipment("Mainhand");
    if (heldItem && heldItem.typeId) {
        const isGoodGift = goodGifts.some(gift => heldItem.typeId.includes(gift));
        const isBadGift = badGifts.some(gift => heldItem.typeId.includes(gift));
        player.runCommand(`clear ${player.name} ${heldItem.typeId} -1 1`);
        if (isGoodGift) {
            points = Math.random() < 0.4 ? randomGain : -randomLoss;
        } else if (isBadGift) {
            points = Math.random() < 0.35 ? randomGain : -randomLoss;
        } else {
            points = Math.random() < 0.3 ? randomGain : -randomLoss;
        }
        entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);
        if (points > 0) {
            player.playSound('mob.villager.earn_love_points', soundOptions);
            entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.gain.points"},{"text": " ${points} "}, {"translate": "translate.points.text"}]}`);
            entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "${isGoodGift ? 'messageParent.goodgifts' : (isBadGift ? 'messageParent.badgifts' : 'messageParent.regulargifts')}.${randomMessage}"}]}`);
        } else if (points < 0) {
            player.playSound('mob.villager.lose_love_points', soundOptions);
            entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
            entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "${isGoodGift ? 'messageParent.goodgifts.fail' : (isBadGift ? 'messageParent.badgifts.fail' : 'messageParent.regulargifts.fail')}.${randomMessage}"}]}`);
        }
    } else {
        player.playSound('mob.villager.lose_love_points', soundOptions);
        points = Math.random() < 0.5 ? -randomLoss : 0;
        entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "messageParent.gifts.fake.${randomMessageFake}"}]}`);
        entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);
    }
}
function gift(player, entity) {
    const goodGifts = ['diamond', 'emerald', 'redstone', 'netherite', 'iron', 'gold', 'golden', 'flower', 'chainmail', 'clock', 'lapis', 'nether_star', 'pumpkin_pie', 'totem_of_undying', 'trident', 'music_disc', 'end_crystal', 'ender_pearl', 'dragon_breath', 'dragon_egg', 'cookie', 'cake'];
    const badGifts = ['bone', 'blaze', 'dye', 'beetroot', 'stone', 'bread', 'brick', 'concretepowder', 'crying_obsidian', 'deadbush', 'dirt', 'feather', 'gravel', 'kelp', 'leather', 'leaves', 'mycelium', 'netherrack', 'paper', 'poisonous_potato', 'sand', 'spider', 'rotten_flesh'];
    let points = 0;
    const randomGain = Math.floor(Math.random() * 11) + 1;
    const randomLoss = Math.floor(Math.random() * 5) + 1;
    const randomMessage = Math.floor(Math.random() * 10) + 1;
    const randomMessageFake = Math.floor(Math.random() * 3) + 1;
    const inventory = player.getComponent("minecraft:inventory")
    const equipmentCompPlayer = player.getComponent(EntityComponentTypes.Equippable);
    const heldItem = equipmentCompPlayer.getEquipment("Mainhand");

    if (entity.hasComponent('is_tamed') && entity.hasTag(`married_${player.name}`)) {
        if (heldItem && heldItem.typeId) {
            const isGoodGift = goodGifts.some(gift => heldItem.typeId.includes(gift));
            const isBadGift = badGifts.some(gift => heldItem.typeId.includes(gift));
            player.runCommand(`clear ${player.name} ${heldItem.typeId} -1 1`);
            if (isGoodGift) {
                points = Math.random() < 1.0 ? randomGain : -randomLoss;
            } else if (isBadGift) {
                points = Math.random() < 0.4 ? randomGain : -randomLoss;
            } else {
                points = Math.random() < 0.75 ? randomGain : -randomLoss;
            }
            entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);
            if (points > 0) {
                player.playSound('mob.villager.earn_love_points', soundOptions);
                entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.gain.points"},{"text": " ${points} "}, {"translate": "translate.points.text"}]}`);
                entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "${isGoodGift ? 'message.goodgifts' : (isBadGift ? 'message.badgifts' : 'message.regulargifts')}.${randomMessage}"}]}`);
                entity.runCommand(`playanimation @s yes`);
            } else if (points < 0) {
                player.playSound('mob.villager.lose_love_points', soundOptions);
                entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
                entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "${isGoodGift ? 'message.goodgifts.fail' : (isBadGift ? 'message.badgifts.fail' : 'message.regulargifts.fail')}.${randomMessage}"}]}`);
                entity.runCommand(`playanimation @s no`);
            }
        } else {
            player.playSound('mob.villager.lose_love_points', soundOptions);
            points = Math.random() < 0.2 ? -randomLoss : 0;
            entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
            entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "message.gifts.fake.${randomMessageFake}"}]}`);
            entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);
            entity.runCommand(`playanimation @s no`);
        }
    } else {
        if (heldItem && heldItem.typeId) {
            const isGoodGift = goodGifts.some(gift => heldItem.typeId.includes(gift));
            const isBadGift = badGifts.some(gift => heldItem.typeId.includes(gift));
            player.runCommand(`clear ${player.name} ${heldItem.typeId} -1 1`);
            if (isGoodGift) {
                points = Math.random() < 0.8 ? randomGain : -randomLoss;
            } else if (isBadGift) {
                points = Math.random() < 0.2 ? randomGain : -randomLoss;
            } else {
                points = Math.random() < 0.35 ? randomGain : -randomLoss;
            }
            entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);
            if (points > 0) {
                player.playSound('mob.villager.earn_love_points', soundOptions);
                entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.gain.points"},{"text": " ${points} "}, {"translate": "translate.points.text"}]}`);
                entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "${isGoodGift ? 'message.goodgifts' : (isBadGift ? 'message.badgifts' : 'message.regulargifts')}.${randomMessage}"}]}`);
                entity.runCommand(`playanimation @s yes`);
            } else if (points < 0) {
                player.playSound('mob.villager.lose_love_points', soundOptions);
                entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
                entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "${isGoodGift ? 'message.goodgifts.fail' : (isBadGift ? 'message.badgifts.fail' : 'message.regulargifts.fail')}.${randomMessage}"}]}`);
                entity.runCommand(`playanimation @s no`);
            }
        } else {
            player.playSound('mob.villager.lose_love_points', soundOptions);
            points = Math.random() < 0.5 ? -randomLoss : 0;
            entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
            entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "message.gifts.fake.${randomMessageFake}"}]}`);
            entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);
            entity.runCommand(`playanimation @s no`);
        }
    }
}
function joke(player, entity) {
    let points = 0;
    const randomGain = Math.floor(Math.random() * 11) + 1;
    const randomLoss = Math.floor(Math.random() * 5) + 1;
    const randomMessage = Math.floor(Math.random() * 10) + 1; // Número aleatorio entre 1 y 10 para seleccionar el mensaje

    if (entity.hasComponent('is_tamed') && entity.hasTag(`married_${player.name}`)) {
        points = Math.random() < 0.9 ? randomGain : -randomLoss;
    } else if (entity.hasTag('kind')) {
        points = Math.random() < 0.55 ? randomGain : -randomLoss;
    } else if (entity.hasTag('shy')) {
        points = Math.random() < 0.35 ? randomGain : -randomLoss;
    } else if (entity.hasTag('brave')) {
        points = Math.random() < 0.25 ? randomGain : -randomLoss;
    } else if (entity.hasTag('vain')) {
        points = Math.random() < 0.15 ? randomGain : -randomLoss;
    } else if (entity.hasTag('rude')) {
        points = Math.random() < 0.25 ? randomGain : -randomLoss;
    } else if (entity.hasTag('germ_phobia')) {
        points = Math.random() < 0.6 ? randomGain : -randomLoss;
    } else if (entity.hasTag('weird')) {
        points = Math.random() < 0.65 ? randomGain : -randomLoss;
    } else if (entity.hasTag('smiling')) {
        points = Math.random() < 0.85 ? randomGain : -randomLoss;
    } else if (entity.hasTag('joker')) {
        points = Math.random() < 0.95 ? randomGain : -randomLoss;
    } else if (entity.hasTag('bored')) {
        points = Math.random() < 0.06 ? randomGain : -randomLoss;
    } else if (entity.hasTag('intelligent')) {
        points = Math.random() < 0.26 ? randomGain : -randomLoss;
    }

    entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);

    if (points > 0) {
        player.playSound('mob.villager.earn_love_points', soundOptions);
        entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.gain.points"},{"text": " ${points} "}, {"translate": "translate.points.text"}]}`);
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "message.joke.${randomMessage}"}]}`);
        entity.runCommand(`playanimation @s joke`);
    } else if (points < 0) {
        player.playSound('mob.villager.lose_love_points', soundOptions);
        entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "message.joke.fail.${randomMessage}"}]}`);
        entity.runCommand(`playanimation @s no`);
    }
}
function jokeParent(player, entity) {
    let points = 0;
    const randomGain = Math.floor(Math.random() * 11) + 1; // Número aleatorio entre 1 y 15 para la ganancia máxima
    const randomLoss = Math.floor(Math.random() * 5) + 1; // Número aleatorio entre 1 y 5 para la pérdida máxima
    const randomMessage = Math.floor(Math.random() * 10) + 1; // Número aleatorio entre 1 y 10 para seleccionar el mensaje

    if (entity.hasTag('kind')) {
        points = Math.random() < 0.55 ? randomGain : -randomLoss;
    } else if (entity.hasTag('shy')) {
        points = Math.random() < 0.35 ? randomGain : -randomLoss;
    } else if (entity.hasTag('brave')) {
        points = Math.random() < 0.25 ? randomGain : -randomLoss;
    } else if (entity.hasTag('vain')) {
        points = Math.random() < 0.15 ? randomGain : -randomLoss;
    } else if (entity.hasTag('rude')) {
        points = Math.random() < 0.25 ? randomGain : -randomLoss;
    } else if (entity.hasTag('germ_phobia')) {
        points = Math.random() < 0.6 ? randomGain : -randomLoss;
    } else if (entity.hasTag('weird')) {
        points = Math.random() < 0.65 ? randomGain : -randomLoss;
    } else if (entity.hasTag('smiling')) {
        points = Math.random() < 0.85 ? randomGain : -randomLoss;
    } else if (entity.hasTag('joker')) {
        points = Math.random() < 0.95 ? randomGain : -randomLoss;
    } else if (entity.hasTag('bored')) {
        points = Math.random() < 0.06 ? randomGain : -randomLoss;
    } else if (entity.hasTag('intelligent')) {
        points = Math.random() < 0.26 ? randomGain : -randomLoss;
    }

    entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);

    if (points > 0) {
        player.playSound('mob.villager.earn_love_points', soundOptions);
        entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.gain.points"},{"text": " ${points} "}, {"translate": "translate.points.text"}]}`);
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "messageParent.joke.${randomMessage}"}]}`);
    } else if (points < 0) {
        player.playSound('mob.villager.lose_love_points', soundOptions);
        entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "messageParent.joke.fail.${randomMessage}"}]}`);
    }
}
function hug(player, entity) {
    let points = 0;
    const randomMessage = Math.floor(Math.random() * 10) + 1;
    const randomGain = Math.floor(Math.random() * 11) + 1;
    const randomLoss = Math.floor(Math.random() * 5) + 1;

    if (entity.hasComponent('is_tamed') && entity.hasTag(`married_${player.name}`)) {
        points = Math.random() < 0.9 ? randomGain : -randomLoss;
    } else if (entity.hasTag('kind')) {
        points = Math.random() < 0.85 ? randomGain : -randomLoss;
    } else if (entity.hasTag('shy')) {
        points = Math.random() < 0.15 ? randomGain : -randomLoss;
    } else if (entity.hasTag('brave')) {
        points = Math.random() < 0.35 ? randomGain : -randomLoss;
    } else if (entity.hasTag('vain')) {
        points = Math.random() < 0.1 ? randomGain : -randomLoss;
    } else if (entity.hasTag('rude')) {
        points = Math.random() < 0.15 ? randomGain : -randomLoss;
    } else if (entity.hasTag('germ_phobia')) {
        points = Math.random() < 0.01 ? randomGain : -randomLoss;
    } else if (entity.hasTag('weird')) {
        points = Math.random() < 0.25 ? randomGain : -randomLoss;
    } else if (entity.hasTag('smiling')) {
        points = Math.random() < 0.55 ? randomGain : -randomLoss;
    } else if (entity.hasTag('joker')) {
        points = Math.random() < 0.45 ? randomGain : -randomLoss;
    } else if (entity.hasTag('bored')) {
        points = Math.random() < 0.25 ? randomGain : -randomLoss;
    } else if (entity.hasTag('intelligent')) {
        points = Math.random() < 0.16 ? randomGain : -randomLoss;
    }
    entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);
    if (points > 0) {
        player.playSound('mob.villager.earn_love_points', soundOptions);
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "message.hug.${randomMessage}"}]}`);
        entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.gain.points"},{"text": " ${points} "}, {"translate": "translate.points.text"}]}`);
        entity.runCommand(`playanimation @s hug`);
    } else if (points < 0) {
        player.playSound('mob.villager.lose_love_points', soundOptions);
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "message.hug.fail.${randomMessage}"}]}`);
        entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
        entity.runCommand(`playanimation @s no`);
    }
}
function hugParent(player, entity) {
    let points = 0;
    const randomMessage = Math.floor(Math.random() * 10) + 1;
    const randomGain = Math.floor(Math.random() * 11) + 1;
    const randomLoss = Math.floor(Math.random() * 5) + 1;

    if (entity.hasTag('kind')) {
        points = Math.random() < 0.85 ? randomGain : -randomLoss;
    } else if (entity.hasTag('shy')) {
        points = Math.random() < 0.15 ? randomGain : -randomLoss;
    } else if (entity.hasTag('brave')) {
        points = Math.random() < 0.35 ? randomGain : -randomLoss;
    } else if (entity.hasTag('vain')) {
        points = Math.random() < 0.1 ? randomGain : -randomLoss;
    } else if (entity.hasTag('rude')) {
        points = Math.random() < 0.15 ? randomGain : -randomLoss;
    } else if (entity.hasTag('germ_phobia')) {
        points = Math.random() < 0.01 ? randomGain : -randomLoss;
    } else if (entity.hasTag('weird')) {
        points = Math.random() < 0.25 ? randomGain : -randomLoss;
    } else if (entity.hasTag('smiling')) {
        points = Math.random() < 0.55 ? randomGain : -randomLoss;
    } else if (entity.hasTag('joker')) {
        points = Math.random() < 0.45 ? randomGain : -randomLoss;
    } else if (entity.hasTag('bored')) {
        points = Math.random() < 0.25 ? randomGain : -randomLoss;
    } else if (entity.hasTag('intelligent')) {
        points = Math.random() < 0.16 ? randomGain : -randomLoss;
    }
    entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);
    if (points > 0) {
        player.playSound('mob.villager.earn_love_points', soundOptions);
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "messageParent.hug.${randomMessage}"}]}`);
        entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.gain.points"},{"text": " ${points} "}, {"translate": "translate.points.text"}]}`);
    } else if (points < 0) {
        player.playSound('mob.villager.lose_love_points', soundOptions);
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "messageParent.hug.fail.${randomMessage}"}]}`);
        entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
    }
}
function story(player, entity) {
    let points = 0;
    const randomMessage = Math.floor(Math.random() * 10) + 1; // Número aleatorio entre 1 y 10 para seleccionar el mensaje
    const randomGain = Math.floor(Math.random() * 11) + 1; // Número aleatorio entre 1 y 15 para la ganancia máxima
    const randomLoss = Math.floor(Math.random() * 5) + 1; // Número aleatorio entre 1 y 5 para la pérdida máxima

    if (entity.hasComponent('is_tamed') && entity.hasTag(`married_${player.name}`)) {
        points = Math.random() < 0.9 ? randomGain : -randomLoss;
    } else if (entity.hasTag('kind')) {
        points = Math.random() < 0.25 ? randomGain : -randomLoss;
    } else if (entity.hasTag('shy')) {
        points = Math.random() < 0.75 ? randomGain : -randomLoss;
    } else if (entity.hasTag('brave')) {
        points = Math.random() < 0.8 ? randomGain : -randomLoss;
    } else if (entity.hasTag('vain')) {
        points = Math.random() < 0.6 ? randomGain : -randomLoss;
    } else if (entity.hasTag('rude')) {
        points = Math.random() < 0.7 ? randomGain : -randomLoss;
    } else if (entity.hasTag('germ_phobia')) {
        points = Math.random() < 0.8 ? randomGain : -randomLoss;
    } else if (entity.hasTag('weird')) {
        points = Math.random() < 0.8 ? randomGain : -randomLoss;
    } else if (entity.hasTag('smiling')) {
        points = Math.random() < 0.5 ? randomGain : -randomLoss;
    } else if (entity.hasTag('joker')) {
        points = Math.random() < 0.15 ? randomGain : -randomLoss;
    } else if (entity.hasTag('bored')) {
        points = Math.random() < 0.15 ? randomGain : -randomLoss;
    } else if (entity.hasTag('intelligent')) {
        points = Math.random() < 0.6 ? randomGain : -randomLoss;
    }
    entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);
    if (points > 0) {
        player.playSound('mob.villager.earn_love_points', soundOptions);
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "message.story.${randomMessage}"}]}`);
        entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.gain.points"},{"text": " ${points} "}, {"translate": "translate.points.text"}]}`);
        entity.runCommand(`playanimation @s yes`);
    } else if (points < 0) {
        player.playSound('mob.villager.lose_love_points', soundOptions);
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "message.story.fail.${randomMessage}"}]}`);
        entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
        entity.runCommand(`playanimation @s no`);
    }
}
function storyParent(player, entity) {
    let points = 0;
    const randomMessage = Math.floor(Math.random() * 10) + 1; // Número aleatorio entre 1 y 10 para seleccionar el mensaje
    const randomGain = Math.floor(Math.random() * 11) + 1; // Número aleatorio entre 1 y 15 para la ganancia máxima
    const randomLoss = Math.floor(Math.random() * 5) + 1; // Número aleatorio entre 1 y 5 para la pérdida máxima

    if (entity.hasTag('kind')) {
        points = Math.random() < 0.25 ? randomGain : -randomLoss;
    } else if (entity.hasTag('shy')) {
        points = Math.random() < 0.85 ? randomGain : -randomLoss;
    } else if (entity.hasTag('brave')) {
        points = Math.random() < 0.85 ? randomGain : -randomLoss;
    } else if (entity.hasTag('vain')) {
        points = Math.random() < 0.6 ? randomGain : -randomLoss;
    } else if (entity.hasTag('rude')) {
        points = Math.random() < 0.75 ? randomGain : -randomLoss;
    } else if (entity.hasTag('germ_phobia')) {
        points = Math.random() < 0.31 ? randomGain : -randomLoss;
    } else if (entity.hasTag('weird')) {
        points = Math.random() < 0.85 ? randomGain : -randomLoss;
    } else if (entity.hasTag('smiling')) {
        points = Math.random() < 0.5 ? randomGain : -randomLoss;
    } else if (entity.hasTag('joker')) {
        points = Math.random() < 0.15 ? randomGain : -randomLoss;
    } else if (entity.hasTag('bored')) {
        points = Math.random() < 0.15 ? randomGain : -randomLoss;
    } else if (entity.hasTag('intelligent')) {
        points = Math.random() < 0.6 ? randomGain : -randomLoss;
    }
    entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);
    if (points > 0) {
        player.playSound('mob.villager.earn_love_points', soundOptions);
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "messageParent.story.${randomMessage}"}]}`);
        entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.gain.points"},{"text": " ${points} "}, {"translate": "translate.points.text"}]}`);
    } else if (points < 0) {
        player.playSound('mob.villager.lose_love_points', soundOptions);
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "messageParent.story.fail.${randomMessage}"}]}`);
        entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
    }
}
function flirt(player, entity) {
    let points = 0;
    const randomMessage = Math.floor(Math.random() * 10) + 1; // Número aleatorio entre 1 y 10 para seleccionar el mensaje
    const randomGain = Math.floor(Math.random() * 11) + 1; // Número aleatorio entre 1 y 15 para la ganancia máxima
    const randomLoss = Math.floor(Math.random() * 5) + 1; // Número aleatorio entre 1 y 5 para la pérdida máxima
    if (entity.hasComponent('is_tamed') && entity.hasTag(`married_${player.name}`)) {
        points = Math.random() < 0.9 ? randomGain : -randomLoss;
    } else if (entity.hasTag('strong')) {
        points = Math.random() < 0.7 ? randomGain : -randomLoss;
    } else if (entity.hasTag('beautiful')) {
        points = Math.random() < 0.8 ? randomGain : -randomLoss;
    } else if (entity.hasTag('unattractive')) {
        points = Math.random() < 0.75 ? randomGain : -randomLoss;
    } else if (entity.hasTag('agile')) {
        points = Math.random() < 0.4 ? randomGain : -randomLoss;
    } else if (entity.hasTag('tall')) {
        points = Math.random() < 0.65 ? randomGain : -randomLoss;
    } else if (entity.hasTag('short')) {
        points = Math.random() < 0.3 ? randomGain : -randomLoss;
    } else if (entity.hasTag('slim')) {
        points = Math.random() < 0.4 ? randomGain : -randomLoss;
    } else if (entity.hasTag('fat')) {
        points = Math.random() < 0.6 ? randomGain : -randomLoss;
    } else if (entity.hasTag('clumsy')) {
        points = Math.random() < 0.65 ? randomGain : -randomLoss;
    }
    entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);
    if (points > 0) {
        player.playSound('mob.villager.earn_love_points', soundOptions);
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "message.flirt.${randomMessage}"}]}`);
        entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.gain.points"},{"text": " ${points} "}, {"translate": "translate.points.text"}]}`);
        entity.runCommand(`playanimation @s yes`);
    } else if (points < 0) {
        player.playSound('mob.villager.lose_love_points', soundOptions);
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "message.flirt.fail.${randomMessage}"}]}`);
        entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
        entity.runCommand(`playanimation @s no`);
    }
}
function handshake(player, entity) {
    let points = 0;
    const randomMessage = Math.floor(Math.random() * 10) + 1; // Número aleatorio entre 1 y 10 para seleccionar el mensaje
    const randomGain = Math.floor(Math.random() * 11) + 1; // Número aleatorio entre 1 y 15 para la ganancia máxima
    const randomLoss = Math.floor(Math.random() * 5) + 1; // Número aleatorio entre 1 y 5 para la pérdida máxima

    if (entity.hasComponent('is_tamed') && entity.hasTag(`married_${player.name}`)) {
        points = Math.random() < 0.9 ? randomGain : -randomLoss;
    } else if (entity.hasTag('kind')) {
        points = Math.random() < 0.75 ? randomGain : -randomLoss;
    } else if (entity.hasTag('shy')) {
        points = Math.random() < 0.1 ? randomGain : -randomLoss;
    } else if (entity.hasTag('brave')) {
        points = Math.random() < 0.25 ? randomGain : -randomLoss;
    } else if (entity.hasTag('vain')) {
        points = Math.random() < 0.1 ? randomGain : -randomLoss;
    } else if (entity.hasTag('rude')) {
        points = Math.random() < 0.65 ? randomGain : -randomLoss;
    } else if (entity.hasTag('germ_phobia')) {
        points = Math.random() < 0.01 ? randomGain : -randomLoss;
    } else if (entity.hasTag('weird')) {
        points = Math.random() < 0.1 ? randomGain : -randomLoss;
    } else if (entity.hasTag('smiling')) {
        points = Math.random() < 0.8 ? randomGain : -randomLoss;
    } else if (entity.hasTag('joker')) {
        points = Math.random() < 0.5 ? randomGain : -randomLoss;
    } else if (entity.hasTag('bored')) {
        points = Math.random() < 0.7 ? randomGain : -randomLoss;
    } else if (entity.hasTag('intelligent')) {
        points = Math.random() < 0.7 ? randomGain : -randomLoss;
    }
    entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);
    if (points > 0) {
        player.playSound('mob.villager.earn_love_points', soundOptions);
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "message.handshake.${randomMessage}"}]}`);
        entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.gain.points"},{"text": " ${points} "}, {"translate": "translate.points.text"}]}`);
        entity.runCommand(`playanimation @s handshake`);
    } else if (points < 0) {
        player.playSound('mob.villager.lose_love_points', soundOptions);
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "message.handshake.fail.${randomMessage}"}]}`);
        entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
        entity.runCommand(`playanimation @s no`);
    }
}
function kiss(player, entity) {
    let points = 0;
    const randomMessage = Math.floor(Math.random() * 10) + 1; // Número aleatorio entre 1 y 10 para seleccionar el mensaje
    const randomGain = Math.floor(Math.random() * 11) + 1; // Número aleatorio entre 1 y 15 para la ganancia máxima
    const randomLoss = Math.floor(Math.random() * 5) + 1; // Número aleatorio entre 1 y 5 para la pérdida máxima
    if (entity.hasComponent('is_tamed') && entity.hasTag(`married_${player.name}`)) {
        points = Math.random() < 0.9 ? randomGain : -randomLoss;
    } else if (entity.hasTag('strong')) {
        points = Math.random() < 0.5 ? randomGain : -randomLoss;
    } else if (entity.hasTag('beautiful')) {
        points = Math.random() < 0.3 ? randomGain : -randomLoss;
    } else if (entity.hasTag('unattractive')) {
        points = Math.random() < 0.8 ? randomGain : -randomLoss;
    } else if (entity.hasTag('agile')) {
        points = Math.random() < 0.2 ? randomGain : -randomLoss;
    } else if (entity.hasTag('tall')) {
        points = Math.random() < 0.3 ? randomGain : -randomLoss;
    } else if (entity.hasTag('short')) {
        points = Math.random() < 0.6 ? randomGain : -randomLoss;
    } else if (entity.hasTag('slim')) {
        points = Math.random() < 0.5 ? randomGain : -randomLoss;
    } else if (entity.hasTag('fat')) {
        points = Math.random() < 0.6 ? randomGain : -randomLoss;
    } else if (entity.hasTag('clumsy')) {
        points = Math.random() < 0.4 ? randomGain : -randomLoss;
    }
    entity.runCommand(`execute as @s[scores={"PF_${player.name}_hearts"=0..100}] run scoreboard players add @s "PF_${player.name}_hearts" ${points}`);
    if (points > 0) {
        player.playSound('mob.villager.earn_love_points', soundOptions);
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "message.kiss.${randomMessage}"}]}`);
        entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.gain.points"},{"text": " ${points} "}, {"translate": "translate.points.text"}]}`);
        entity.runCommand(`playanimation @s kiss`);
    } else if (points < 0) {
        player.playSound('mob.villager.lose_love_points', soundOptions);
        entity.runCommand(`tellraw "${player.name}" {"rawtext": [{"selector": "@e[type=pf:humanoid,r=2,c=1]"}, {"translate": "message.kiss.fail.${randomMessage}"}]}`);
        entity.runCommand(`titleraw "${player.name}" actionbar {"rawtext": [{"translate": "player.loss.points"},{"text": " ${-points} "}, {"translate": "translate.points.text"}]}`);
        entity.runCommand(`playanimation @s no`);
    }
}