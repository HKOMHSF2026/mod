import {system, world, ItemStack, PlayerPlaceBlockAfterEvent, Entity, Player, Block } from "@minecraft/server"
import EntityChecker from "./snailstudios_xp_mob_spawner.js";
import { JsonDatabase } from "./con-database.js"
import { ActionFormData,MessageFormData,ModalFormData } from "@minecraft/server-ui"





const openForms = new Map();


const playerfirstLoadWorld = new JsonDatabase('playerfirstLoadWorld');

  
let firstLoadWorld = false;

//after the player join they're given a book and a tag
world.afterEvents.playerSpawn.subscribe(async (eventData) => {
		const playerId = eventData.player;
		const returnPlayerLoaded = playerfirstLoadWorld.get("snailstudiosfirstloadgame");

		playerId.runCommandAsync('execute at @a[tag=!snailstudios_tutorial] run structure load snailstudios_xp:book ~ ~ ~');
		playerId.runCommandAsync('execute at @a[tag=!snailstudios_tutorial] run tag @a[tag=!snailstudios_tutorial] add snailstudios_tutorial');
		if (returnPlayerLoaded !== true) {
			world.sendMessage('§f{§2XP Storage§f} §fAddon Loaded!');
			firstLoadWorld = true;
			playerfirstLoadWorld.set("snailstudiosfirstloadgame", firstLoadWorld);
		}
		}
  )


function checkAndModifyBlock() {
	for (const player of world.getAllPlayers()) {
		// Check if player is sneaking
		if (player.isSneaking) {
			// Define the coordinates for the block directly below the player
			const x = Math.floor(player.location.x);
			const y = Math.floor(player.location.y) - 1; // Adjust to get the block below
			const z = Math.floor(player.location.z);

			// Retrieve the block below the player
			const blockBelowPlayer = player.dimension.getBlock({
				x,
				y,
				z
			});

			const playerLevel = player.level;
			let playerLevelXpOrbs = player.getTotalXp();

			// Ensure block is defined before processing
			if (blockBelowPlayer.permutation !== undefined) {
				if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_0") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 7) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 7;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_1`);
						} else {}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_1") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 9) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 9;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_2`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_2") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 11) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 11;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_3`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_3") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 13) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 13;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_4`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_4") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 15) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 15;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_5`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_5") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 17) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 17;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_6`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_6") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 19) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 19;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_7`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_7") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 21) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 21;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_8`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_8") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 23) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 23;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_9`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_9") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 25) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 25;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_10`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_10") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 27) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 27;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_11`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_11") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 29) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 29;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_12`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_12") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 31) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 31;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_13`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_13") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 33) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 33;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_14`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_14") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 35) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 35;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_15`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_15") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 37) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 37;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_16`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_16") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 42) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 42;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_17`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_17") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 47) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 47;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_18`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_18") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 52) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 52;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_19`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_19") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 57) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 57;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_20`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_20") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 62) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 62;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_21`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_21") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 67) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 67;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_22`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_22") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 72) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 72;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_23`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_23") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 77) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 77;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_24`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_24") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 82) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 82;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_25`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_25") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 87) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 87;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_26`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_26") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 92) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 92;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_27`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_27") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 97) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 97;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_28`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_28") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 102) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 102;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_29`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_29") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 107) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 107;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_30`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_30") && playerLevel > 0) {
					// Handle block snailstudios_xp:snailstudios_iron_xp_storage_30
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_0") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 7) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 7;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_1`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_1") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 9) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 9;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_2`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_2") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 11) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 11;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_3`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_3") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 13) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 13;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_4`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_4") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 15) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 15;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_5`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_5") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 17) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 17;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_6`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_6") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 19) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 19;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_7`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_7") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 21) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 21;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_8`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_8") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 23) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 23;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_9`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_9") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 25) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 25;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_10`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_10") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 27) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 27;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_11`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_11") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 29) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 29;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_12`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_12") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 31) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 31;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_13`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_13") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 33) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 33;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_14`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_14") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 35) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 35;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_15`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_15") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 37) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 37;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_16`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_16") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 42) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 42;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_17`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_17") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 47) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 47;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_18`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_18") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 52) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 52;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_19`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_19") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 57) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 57;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_20`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_20") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 62) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 62;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_21`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_21") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 67) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 67;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_22`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_22") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 72) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 72;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_23`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_23") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 77) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 77;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_24`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_24") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 82) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 82;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_25`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_25") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 87) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 87;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_26`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_26") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 92) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 92;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_27`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_27") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 97) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 97;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_28`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_28") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 102) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 102;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_29`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_29") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 107) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 107;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_30`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_30") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 112) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 112;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_31`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_31") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 121) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 121;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_32`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_32") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 130) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 130;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_33`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_33") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 139) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 139;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_34`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_34") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 148) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 148;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_35`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_35") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 157) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 157;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_36`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_36") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 166) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 166;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_37`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_37") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 175) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 175;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_38`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_38") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 184) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 184;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_39`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_39") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 193) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 193;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_40`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_40") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 202) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 202;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_41`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_41") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 211) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 211;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_42`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_42") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 220) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 220;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_43`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_43") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 229) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 229;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_44`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_44") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 238) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 238;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_45`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_45") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 247) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 247;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_46`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_46") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 256) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 256;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_47`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_47") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 265) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 265;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_48`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_48") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 274) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 274;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_49`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_49") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 283) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 283;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_50`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_50") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 292) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 292;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_51`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_51") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 301) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 301;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_52`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_52") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 310) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 310;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_53`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_53") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 319) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 319;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_54`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_54") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 328) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 328;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_55`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_55") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 337) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 337;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_56`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_56") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 346) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 346;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_57`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_57") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 355) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 355;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_58`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_58") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 364) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 364;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_59`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_59") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 373) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 373;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_60`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_0") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 7) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 7;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_1`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_1") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 9) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 9;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_2`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_2") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 11) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 11;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_3`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_3") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 13) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 13;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_4`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_4") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 15) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 15;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_5`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_5") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 17) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 17;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_6`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_6") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 19) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 19;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_7`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_7") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 21) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 21;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_8`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_8") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 23) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 23;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_9`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_9") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 25) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 25;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_10`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_10") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 27) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 27;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_11`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_11") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 29) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 29;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_12`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_12") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 31) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 31;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_13`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_13") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 33) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 33;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_14`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_14") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 35) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 35;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_15`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_15") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 37) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 37;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_16`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_16") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 42) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 42;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_17`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_17") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 47) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 47;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_18`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_18") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 52) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 52;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_19`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_19") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 57) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 57;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_20`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_20") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 62) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 62;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_21`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_21") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 67) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 67;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_22`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_22") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 72) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 72;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_23`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_23") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 77) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 77;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_24`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_24") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 82) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 82;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_25`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_25") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 87) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 87;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_26`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_26") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 92) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 92;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_27`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_27") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 97) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 97;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_28`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_28") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 102) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 102;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_29`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_29") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 107) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 107;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_30`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_30") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 112) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 112;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_31`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_31") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 121) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 121;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_32`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_32") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 130) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 130;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_33`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_33") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 139) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 139;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_34`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_34") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 148) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 148;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_35`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_35") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 157) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 157;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_36`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_36") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 166) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 166;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_37`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_37") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 175) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 175;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_38`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_38") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 184) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 184;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_39`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_39") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 193) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 193;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_40`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_40") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 202) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 202;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_41`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_41") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 211) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 211;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_42`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_42") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 220) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 220;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_43`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_43") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 229) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 229;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_44`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_44") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 238) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 238;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_45`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_45") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 247) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 247;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_46`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_46") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 256) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 256;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_47`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_47") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 265) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 265;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_48`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_48") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 274) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 274;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_49`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_49") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 283) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 283;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_50`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_50") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 292) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 292;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_51`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_51") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 301) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 301;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_52`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_52") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 310) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 310;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_53`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_53") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 319) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 319;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_54`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_54") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 328) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 328;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_55`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_55") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 337) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 337;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_56`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_56") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 346) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 346;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_57`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_57") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 355) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 355;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_58`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_58") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 364) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 364;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_59`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_59") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 373) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 373;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_60`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_60") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 382) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 382;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_61`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_61") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 391) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 391;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_62`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_62") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 400) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 400;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_63`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_63") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 409) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 409;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_64`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_64") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 418) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 418;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_65`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_65") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 427) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 427;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_66`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_66") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 436) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 436;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_67`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_67") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 445) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 445;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_68`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_68") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 454) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 454;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_69`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_69") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 463) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 463;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_70`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_70") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 472) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 472;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_71`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_71") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 481) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 481;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_72`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_72") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 490) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 490;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_73`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_73") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 499) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 499;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_74`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_74") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 508) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 508;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_75`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_75") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 517) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 517;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_76`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_76") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 526) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 526;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_77`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_77") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 535) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 535;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_78`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_78") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 544) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 544;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_79`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_79") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 553) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 553;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_80`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_80") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 562) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 562;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_81`);
						}
					} else {
						return;
					}
				} else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_81") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 571) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 571;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_82`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_82") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 580) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 580;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_83`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_83") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 589) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 589;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_84`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_84") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 598) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 598;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_85`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_85") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 607) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 607;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_86`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_86") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 616) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 616;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_87`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_87") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 625) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 625;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_88`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_88") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 634) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 634;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_89`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_89") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 643) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 643;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_90`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_90") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 652) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 652;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_91`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_91") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 661) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 661;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_92`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_92") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 670) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 670;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_93`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_93") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 679) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 679;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_94`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_94") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 688) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 688;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_95`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_95") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 697) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 697;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_96`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_96") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 706) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 706;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_97`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_97") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 715) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 715;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_98`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_98") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 724) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 724;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_99`);
						}
					} else {
						return;
					}
				}
				
				
				else if (blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_99") && playerLevel > 0) {
					if (playerLevelXpOrbs >= 733) {
						player.addLevels(-1000)
						playerLevelXpOrbs -= 733;
						if (playerLevelXpOrbs >= 0) {
							player.addExperience(playerLevelXpOrbs)
							player.runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_100`);
						}
					} else {
						return;
					}
				} else {
					return;
				}
			} else {
				return;
			}
		}
	}
}
























function modifyBlock(player, blockLevel) {
	const playerLevel = player.getTotalXp();

	if (playerLevel > 0) {
		const newBlockLevel = blockLevel + 1;
		if (blockLevel < 30) {
			modifyBlockBelow(player, newBlockLevel);
		}
		// Deduct levels from the player
		deductPlayerLevels(player, playerLevel);
	} else {
		return;
	}
}

function modifyBlockBelow(player, newLevel) {
	player.runCommandAsync(`say hello`);
}

function deductPlayerLevels(player, levels) {
	player.runCommandAsync('xp -1L @s');
}

function runCheck() {
	system.runInterval(checkAndModifyBlock, 10);
}

// Start the loop
runCheck();














































//handles the placement of the brain
const playersDataBaseXP = new JsonDatabase('playersDataBaseXP');
const playersDataBaseDimension = new JsonDatabase('playersDataBaseDimension');
//handles the placement of the storage
const playersXpDataBase = new JsonDatabase('playersDataBaseXp');


export class XpStoragePlacedHandler {
    constructor(blockHandler) {
        this.storedLocationOfXp = null;
		
        this.blockHandler = blockHandler;
        this.onBlockPlaced = this.onBlockPlaced.bind(this);
    }

    getStoredLocationOfXp() {
        return this.storedLocationOfXp;
    }

	resetLocationOfMainXp() {
        this.storedLocationOfXp = null;
		playersXpDataBase.clear("mainXpStorageLocation");
    }

	handleMainXpBreak(xpData) {
			const breakXpBlockLocation = xpData.block.location;
			const breakXpBlockPlayer = xpData.player;
	
				if (this.storedLocationOfXp &&
					breakXpBlockLocation.x === this.storedLocationOfXp.x &&
					breakXpBlockLocation.y === this.storedLocationOfXp.y &&
					breakXpBlockLocation.z === this.storedLocationOfXp.z) {
					toggleButton = false;
					breakXpBlockPlayer.sendMessage("Destroyed main xp storage!");
					playersXpDataBase.clear("mainXpStorageLocation");
					this.storedLocationOfXp = null;
				} else {
			}
		}

		

    onBlockPlaced(xpData) {
        const xpBlock = xpData.block;
        const xpLocation = xpData.block.location;

		if (
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_0') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_1') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_2') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_3') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_4') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_5') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_6') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_7') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_8') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_9') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_10') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_11') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_12') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_13') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_14') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_15') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_16') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_17') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_18') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_19') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_20') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_21') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_22') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_23') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_24') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_25') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_26') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_27') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_28') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_29') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_30') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_0') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_1') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_2') || 
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_3') || 
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_4') || 
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_5') || 
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_6') || 
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_7') || 
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_8') || 
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_9') || 
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_10') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_11') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_12') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_13') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_14') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_15') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_16') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_17') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_18') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_19') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_20') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_21') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_22') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_23') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_24') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_25') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_26') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_27') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_28') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_29') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_30') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_31') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_32') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_33') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_34') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_35') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_36') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_37') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_38') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_39') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_40') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_41') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_42') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_43') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_44') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_45') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_46') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_47') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_48') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_49') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_50') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_51') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_52') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_53') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_54') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_55') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_56') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_57') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_58') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_59') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_60') ||
		xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_0') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_1') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_2') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_3') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_4') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_5') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_6') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_7') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_8') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_9') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_10') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_11') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_12') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_13') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_14') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_15') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_16') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_17') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_18') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_19') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_20') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_21') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_22') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_23') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_24') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_25') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_26') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_27') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_28') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_29') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_30') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_31') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_32') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_33') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_34') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_35') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_36') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_37') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_38') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_39') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_40') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_41') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_42') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_43') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_44') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_45') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_46') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_47') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_48') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_49') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_50') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_51') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_52') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_53') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_54') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_55') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_56') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_57') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_58') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_59') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_60') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_61') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_62') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_63') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_64') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_65') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_66') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_67') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_68') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_69') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_70') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_71') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_72') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_73') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_74') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_75') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_76') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_77') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_78') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_79') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_80') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_81') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_82') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_83') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_84') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_85') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_86') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_87') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_88') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_89') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_90') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_91') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_92') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_93') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_94') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_95') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_96') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_97') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_98') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_99') ||
        xpBlock.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_100')) {
            const brainBlockCoords = this.blockHandler.getStoredLocation();

            if (brainBlockCoords !== null && brainBlockCoords !== undefined) {
                const distance = this.calculateDistance(xpLocation, brainBlockCoords);

                if (distance <= 20 && this.storedLocationOfXp === null || distance <= 20 && this.storedLocationOfXp === undefined) {
					const xpMainDimension = blockHandler.getStoredDimension();
                    playersXpDataBase.set("mainXpStorageLocation", xpLocation);
                    this.storedLocationOfXp = xpLocation;
					world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_main_storage_placed @a ${xpLocation.x} ${xpLocation.y + 1} ${xpLocation.z}`)
					world.getDimension(xpMainDimension).runCommandAsync(`particle snailstudios_xp:link_xp_particle ${xpLocation.x} ${xpLocation.y + 1} ${xpLocation.z}`)
					world.getDimension(xpMainDimension).runCommandAsync(`particle snailstudios_xp:link_xp_particle ${brainBlockCoords.x} ${brainBlockCoords.y + 1} ${brainBlockCoords.z}`)
                } else {
                }
            } else {
            }
        }
    }
	

    calculateDistance(coords1, coords2) {
        const dx = coords1.x - coords2.x;
        const dy = coords1.y - coords2.y;
        const dz = coords1.z - coords2.z;

        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

	handlePlayerJoinXp(XpDataJoin) {

		const mainXpStorageLocation = playersXpDataBase.get("mainXpStorageLocation");

		if (this.storedLocationOfXp = null) {
		} else {
			this.storedLocationOfXp = mainXpStorageLocation
		}
	}
}




































export class BlockHandler {
	constructor() {
		this.storedLocationOfFirstBlock = null;
		this.storedDimensionOfFirstBlock = null;
		
	}

	getStoredLocation() {
		return this.storedLocationOfFirstBlock;
	}

	getStoredDimension() {
		return this.storedDimensionOfFirstBlock;
	}

	resetLocationOfMainSmartSpawner() {
		this.storedLocationOfFirstBlock = null;
		this.storedDimensionOfFirstBlock = null;
		playersDataBaseXP.clear("mainBrainLocation");
		playersDataBaseXP.clear("mainDimension");
	}




	handleBreakBlock(data) {
		const breakBlockLocation = data.block.location;
		const breakBlockPlayer = data.player;

		if (this.storedLocationOfFirstBlock &&
			breakBlockLocation.x === this.storedLocationOfFirstBlock.x &&
			breakBlockLocation.y === this.storedLocationOfFirstBlock.y &&
			breakBlockLocation.z === this.storedLocationOfFirstBlock.z) {
			breakBlockPlayer.sendMessage("Destroyed main smart spawner!");
			playersDataBaseXP.clear("mainBrainLocation");
			playersXpDataBase.clear("mainXpStorageLocation");
			playersDataBaseXP.clear("mainDimension");
			this.storedLocationOfFirstBlock = null;
			this.storedDimensionOfFirstBlock = null;
		} else {
		}
	}



	handlePlaceBlock(eventData) {

		const player = eventData.player;
		const dimension = eventData.player.dimension.id;
		const location = eventData.block.location;
		const block = eventData.block;

		// Check if the placed block is of the specified type
		if (block.permutation.matches('snailstudios_xp:snailstudios_xp_grinder_brain')) {
			// Check if the block has already been placed in the world
			if (this.storedLocationOfFirstBlock === null || this.storedLocationOfFirstBlock === undefined) {
				// No block has been placed yet, store the location
				playersDataBaseXP.set("mainBrainLocation", location);
				this.storedLocationOfFirstBlock = location;
				playersDataBaseDimension.set("mainDimension", dimension);
				this.storedDimensionOfFirstBlock = dimension;
				world.getDimension(dimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_smart_spawner_placed @a ${location.x} ${location.y + 1} ${location.z}`)
			} else if (this.storedLocationOfFirstBlock && (location.x !== this.storedLocationOfFirstBlock.x ||
					location.y !== this.storedLocationOfFirstBlock.y ||
					location.z !== this.storedLocationOfFirstBlock.z)) {
			}
		}
	}



	handlePlayerJoin(eventData) {

		const mainBrainLocation = playersDataBaseXP.get("mainBrainLocation");
		const mainBrainDimension = playersDataBaseDimension.get("mainDimension");

		if (this.storedLocationOfFirstBlock = null) {
		} else {
			this.storedLocationOfFirstBlock = mainBrainLocation
			this.storedDimensionOfFirstBlock = mainBrainDimension
		}
	}
}
































































//Global variables
let foundBlock = null;
let intervalId;
let drainXp = null;
let alwaysFalseToggle = false;
let locationKey;
let playerDimension;

// Boolean variable to track if a form is currently open
let isFormOpen = false;

// Boolean variable to track if the interval is running
let isIntervalRunning = false;

// Subscribe to item use event with a regular function
world.afterEvents.itemUse.subscribe((event) => {
    const item = event.itemStack;
    const player = event.source;
	playerDimension = event.source.dimension.id;

        if (item?.typeId === "snailstudios_xp:xp_wrench") {
            // Check if a form is already open or the interval is running
            if (openForms.has(locationKey) || isIntervalRunning) {
                player.sendMessage("Another operation is in progress.");
                return;
            }

            // Get player's location
            const playerLocation = player.location;

            // Ensure player location exists
            if (playerLocation) {
                const x = Math.floor(playerLocation.x);
                const yStart = Math.floor(playerLocation.y) + 1; // Start from 2 blocks above the player's location
                const yEnd = yStart + 4; // Check up to 4 blocks above the player's location
                const z = Math.floor(playerLocation.z);

				locationKey = `${x}:${z}`;

                // Check for blocks within the specified y-coordinate range
                for (let y = yStart; y <= yEnd; y++) {
                    const blockAbovePlayer = world.getDimension(playerDimension).getBlock({
                        x,
                        y,
                        z
                    });

                    // Check if the block above the player's location exists and matches the desired type
                    if (blockAbovePlayer.permutation.matches('snailstudios_xp:xp_faucet')) {
                        foundBlock = blockAbovePlayer; // Store the found block
                        const uiMendingForm = new ModalFormData();

                        uiMendingForm.title("Make it rain!");
                        // Set the initial state of the toggle button based on the current value of toggleButton
                        uiMendingForm.toggle("Drop 1 level of xp!", alwaysFalseToggle);

                        uiMendingForm.show(player).then((formData) => {

                            if (formData.canceled) {
								openForms.delete(locationKey, true);
                                return;
                            }

                            if (formData.formValues[0] === false) {
								openForms.delete(locationKey, true);
                                // Do something if toggle button is false
                            } else {
                                // Do timer and return the block above location
                                getStorageAboveFaucet();
                            }
                        }).catch(e => {
							openForms.delete(locationKey, true);
                            console.error(e, e.stack);
                        });

                        isFormOpen = true; // Set the form open status to true
						openForms.set(locationKey, true);
                        break; // Exit the loop once the block is found
                    }
                }
            }
        }
});

// Function to get the block directly above the faucet block
function getStorageAboveFaucet() {
    if (foundBlock) {
        const x = Math.floor(foundBlock.x);
        const y = Math.floor(foundBlock.y) + 1; // Get block directly above the faucet block
        const z = Math.floor(foundBlock.z);

        const blockAboveFaucet = world.getDimension(playerDimension).getBlock({
            x,
            y,
            z
        });

        if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_30')) {
            drainXp = 107; // Set drainXp value

            world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_29`);

            // Start the interval only if it's not already running
            if (!isIntervalRunning) {
                intervalId = system.runInterval(decreaseDrainXp, 1);
                isIntervalRunning = true;
            }
        } else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_29')) {
            drainXp = 102; // Set drainXp value

            world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_28`);

            // Start the interval only if it's not already running
            if (!isIntervalRunning) {
                intervalId = system.runInterval(decreaseDrainXp, 1);
                isIntervalRunning = true;
            }
        }
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_28')) {
			drainXp = 97
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_27`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_27')) {
			drainXp = 92
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_26`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_26')) {
			drainXp = 87
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_25`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_25')) {
			drainXp = 82
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_24`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_24')) {
			drainXp = 77
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_23`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_23')) {
			drainXp = 72
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_22`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_22')) {
			drainXp = 67
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_21`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_21')) {
			drainXp = 62
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_20`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_20')) {
			drainXp = 57
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_19`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_19')) {
			drainXp = 52
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_18`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_18')) {
			drainXp = 47
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_17`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_17')) {
			drainXp = 42
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_16`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_16')) {
			drainXp = 37
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_15`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_15')) {
			drainXp = 35
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_14`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_14')) {
			drainXp = 33
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_13`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_13')) {
			drainXp = 31
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_12`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_12')) {
			drainXp = 29
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_11`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_11')) {
			drainXp = 27
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_10`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_10')) {
			drainXp = 25
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_9`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_9')) {
			drainXp = 23
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_8`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_8')) {
			drainXp = 21
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_7`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_7')) {
			drainXp = 19
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_6`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_6')) {
			drainXp = 17
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_5`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_5')) {
			drainXp = 15
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_4`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_4')) {
			drainXp = 13
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_3`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_3')) {
			drainXp = 11
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_2`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_2')) {
			drainXp = 9
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_1`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_iron_xp_storage_1')) {
			drainXp = 7
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_iron_xp_storage_0`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		} 

		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_100')) {
			drainXp = 733
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_99`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_99')) {
			drainXp = 724
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_98`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_98')) {
			drainXp = 715
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_97`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_97')) {
			drainXp = 706
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_96`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_96')) {
			drainXp = 697
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_95`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_95')) {
			drainXp = 688
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_94`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_94')) {
			drainXp = 679
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_93`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_93')) {
			drainXp = 670
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_92`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_92')) {
			drainXp = 661
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_91`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_91')) {
			drainXp = 652
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_90`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_90')) {
			drainXp = 643
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_89`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_89')) {
			drainXp = 634
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_88`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_88')) {
			drainXp = 625
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_87`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_87')) {
			drainXp = 616
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_86`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_86')) {
			drainXp = 607
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_85`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_85')) {
			drainXp = 598
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_84`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_84')) {
			drainXp = 589
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_83`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_83')) {
			drainXp = 580
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_82`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_82')) {
			drainXp = 571
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_81`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_81')) {
			drainXp = 562
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_80`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}

		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_80')) {
			drainXp = 553
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_79`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_79')) {
			drainXp = 544
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_78`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_78')) {
			drainXp = 535
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_77`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_77')) {
			drainXp = 526
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_76`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_76')) {
			drainXp = 517
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_75`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_75')) {
			drainXp = 508
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_74`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_74')) {
			drainXp = 499
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_73`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_73')) {
			drainXp = 490
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_72`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_72')) {
			drainXp = 481
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_71`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_71')) {
			drainXp = 472
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_70`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_70')) {
			drainXp = 463
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_69`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_69')) {
			drainXp = 454
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_68`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_68')) {
			drainXp = 445
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_67`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_67')) {
			drainXp = 436
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_66`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_66')) {
			drainXp = 427
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_65`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_65')) {
			drainXp = 418
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_64`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_64')) {
			drainXp = 409
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_63`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_63')) {
			drainXp = 400
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_62`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_62')) {
			drainXp = 391
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_61`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_61')) {
			drainXp = 382
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_60`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}

		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_60')) {
			drainXp = 373
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_59`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_59')) {
			drainXp = 364
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_58`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_58')) {
			drainXp = 355
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_57`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_57')) {
			drainXp = 346
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_56`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_56')) {
			drainXp = 337
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_55`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_55')) {
			drainXp = 328
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_54`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_54')) {
			drainXp = 319
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_53`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_53')) {
			drainXp = 310
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_52`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_52')) {
			drainXp = 301
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_51`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_51')) {
			drainXp = 292
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_50`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_50')) {
			drainXp = 283
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_49`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_49')) {
			drainXp = 274
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_48`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_48')) {
			drainXp = 265
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_47`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_47')) {
			drainXp = 256
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_46`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_46')) {
			drainXp = 247
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_45`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_45')) {
			drainXp = 238
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_44`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_44')) {
			drainXp = 229
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_43`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_43')) {
			drainXp = 220
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_42`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_42')) {
			drainXp = 211
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_41`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_41')) {
			drainXp = 202
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_40`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}

		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_40')) {
			drainXp = 193
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_39`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_39')) {
			drainXp = 184
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_38`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_38')) {
			drainXp = 175
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_37`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_37')) {
			drainXp = 166
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_36`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_36')) {
			drainXp = 157
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_35`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_35')) {
			drainXp = 148
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_34`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_34')) {
			drainXp = 139
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_33`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_33')) {
			drainXp = 130
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_32`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_32')) {
			drainXp = 121
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_31`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_31')) {
			drainXp = 112
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_30`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_30')) {
			drainXp = 107
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_29`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_29')) {
			drainXp = 102
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_28`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_28')) {
			drainXp = 97
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_27`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_27')) {
			drainXp = 92
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_26`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_26')) {
			drainXp = 87
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_25`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_25')) {
			drainXp = 82
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_24`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_24')) {
			drainXp = 77
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_23`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_23')) {
			drainXp = 77
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_22`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_22')) {
			drainXp = 67
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_21`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_21')) {
			drainXp = 62
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_20`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}

		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_20')) {
			drainXp = 57
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_19`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_19')) {
			drainXp = 52
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_18`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_18')) {
			drainXp = 47
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_17`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_17')) {
			drainXp = 42
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_16`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_16')) {
			drainXp = 37
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_15`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_15')) {
			drainXp = 35
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_14`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_14')) {
			drainXp = 33
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_13`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_13')) {
			drainXp = 31
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_12`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_12')) {
			drainXp = 29
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_11`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_11')) {
			drainXp = 27
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_10`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_10')) {
			drainXp = 25
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_9`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_9')) {
			drainXp = 23
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_8`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_8')) {
			drainXp = 21
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_7`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_7')) {
			drainXp = 19
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_6`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_6')) {
			drainXp = 17
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_5`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_5')) {
			drainXp = 15
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_4`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_4')) {
			drainXp = 13
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_3`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_3')) {
			drainXp = 11
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_2`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_2')) {
			drainXp = 9
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_1`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_netherite_xp_storage_1')) {
			drainXp = 7
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_netherite_xp_storage_0`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}

		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_60')) {
			drainXp = 373
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_59`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_59')) {
			drainXp = 364
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_58`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_58')) {
			drainXp = 355
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_57`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_57')) {
			drainXp = 346
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_56`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_56')) {
			drainXp = 337
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_55`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_55')) {
			drainXp = 328
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_54`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_54')) {
			drainXp = 319
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_53`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_53')) {
			drainXp = 310
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_52`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_52')) {
			drainXp = 301
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_51`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_51')) {
			drainXp = 292
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_50`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_50')) {
			drainXp = 283
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_49`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_49')) {
			drainXp = 274
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_48`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_48')) {
			drainXp = 265
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_47`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_47')) {
			drainXp = 256
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_46`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_46')) {
			drainXp = 247
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_45`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_45')) {
			drainXp = 238
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_44`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_44')) {
			drainXp = 229
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_43`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_43')) {
			drainXp = 220
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_42`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_42')) {
			drainXp = 211
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_41`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_41')) {
			drainXp = 202
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_40`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_40')) {
			drainXp = 193
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_39`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_39')) {
			drainXp = 184
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_38`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_38')) {
			drainXp = 175
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_37`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_37')) {
			drainXp = 166
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_36`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_36')) {
			drainXp = 157
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_35`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_35')) {
			drainXp = 148
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_34`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_34')) {
			drainXp = 139
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_33`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_33')) {
			drainXp = 130
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_32`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_32')) {
			drainXp = 121
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_31`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_31')) {
			drainXp = 112
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_30`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_30')) {
			drainXp = 107
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_29`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_29')) {
			drainXp = 102
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_28`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_28')) {
			drainXp = 97
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_27`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_27')) {
			drainXp = 92
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_26`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_26')) {
			drainXp = 87
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_25`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_25')) {
			drainXp = 82
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_24`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_24')) {
			drainXp = 77
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_23`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_23')) {
			drainXp = 72
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_22`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_22')) {
			drainXp = 67
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_21`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_21')) {
			drainXp = 62
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_20`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_20')) {
			drainXp = 57
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_19`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_19')) {
			drainXp = 52
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_18`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_18')) {
			drainXp = 47
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_17`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_17')) {
			drainXp = 42
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_16`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_16')) {
			drainXp = 37
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_15`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_15')) {
			drainXp = 35
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_14`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_14')) {
			drainXp = 33
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_13`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_13')) {
			drainXp = 31
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_12`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_12')) {
			drainXp = 29
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_11`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_11')) {
			drainXp = 27
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_10`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_10')) {
			drainXp = 25
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_9`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_9')) {
			drainXp = 23
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_8`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_8')) {
			drainXp = 21
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_7`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_7')) {
			drainXp = 19
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_6`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_6')) {
			drainXp = 17
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_5`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_5')) {
			drainXp = 15
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_4`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_4')) {
			drainXp = 13
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_3`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_3')) {
			drainXp = 11
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_2`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_2')) {
			drainXp = 9
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_1`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		
		else if (blockAboveFaucet.permutation.matches('snailstudios_xp:snailstudios_gold_xp_storage_1')) {
			drainXp = 7
			world.getDimension(playerDimension).runCommandAsync(`setblock ${x} ${y} ${z} snailstudios_xp:snailstudios_gold_xp_storage_0`)
		
			if (!isIntervalRunning) {
				intervalId = system.runInterval(decreaseDrainXp, 1)
				isIntervalRunning = true;
			}
		}
		
		 else {
            world.sendMessage("No valid storage block found above faucet block.");
        }
    } else {
        world.sendMessage("Faucet block not found.");
    }
}

function decreaseDrainXp() {
    const checkFaucetExistStill = world.getDimension(playerDimension).getBlock(foundBlock);

    if (drainXp > 0 && checkFaucetExistStill.permutation.matches('snailstudios_xp:xp_faucet')) {
        drainXp--;
        world.getDimension(playerDimension).runCommandAsync(`summon xp_orb ${foundBlock.x + 0.35} ${foundBlock.y + 0.3} ${foundBlock.z}`);
    } else {
        drainXp = 0;
		openForms.delete(locationKey);
        system.clearRun(intervalId);
        isIntervalRunning = false;
    }
}






































const playersXpFanDataBase1 = new JsonDatabase('playersXpFanDataBase1');
const playersXpFanDataBase2 = new JsonDatabase('playersXpFanDataBase2');
const playersXpFanDataBase3 = new JsonDatabase('playersXpFanDataBase3');
const playersXpFanDataBase4 = new JsonDatabase('playersXpFanDataBase4');
const playersXpFanDataBase5 = new JsonDatabase('playersXpFanDataBase5');
const playersXpFanDataBase6 = new JsonDatabase('playersXpFanDataBase6');

const playersXpGrinderDataBase1 = new JsonDatabase('playersXpGrinderDataBase1');
const playersXpGrinderDataBase2 = new JsonDatabase('playersXpGrinderDataBase2');
const playersXpGrinderDataBase3 = new JsonDatabase('playersXpGrinderDataBase3');
const playersXpGrinderDataBase4 = new JsonDatabase('playersXpGrinderDataBase4');
const playersXpGrinderDataBase5 = new JsonDatabase('playersXpGrinderDataBase5');
const playersXpGrinderDataBase6 = new JsonDatabase('playersXpGrinderDataBase6');

export class XPFanAndGrinderMax {
	constructor(blockHandler) {
		this.blockHandler = blockHandler;

		this.storedLocationOfFan1 = null;
		this.storedLocationOfFan2 = null;
		this.storedLocationOfFan3 = null;
		this.storedLocationOfFan4 = null;
		this.storedLocationOfFan5 = null;
		this.storedLocationOfFan6 = null;

		this.storedLocationOfGrinder1 = null;
		this.storedLocationOfGrinder2 = null;
		this.storedLocationOfGrinder3 = null;
		this.storedLocationOfGrinder4 = null;
		this.storedLocationOfGrinder5 = null;
		this.storedLocationOfGrinder6 = null;
		
	}


	getStoredLocationsOfFans(index) {
        switch(index) {
            case 1:
                return this.storedLocationOfFan1;
            case 2:
                return this.storedLocationOfFan2;
            case 3:
                return this.storedLocationOfFan3;
            case 4:
                return this.storedLocationOfFan4;
            case 5:
                return this.storedLocationOfFan5;
            case 6:
                return this.storedLocationOfFan6;
            default:
                return null;
        }
    }

	getStoredLocationsOfGrinders(index) {
        switch(index) {
            case 1:
                return this.storedLocationOfGrinder1;
            case 2:
                return this.storedLocationOfGrinder2;
            case 3:
                return this.storedLocationOfGrinder3;
            case 4:
                return this.storedLocationOfGrinder4;
            case 5:
                return this.storedLocationOfGrinder5;
            case 6:
                return this.storedLocationOfGrinder6;
            default:
                return null;
        }
    }

	resetLocationForGrindersAndFans() {
		this.storedLocationOfFan1 = null;
		this.storedLocationOfFan2 = null;
		this.storedLocationOfFan3 = null;
		this.storedLocationOfFan4 = null;
		this.storedLocationOfFan5 = null;
		this.storedLocationOfFan6 = null;

		this.storedLocationOfGrinder1 = null;
		this.storedLocationOfGrinder2 = null;
		this.storedLocationOfGrinder3 = null;
		this.storedLocationOfGrinder4 = null;
		this.storedLocationOfGrinder5 = null;
		this.storedLocationOfGrinder6 = null;

		playersXpFanDataBase1.clear("snailstudios_xp_fan_1");
		playersXpFanDataBase2.clear("snailstudios_xp_fan_2");
		playersXpFanDataBase3.clear("snailstudios_xp_fan_3");
		playersXpFanDataBase4.clear("snailstudios_xp_fan_4");
		playersXpFanDataBase5.clear("snailstudios_xp_fan_5");
		playersXpFanDataBase6.clear("snailstudios_xp_fan_6");

		playersXpGrinderDataBase1.clear("snailstudios_xp_grinder_1");
		playersXpGrinderDataBase2.clear("snailstudios_xp_grinder_2");
		playersXpGrinderDataBase3.clear("snailstudios_xp_grinder_3");
		playersXpGrinderDataBase4.clear("snailstudios_xp_grinder_4");
		playersXpGrinderDataBase5.clear("snailstudios_xp_grinder_5");
		playersXpGrinderDataBase6.clear("snailstudios_xp_grinder_6");
    }

	

	handleBreakFanAndGrinder(data) {
		const breakBlockLocation = data.block.location;

		if (this.storedLocationOfFan1 &&
			breakBlockLocation.x === this.storedLocationOfFan1.x &&
			breakBlockLocation.y === this.storedLocationOfFan1.y &&
			breakBlockLocation.z === this.storedLocationOfFan1.z) {
			playersXpFanDataBase1.clear("snailstudios_xp_fan_1");
			this.storedLocationOfFan1 = null;
		} else if (this.storedLocationOfFan2 &&
			breakBlockLocation.x === this.storedLocationOfFan2.x &&
			breakBlockLocation.y === this.storedLocationOfFan2.y &&
			breakBlockLocation.z === this.storedLocationOfFan2.z) {
			playersXpFanDataBase2.clear("snailstudios_xp_fan_2");
			this.storedLocationOfFan2 = null;
		} else if (this.storedLocationOfFan3 &&
			breakBlockLocation.x === this.storedLocationOfFan3.x &&
			breakBlockLocation.y === this.storedLocationOfFan3.y &&
			breakBlockLocation.z === this.storedLocationOfFan3.z) {
			playersXpFanDataBase3.clear("snailstudios_xp_fan_3");
			this.storedLocationOfFan3 = null;
		} else if (this.storedLocationOfFan4 &&
			breakBlockLocation.x === this.storedLocationOfFan4.x &&
			breakBlockLocation.y === this.storedLocationOfFan4.y &&
			breakBlockLocation.z === this.storedLocationOfFan4.z) {
			playersXpFanDataBase4.clear("snailstudios_xp_fan_4");
			this.storedLocationOfFan4 = null;
		} else if (this.storedLocationOfFan5 &&
			breakBlockLocation.x === this.storedLocationOfFan5.x &&
			breakBlockLocation.y === this.storedLocationOfFan5.y &&
			breakBlockLocation.z === this.storedLocationOfFan5.z) {
			playersXpFanDataBase5.clear("snailstudios_xp_fan_5");
			this.storedLocationOfFan5 = null;
		} else if (this.storedLocationOfFan6 &&
			breakBlockLocation.x === this.storedLocationOfFan6.x &&
			breakBlockLocation.y === this.storedLocationOfFan6.y &&
			breakBlockLocation.z === this.storedLocationOfFan6.z) {
			playersXpFanDataBase6.clear("snailstudios_xp_fan_6");
			this.storedLocationOfFan6 = null;
		} else if (this.storedLocationOfGrinder1 &&
			breakBlockLocation.x === this.storedLocationOfGrinder1.x &&
			breakBlockLocation.y === this.storedLocationOfGrinder1.y &&
			breakBlockLocation.z === this.storedLocationOfGrinder1.z) {
			playersXpGrinderDataBase1.clear("snailstudios_xp_grinder_1");
			this.storedLocationOfGrinder1 = null;
		} else if (this.storedLocationOfGrinder2 &&
			breakBlockLocation.x === this.storedLocationOfGrinder2.x &&
			breakBlockLocation.y === this.storedLocationOfGrinder2.y &&
			breakBlockLocation.z === this.storedLocationOfGrinder2.z) {
			playersXpGrinderDataBase2.clear("snailstudios_xp_grinder_2");
			this.storedLocationOfGrinder2 = null;
		} else if (this.storedLocationOfGrinder3 &&
			breakBlockLocation.x === this.storedLocationOfGrinder3.x &&
			breakBlockLocation.y === this.storedLocationOfGrinder3.y &&
			breakBlockLocation.z === this.storedLocationOfGrinder3.z) {
			playersXpGrinderDataBase3.clear("snailstudios_xp_grinder_3");
			this.storedLocationOfGrinder3 = null;
		} else if (this.storedLocationOfGrinder4 &&
			breakBlockLocation.x === this.storedLocationOfGrinder4.x &&
			breakBlockLocation.y === this.storedLocationOfGrinder4.y &&
			breakBlockLocation.z === this.storedLocationOfGrinder4.z) {
			playersXpGrinderDataBase4.clear("snailstudios_xp_grinder_4");
			this.storedLocationOfGrinder4 = null;
		} else if (this.storedLocationOfGrinder5 &&
			breakBlockLocation.x === this.storedLocationOfGrinder5.x &&
			breakBlockLocation.y === this.storedLocationOfGrinder5.y &&
			breakBlockLocation.z === this.storedLocationOfGrinder5.z) {
			playersXpGrinderDataBase5.clear("snailstudios_xp_grinder_5");
			this.storedLocationOfGrinder5 = null;
		} else if (this.storedLocationOfGrinder6 &&
			breakBlockLocation.x === this.storedLocationOfGrinder6.x &&
			breakBlockLocation.y === this.storedLocationOfGrinder6.y &&
			breakBlockLocation.z === this.storedLocationOfGrinder6.z) {
			playersXpGrinderDataBase6.clear("snailstudios_xp_grinder_6");
			this.storedLocationOfGrinder6 = null;
		} else {
		}
	}

	handlePlaceFanAndGrinder(eventData) {
		const player = eventData.player;
		const location = eventData.block.location;
		const block = eventData.block;

		const xpMainDimension = blockHandler.getStoredDimension();

		const brainBlockCoords = this.blockHandler.getStoredLocation();

		if (brainBlockCoords !== null && location !== null) {
			const distance = this.calculateDistance(location, brainBlockCoords);
			if (distance <= 100) {
				if (block.permutation.matches('snailstudios_xp:fan_block')) {
					if (this.storedLocationOfFan1 === null) {
						playersXpFanDataBase1.set("snailstudios_xp_fan_1", location);
						this.storedLocationOfFan1 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else if (this.storedLocationOfFan2 === null && this.storedLocationOfFan1 !== null) {
						playersXpFanDataBase2.set("snailstudios_xp_fan_2", location);
						this.storedLocationOfFan2 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else if (this.storedLocationOfFan3 === null && this.storedLocationOfFan1 !== null && this.storedLocationOfFan2 !== null) {
						playersXpFanDataBase3.set("snailstudios_xp_fan_3", location);
						this.storedLocationOfFan3 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else if (this.storedLocationOfFan4 === null && this.storedLocationOfFan1 !== null && this.storedLocationOfFan2 !== null && this.storedLocationOfFan3 !== null) {
						playersXpFanDataBase4.set("snailstudios_xp_fan_4", location);
						this.storedLocationOfFan4 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else if (this.storedLocationOfFan5 === null && this.storedLocationOfFan1 !== null && this.storedLocationOfFan2 !== null && this.storedLocationOfFan3 !== null && this.storedLocationOfFan4 !== null) {
						playersXpFanDataBase5.set("snailstudios_xp_fan_5", location);
						this.storedLocationOfFan5 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else if (this.storedLocationOfFan6 === null && this.storedLocationOfFan1 !== null && this.storedLocationOfFan2 !== null && this.storedLocationOfFan3 !== null && this.storedLocationOfFan4 !== null && this.storedLocationOfFan5 !== null) {
						playersXpFanDataBase6.set("snailstudios_xp_fan_6", location);
						this.storedLocationOfFan6 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else {
						player.sendMessage(`Only 6 fans are allowed!`);
					}
				} else if (block.permutation.matches('snailstudios_xp:grinder_block')) {
					if (this.storedLocationOfGrinder1 === null) {
						playersXpGrinderDataBase1.set("snailstudios_xp_grinder_1", location);
						this.storedLocationOfGrinder1 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else if (this.storedLocationOfGrinder2 === null && this.storedLocationOfGrinder1 !== null) {
						playersXpGrinderDataBase2.set("snailstudios_xp_grinder_2", location);
						this.storedLocationOfGrinder2 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else if (this.storedLocationOfGrinder3 === null && this.storedLocationOfGrinder1 !== null && this.storedLocationOfGrinder2 !== null) {
						playersXpGrinderDataBase3.set("snailstudios_xp_grinder_3", location);
						this.storedLocationOfGrinder3 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else if (this.storedLocationOfGrinder4 === null && this.storedLocationOfGrinder1 !== null && this.storedLocationOfGrinder2 !== null && this.storedLocationOfGrinder3 !== null) {
						playersXpGrinderDataBase4.set("snailstudios_xp_grinder_4", location);
						this.storedLocationOfGrinder4 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else if (this.storedLocationOfGrinder5 === null && this.storedLocationOfGrinder1 !== null && this.storedLocationOfGrinder2 !== null && this.storedLocationOfGrinder3 !== null && this.storedLocationOfGrinder4 !== null) {
						playersXpGrinderDataBase5.set("snailstudios_xp_grinder_5", location);
						this.storedLocationOfGrinder5 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else if (this.storedLocationOfGrinder6 === null && this.storedLocationOfGrinder1 !== null && this.storedLocationOfGrinder2 !== null && this.storedLocationOfGrinder3 !== null && this.storedLocationOfGrinder4 !== null && this.storedLocationOfGrinder5 !== null) {
						playersXpGrinderDataBase6.set("snailstudios_xp_grinder_6", location);
						this.storedLocationOfGrinder6 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else {
						player.sendMessage(`Only 6 grinders are allowed!`);
					}
				} else if (block.permutation.matches('snailstudios_xp:grinder_block_gold')) {
					if (this.storedLocationOfGrinder1 === null) {
						playersXpGrinderDataBase1.set("snailstudios_xp_grinder_1", location);
						this.storedLocationOfGrinder1 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else if (this.storedLocationOfGrinder2 === null && this.storedLocationOfGrinder1 !== null) {
						playersXpGrinderDataBase2.set("snailstudios_xp_grinder_2", location);
						this.storedLocationOfGrinder2 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else if (this.storedLocationOfGrinder3 === null && this.storedLocationOfGrinder1 !== null && this.storedLocationOfGrinder2 !== null) {
						playersXpGrinderDataBase3.set("snailstudios_xp_grinder_3", location);
						this.storedLocationOfGrinder3 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else if (this.storedLocationOfGrinder4 === null && this.storedLocationOfGrinder1 !== null && this.storedLocationOfGrinder2 !== null && this.storedLocationOfGrinder3 !== null) {
						playersXpGrinderDataBase4.set("snailstudios_xp_grinder_4", location);
						this.storedLocationOfGrinder4 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else if (this.storedLocationOfGrinder5 === null && this.storedLocationOfGrinder1 !== null && this.storedLocationOfGrinder2 !== null && this.storedLocationOfGrinder3 !== null && this.storedLocationOfGrinder4 !== null) {
						playersXpGrinderDataBase5.set("snailstudios_xp_grinder_5", location);
						this.storedLocationOfGrinder5 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else if (this.storedLocationOfGrinder6 === null && this.storedLocationOfGrinder1 !== null && this.storedLocationOfGrinder2 !== null && this.storedLocationOfGrinder3 !== null && this.storedLocationOfGrinder4 !== null && this.storedLocationOfGrinder5 !== null) {
						playersXpGrinderDataBase6.set("snailstudios_xp_grinder_6", location);
						this.storedLocationOfGrinder6 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else {
						player.sendMessage(`Only 6 grinders are allowed!`);
					}
				} else if (block.permutation.matches('snailstudios_xp:grinder_block_netherite')) {
					if (this.storedLocationOfGrinder1 === null) {
						playersXpGrinderDataBase1.set("snailstudios_xp_grinder_1", location);
						this.storedLocationOfGrinder1 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else if (this.storedLocationOfGrinder2 === null && this.storedLocationOfGrinder1 !== null) {
						playersXpGrinderDataBase2.set("snailstudios_xp_grinder_2", location);
						this.storedLocationOfGrinder2 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else if (this.storedLocationOfGrinder3 === null && this.storedLocationOfGrinder1 !== null && this.storedLocationOfGrinder2 !== null) {
						playersXpGrinderDataBase3.set("snailstudios_xp_grinder_3", location);
						this.storedLocationOfGrinder3 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else if (this.storedLocationOfGrinder4 === null && this.storedLocationOfGrinder1 !== null && this.storedLocationOfGrinder2 !== null && this.storedLocationOfGrinder3 !== null) {
						playersXpGrinderDataBase4.set("snailstudios_xp_grinder_4", location);
						this.storedLocationOfGrinder4 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else if (this.storedLocationOfGrinder5 === null && this.storedLocationOfGrinder1 !== null && this.storedLocationOfGrinder2 !== null && this.storedLocationOfGrinder3 !== null && this.storedLocationOfGrinder4 !== null) {
						playersXpGrinderDataBase5.set("snailstudios_xp_grinder_5", location);
						this.storedLocationOfGrinder5 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else if (this.storedLocationOfGrinder6 === null && this.storedLocationOfGrinder1 !== null && this.storedLocationOfGrinder2 !== null && this.storedLocationOfGrinder3 !== null && this.storedLocationOfGrinder4 !== null && this.storedLocationOfGrinder5 !== null) {
						playersXpGrinderDataBase6.set("snailstudios_xp_grinder_6", location);
						this.storedLocationOfGrinder6 = location;
						world.getDimension(xpMainDimension).runCommandAsync(`playsound snailstudios_xp.snailstudios_xp_place_grinder_fan @a ${location.x} ${location.y + 1} ${location.z}`)
					} else {
						player.sendMessage(`Only 6 grinders are allowed!`);
					}
				}
			} else {
				player.sendMessage("No smart spawner nearby!");
			}
		} else {
		}
	}

	calculateDistance(coords1, coords2) {
		if(coords1 !== null && coords2 !== null){
			const dx = coords1.x - coords2.x;
			const dy = coords1.y - coords2.y;
			const dz = coords1.z - coords2.z;

			return Math.sqrt(dx * dx + dy * dy + dz * dz);
		}
	}

	handlePlayerJoinSetGrinderAndFan(eventData) {
		const fanLocation1 = playersXpFanDataBase1.get("snailstudios_xp_fan_1");
		const fanLocation2 = playersXpFanDataBase2.get("snailstudios_xp_fan_2");
		const fanLocation3 = playersXpFanDataBase3.get("snailstudios_xp_fan_3");
		const fanLocation4 = playersXpFanDataBase4.get("snailstudios_xp_fan_4");
		const fanLocation5 = playersXpFanDataBase5.get("snailstudios_xp_fan_5");
		const fanLocation6 = playersXpFanDataBase6.get("snailstudios_xp_fan_6");

		const grinderLocation1 = playersXpGrinderDataBase1.get("snailstudios_xp_grinder_1");
		const grinderLocation2 = playersXpGrinderDataBase2.get("snailstudios_xp_grinder_2");
		const grinderLocation3 = playersXpGrinderDataBase3.get("snailstudios_xp_grinder_3");
		const grinderLocation4 = playersXpGrinderDataBase4.get("snailstudios_xp_grinder_4");
		const grinderLocation5 = playersXpGrinderDataBase5.get("snailstudios_xp_grinder_5");
		const grinderLocation6 = playersXpGrinderDataBase6.get("snailstudios_xp_grinder_6");
	
		if (fanLocation1 === null || fanLocation1 === undefined) {
		} else {
			this.storedLocationOfFan1 = fanLocation1;
		}
	
		if (fanLocation2 === null || fanLocation2 === undefined) {
		} else {
			this.storedLocationOfFan2 = fanLocation2;
		}
	
		if (fanLocation3 === null || fanLocation3 === undefined) {
		} else {
			this.storedLocationOfFan3 = fanLocation3;
		}
	
		if (fanLocation4 === null || fanLocation4 === undefined) {
		} else {
			this.storedLocationOfFan4 = fanLocation4;
		}
	
		if (fanLocation5 === null || fanLocation5 === undefined) {
		} else {
			this.storedLocationOfFan5 = fanLocation5;
		}
	
		if (fanLocation6 === null || fanLocation6 === undefined) {
		} else {
			this.storedLocationOfFan6 = fanLocation6;
		}

		if (grinderLocation1 === null || grinderLocation1 === undefined) {
		} else {
			this.storedLocationOfGrinder1 = grinderLocation1;
		}
	
		if (grinderLocation2 === null || grinderLocation2 === undefined) {
		} else {
			this.storedLocationOfGrinder2 = grinderLocation2;
		}
	
		if (grinderLocation3 === null || grinderLocation3 === undefined) {
		} else {
			this.storedLocationOfGrinder3 = grinderLocation3;
		}
	
		if (grinderLocation4 === null || grinderLocation4 === undefined) {
		} else {
			this.storedLocationOfGrinder4 = grinderLocation4;
		}
	
		if (grinderLocation5 === null || grinderLocation5 === undefined) {
		} else {
			this.storedLocationOfGrinder5 = grinderLocation5;
		}
	
		if (grinderLocation6 === null || grinderLocation6 === undefined) {
		} else {
			this.storedLocationOfGrinder6 = grinderLocation6;
		}
	}
}












// Instantiate BlockHandler
const blockHandlerDimension = new BlockHandler();




const xpFanAndGrinderMaxInstance = new XPFanAndGrinderMax();

// Function to apply velocity to entities in front of the fan block based on block's facing direction
function applyVelocityToEntities(blockPos, blockHandlerDimension) {
    // Get the block's facing direction
	const xpMainDimension = blockHandler.getStoredDimension();
    const direction = world.getDimension(xpMainDimension).getBlock(blockPos).permutation.getState('minecraft:cardinal_direction');
    
    // Define the impulse direction based on the block's facing direction
    let impulse = { x: 0, y: 0, z: 0 };
    if (direction === "north") {
        impulse = { x: 0, y: 0, z: -0.3 }; // Push back in the negative Z direction
    } else if (direction === "east") {
        impulse = { x: 0.3, y: 0, z: 0 }; // Push back in the positive X direction
    } else if (direction === "south") {
        impulse = { x: 0, y: 0, z: 0.3 }; // Push back in the positive Z direction
    } else if (direction === "west") {
        impulse = { x: -0.3, y: 0, z: 0 }; // Push back in the negative X direction
    }

    // Get all entities within a radius in front of the block
    const entities = world.getDimension(xpMainDimension).getEntities();
	const entitiesInRange = entities.filter(entity => {
		if (entity.typeId !== "minecraft:player") {
			const entityPos = entity.location;
	
			switch (direction) {
				case "north":
					return (entityPos.z >= blockPos.z - 11 && entityPos.z <= blockPos.z && Math.abs(entityPos.x - blockPos.x) <= 4 && Math.abs(entityPos.y - blockPos.y) <= 4);
				case "east":
					return (entityPos.x >= blockPos.x && entityPos.x <= blockPos.x + 11 && Math.abs(entityPos.z - blockPos.z) <= 4 && Math.abs(entityPos.y - blockPos.y) <= 4);
				case "south":
					return (entityPos.z <= blockPos.z + 11 && entityPos.z >= blockPos.z && Math.abs(entityPos.x - blockPos.x) <= 4 && Math.abs(entityPos.y - blockPos.y) <= 4);
				case "west":
					return (entityPos.x <= blockPos.x && entityPos.x >= blockPos.x - 11 && Math.abs(entityPos.z - blockPos.z) <= 4 && Math.abs(entityPos.y - blockPos.y) <= 4);
				default:
					return false;
			}
		} else {
			return false;
		}
	});


    entitiesInRange.forEach(entity => {
        entity.applyImpulse(impulse);
    });
}

function applyDamageToEntities(grinderLocations, blockHandlerDimension) {
    grinderLocations.forEach(grinderLocation => {
        if (grinderLocation) { // Check if grinderLocation is not null or undefined
			const xpMainDimension = blockHandler.getStoredDimension();
			if (xpMainDimension) {
            const block = world.getDimension(xpMainDimension).getBlock(grinderLocation);
            if (block) {
                // Calculate the position at the center of the block above the grinder
                const targetPosGrinder = { 
                    x: grinderLocation.x + 0.5,
                    y: grinderLocation.y + 1,
                    z: grinderLocation.z + 0.5
                };


                const entitiesGrinder = world.getDimension(xpMainDimension).getEntities();

                entitiesGrinder.forEach(entityGrinder => {
                    if (entityGrinder.typeId !== "minecraft:player") {
                        const entityPosGrinder = entityGrinder.location;

                        const distanceX = Math.abs(entityPosGrinder.x - targetPosGrinder.x);
                        const distanceY = Math.abs(entityPosGrinder.y - targetPosGrinder.y);
                        const distanceZ = Math.abs(entityPosGrinder.z - targetPosGrinder.z);

                        const distance = Math.max(distanceX, distanceY, distanceZ);

                        if (distance <= 1.5 && entityGrinder.typeId !== "minecraft:item" && block.permutation.matches('snailstudios_xp:grinder_block')) {
                            entityGrinder.applyDamage(2);
                        }
						else if (distance <= 1.5 && entityGrinder.typeId !== "minecraft:item" && block.permutation.matches('snailstudios_xp:grinder_block_gold')) {
							entityGrinder.applyDamage(4);
                        }
						else if (distance <= 1.5 && entityGrinder.typeId !== "minecraft:item" && block.permutation.matches('snailstudios_xp:grinder_block_netherite')) {
							entityGrinder.applyDamage(8);
                        }
                    }
                });
            }
		}
        }
    });
}





function startVelocityLoop(blockHandlerDimension) {
    system.runInterval(() => {

        let fanLocations = [
            playersXpFanDataBase1.get("snailstudios_xp_fan_1"),
            playersXpFanDataBase2.get("snailstudios_xp_fan_2"),
            playersXpFanDataBase3.get("snailstudios_xp_fan_3"),
            playersXpFanDataBase4.get("snailstudios_xp_fan_4"),
            playersXpFanDataBase5.get("snailstudios_xp_fan_5"),
            playersXpFanDataBase6.get("snailstudios_xp_fan_6"),
        ];

        let grinderLocations = [
            playersXpGrinderDataBase1.get("snailstudios_xp_grinder_1"),
            playersXpGrinderDataBase2.get("snailstudios_xp_grinder_2"),
            playersXpGrinderDataBase3.get("snailstudios_xp_grinder_3"),
            playersXpGrinderDataBase4.get("snailstudios_xp_grinder_4"),
            playersXpGrinderDataBase5.get("snailstudios_xp_grinder_5"),
            playersXpGrinderDataBase6.get("snailstudios_xp_grinder_6"),
        ];

		const mainBrainSpawnerLocation = playersDataBaseXP.get("mainBrainLocation");

		if (!mainBrainSpawnerLocation) {
		} else {
			const xpMainDimension = blockHandler.getStoredDimension();
			if (xpMainDimension) {
			world.getDimension(xpMainDimension).runCommandAsync(`kill @e[type=xp_orb,x=${mainBrainSpawnerLocation.x},y=${mainBrainSpawnerLocation.y},z=${mainBrainSpawnerLocation.z},r=7]`)
			}
		}


        fanLocations.forEach(blockPos => {
            if (blockPos) {
				const xpMainDimension = blockHandler.getStoredDimension();
				if (xpMainDimension) {
                const block = world.getDimension(xpMainDimension).getBlock(blockPos);
                if (block) {
                    const direction = block.permutation.getState('minecraft:cardinal_direction');
                    applyVelocityToEntities(blockPos, direction);
				}
            }
        }
    });
		


        applyDamageToEntities(grinderLocations);
    }, 1);
}

// Call the function to start the loop
startVelocityLoop();

































let toggleButton = false;
let toggleButtonCollectAll = false;
let indexEntities = 0;

function returnindexEntites() {
	return indexEntities;
}

function toggleButtonFalse() {
	toggleButton = false;
};

function toggleButtonTrue() {
	toggleButton = true;
};

// Export the variables
export {
	toggleButton,
	indexEntities,
	toggleButtonFalse,
	toggleButtonTrue,
	returnindexEntites
};





// Subscribe to item use event
world.afterEvents.itemUse.subscribe((event) => {
	const item = event.itemStack;

	if (item?.typeId == "snailstudios_xp:xp_wrench") {

		const playerForm = event.source;
		const playerFormplayer = event.player;

		const mainXpStorage = playersXpDataBase.get("mainXpStorageLocation");


		const x = Math.floor(playerForm.location.x);
		const y = Math.floor(playerForm.location.y) - 1;
		const z = Math.floor(playerForm.location.z);

		locationKey = `${x}:${z}`;

		// Retrieve the block below the player
		const blockBelowPlayer = playerForm.dimension.getBlock({
			x,
			y,
			z
		});

		// Check if the form is already open for this block
		if (openForms.has(locationKey)) {
			return;
		}

		// Check if the item used is a clock and the block matches ironXPStorage
			if ((mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_0") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {

				// Set formOpen flag to true for this block
				openForms.set(locationKey, true);

				const uiMainXpStorage0 = new ModalFormData();


				uiMainXpStorage0.title("XP Options : Total levels stored: 0/30");
				// Set the initial state of the toggle button based on the current value of toggleButton
				uiMainXpStorage0.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage0.toggle("Collect all", false);
				uiMainXpStorage0.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage0.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}


					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}


					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
					}


					
					const selectedOption = formData.formValues[2];

					indexEntities = selectedOption

					
					openForms.delete(locationKey);
				}).catch(e => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_1") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage1 = new ModalFormData();

				uiMainXpStorage1.title("XP Options : Total levels stored: 1/30");
				uiMainXpStorage1.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage1.toggle("Collect all", false);
				uiMainXpStorage1.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage1.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 7 @s`);
					}

					
					const selectedOption = formData.formValues[2];

					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_2") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage2 = new ModalFormData();

				uiMainXpStorage2.title("XP Options : Total levels stored: 2/30");
				uiMainXpStorage2.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage2.toggle("Collect all", false);
				uiMainXpStorage2.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage2.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 16 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_3") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage3 = new ModalFormData();

				uiMainXpStorage3.title("XP Options : Total levels stored: 3/30");
				uiMainXpStorage3.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage3.toggle("Collect all", false);
				uiMainXpStorage3.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage3.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 27 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_4") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage4 = new ModalFormData();

				uiMainXpStorage4.title("XP Options : Total levels stored: 4/30");
				uiMainXpStorage4.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage4.toggle("Collect all", false);
				uiMainXpStorage4.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage4.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 40 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_5") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage5 = new ModalFormData();

				uiMainXpStorage5.title("XP Options : Total levels stored: 5/30");
				uiMainXpStorage5.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage5.toggle("Collect all", false);
				uiMainXpStorage5.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage5.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 55 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_6") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage6 = new ModalFormData();

				uiMainXpStorage6.title("XP Options : Total levels stored: 6/30");
				uiMainXpStorage6.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage6.toggle("Collect all", false);
				uiMainXpStorage6.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage6.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 72 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_7") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage7 = new ModalFormData();

				uiMainXpStorage7.title("XP Options : Total levels stored: 7/30");
				uiMainXpStorage7.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage7.toggle("Collect all", false);
				uiMainXpStorage7.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage7.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 91 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_8") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage8 = new ModalFormData();

				uiMainXpStorage8.title("XP Options : Total levels stored: 8/30");
				uiMainXpStorage8.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage8.toggle("Collect all", false);
				uiMainXpStorage8.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage8.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 112 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_9") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage9 = new ModalFormData();

				uiMainXpStorage9.title("XP Options : Total levels stored: 9/30");
				uiMainXpStorage9.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage9.toggle("Collect all", false);
				uiMainXpStorage9.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage9.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 135 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_10") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage10 = new ModalFormData();

				uiMainXpStorage10.title("XP Options : Total levels stored: 10/30");
				uiMainXpStorage10.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage10.toggle("Collect all", false);
				uiMainXpStorage10.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage10.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 160 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_11") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage11 = new ModalFormData();

				uiMainXpStorage11.title("XP Options : Total levels stored: 11/30");
				uiMainXpStorage11.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage11.toggle("Collect all", false);
				uiMainXpStorage11.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage11.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 187 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_12") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage12 = new ModalFormData();

				uiMainXpStorage12.title("XP Options : Total levels stored: 12/30");
				uiMainXpStorage12.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage12.toggle("Collect all", false);
				uiMainXpStorage12.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage12.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 216 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_13") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage13 = new ModalFormData();

				uiMainXpStorage13.title("XP Options : Total levels stored: 13/30");
				uiMainXpStorage13.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage13.toggle("Collect all", false);
				uiMainXpStorage13.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage13.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 247 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_14") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage14 = new ModalFormData();

				uiMainXpStorage14.title("XP Options : Total levels stored: 14/30");
				uiMainXpStorage14.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage14.toggle("Collect all", false);
				uiMainXpStorage14.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage14.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 280 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_15") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage15 = new ModalFormData();

				uiMainXpStorage15.title("XP Options : Total levels stored: 15/30");
				uiMainXpStorage15.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage15.toggle("Collect all", false);
				uiMainXpStorage15.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage15.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 315 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_16") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage16 = new ModalFormData();

				uiMainXpStorage16.title("XP Options : Total levels stored: 16/30");
				uiMainXpStorage16.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage16.toggle("Collect all", false);
				uiMainXpStorage16.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage16.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 352 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_17") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage17 = new ModalFormData();

				uiMainXpStorage17.title("XP Options : Total levels stored: 17/30");
				uiMainXpStorage17.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage17.toggle("Collect all", false);
				uiMainXpStorage17.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage17.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 394 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_18") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage18 = new ModalFormData();

				uiMainXpStorage18.title("XP Options : Total levels stored: 18/30");
				uiMainXpStorage18.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage18.toggle("Collect all", false);
				uiMainXpStorage18.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage18.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 441 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_19") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage19 = new ModalFormData();

				uiMainXpStorage19.title("XP Options : Total levels stored: 19/30");
				uiMainXpStorage19.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage19.toggle("Collect all", false);
				uiMainXpStorage19.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage19.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 493 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_20") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage20 = new ModalFormData();

				uiMainXpStorage20.title("XP Options : Total levels stored: 20/30");
				uiMainXpStorage20.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage20.toggle("Collect all", false);
				uiMainXpStorage20.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage20.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 550 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_21") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage21 = new ModalFormData();

				uiMainXpStorage21.title("XP Options : Total levels stored: 21/30");
				uiMainXpStorage21.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage21.toggle("Collect all", false);
				uiMainXpStorage21.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage21.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 612 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_22") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage22 = new ModalFormData();

				uiMainXpStorage22.title("XP Options : Total levels stored: 22/30");
				uiMainXpStorage22.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage22.toggle("Collect all", false);
				uiMainXpStorage22.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage22.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 679 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_23") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage23 = new ModalFormData();

				uiMainXpStorage23.title("XP Options : Total levels stored: 23/30");
				uiMainXpStorage23.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage23.toggle("Collect all", false);
				uiMainXpStorage23.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage23.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 751 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_24") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage24 = new ModalFormData();

				uiMainXpStorage24.title("XP Options : Total levels stored: 24/30");
				uiMainXpStorage24.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage24.toggle("Collect all", false);
				uiMainXpStorage24.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage24.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 828 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_25") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage25 = new ModalFormData();

				uiMainXpStorage25.title("XP Options : Total levels stored: 25/30");
				uiMainXpStorage25.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage25.toggle("Collect all", false);
				uiMainXpStorage25.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage25.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 910 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_26") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage26 = new ModalFormData();

				uiMainXpStorage26.title("XP Options : Total levels stored: 26/30");
				uiMainXpStorage26.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage26.toggle("Collect all", false);
				uiMainXpStorage26.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage26.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 997 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_27") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage27 = new ModalFormData();

				uiMainXpStorage27.title("XP Options : Total levels stored: 27/30");
				uiMainXpStorage27.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage27.toggle("Collect all", false);
				uiMainXpStorage27.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage27.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 1089 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_28") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage28 = new ModalFormData();

				uiMainXpStorage28.title("XP Options : Total levels stored: 28/30");
				uiMainXpStorage28.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage28.toggle("Collect all", false);
				uiMainXpStorage28.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage28.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 1186 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_29") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage29 = new ModalFormData();

				uiMainXpStorage29.title("XP Options : Total levels stored: 29/30");
				uiMainXpStorage29.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage29.toggle("Collect all", false);
				uiMainXpStorage29.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage29.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 1288 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_30") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorage30 = new ModalFormData();

				uiMainXpStorage30.title("XP Options : Total levels stored: 30/30");
				uiMainXpStorage30.toggle("Turn Off/On", toggleButton);
				uiMainXpStorage30.toggle("Collect all", false);
				uiMainXpStorage30.dropdown("Mob spawner options", ["Cow", "Sheep", "Chicken", "Pig", "Skeleton", "Zombie"], indexEntities);

				uiMainXpStorage30.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
						playerForm.runCommandAsync(`xp 1395 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} 
			
			
			
			
			
			
			
			
			
			
			
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_0") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold0 = new ModalFormData();

				uiMainXpStorageGold0.title("XP Options : Total levels stored: 0/60");
				uiMainXpStorageGold0.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold0.toggle("Collect all", false);
				uiMainXpStorageGold0.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold0.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_1") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold1 = new ModalFormData();

				uiMainXpStorageGold1.title("XP Options : Total levels stored: 1/60");
				uiMainXpStorageGold1.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold1.toggle("Collect all", false);
				uiMainXpStorageGold1.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold1.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 7 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_2") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold2 = new ModalFormData();

				uiMainXpStorageGold2.title("XP Options : Total levels stored: 2/60");
				uiMainXpStorageGold2.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold2.toggle("Collect all", false);
				uiMainXpStorageGold2.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold2.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 16 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_3") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold3 = new ModalFormData();

				uiMainXpStorageGold3.title("XP Options : Total levels stored: 3/60");
				uiMainXpStorageGold3.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold3.toggle("Collect all", false);
				uiMainXpStorageGold3.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold3.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 27 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_4") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold4 = new ModalFormData();

				uiMainXpStorageGold4.title("XP Options : Total levels stored: 4/60");
				uiMainXpStorageGold4.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold4.toggle("Collect all", false);
				uiMainXpStorageGold4.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold4.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 40 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_5") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold5 = new ModalFormData();

				uiMainXpStorageGold5.title("XP Options : Total levels stored: 5/60");
				uiMainXpStorageGold5.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold5.toggle("Collect all", false);
				uiMainXpStorageGold5.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold5.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 55 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_6") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold6 = new ModalFormData();

				uiMainXpStorageGold6.title("XP Options : Total levels stored: 6/60");
				uiMainXpStorageGold6.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold6.toggle("Collect all", false);
				uiMainXpStorageGold6.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold6.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 72 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_7") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold7 = new ModalFormData();

				uiMainXpStorageGold7.title("XP Options : Total levels stored: 7/60");
				uiMainXpStorageGold7.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold7.toggle("Collect all", false);
				uiMainXpStorageGold7.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold7.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 91 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_8") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold8 = new ModalFormData();

				uiMainXpStorageGold8.title("XP Options : Total levels stored: 8/60");
				uiMainXpStorageGold8.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold8.toggle("Collect all", false);
				uiMainXpStorageGold8.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold8.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 112 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_9") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold9 = new ModalFormData();

				uiMainXpStorageGold9.title("XP Options : Total levels stored: 9/60");
				uiMainXpStorageGold9.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold9.toggle("Collect all", false);
				uiMainXpStorageGold9.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold9.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 135 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_10") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold10 = new ModalFormData();

				uiMainXpStorageGold10.title("XP Options : Total levels stored: 10/60");
				uiMainXpStorageGold10.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold10.toggle("Collect all", false);
				uiMainXpStorageGold10.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold10.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 160 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_11") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold11 = new ModalFormData();

				uiMainXpStorageGold11.title("XP Options : Total levels stored: 11/60");
				uiMainXpStorageGold11.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold11.toggle("Collect all", false);
				uiMainXpStorageGold11.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold11.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 187 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_12") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold12 = new ModalFormData();

				uiMainXpStorageGold12.title("XP Options : Total levels stored: 12/60");
				uiMainXpStorageGold12.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold12.toggle("Collect all", false);
				uiMainXpStorageGold12.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold12.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 216 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_13") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold13 = new ModalFormData();

				uiMainXpStorageGold13.title("XP Options : Total levels stored: 13/60");
				uiMainXpStorageGold13.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold13.toggle("Collect all", false);
				uiMainXpStorageGold13.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold13.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 247 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_14") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold14 = new ModalFormData();

				uiMainXpStorageGold14.title("XP Options : Total levels stored: 14/60");
				uiMainXpStorageGold14.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold14.toggle("Collect all", false);
				uiMainXpStorageGold14.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold14.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 280 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_15") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold15 = new ModalFormData();

				uiMainXpStorageGold15.title("XP Options : Total levels stored: 15/60");
				uiMainXpStorageGold15.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold15.toggle("Collect all", false);
				uiMainXpStorageGold15.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold15.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 315 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_16") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold16 = new ModalFormData();

				uiMainXpStorageGold16.title("XP Options : Total levels stored: 16/60");
				uiMainXpStorageGold16.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold16.toggle("Collect all", false);
				uiMainXpStorageGold16.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold16.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 352 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_17") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold17 = new ModalFormData();

				uiMainXpStorageGold17.title("XP Options : Total levels stored: 17/60");
				uiMainXpStorageGold17.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold17.toggle("Collect all", false);
				uiMainXpStorageGold17.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold17.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 394 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_18") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold18 = new ModalFormData();

				uiMainXpStorageGold18.title("XP Options : Total levels stored: 18/60");
				uiMainXpStorageGold18.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold18.toggle("Collect all", false);
				uiMainXpStorageGold18.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold18.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 441 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_19") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold19 = new ModalFormData();

				uiMainXpStorageGold19.title("XP Options : Total levels stored: 19/60");
				uiMainXpStorageGold19.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold19.toggle("Collect all", false);
				uiMainXpStorageGold19.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold19.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 493 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_20") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold20 = new ModalFormData();

				uiMainXpStorageGold20.title("XP Options : Total levels stored: 20/60");
				uiMainXpStorageGold20.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold20.toggle("Collect all", false);
				uiMainXpStorageGold20.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold20.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 550 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_21") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold21 = new ModalFormData();

				uiMainXpStorageGold21.title("XP Options : Total levels stored: 21/60");
				uiMainXpStorageGold21.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold21.toggle("Collect all", false);
				uiMainXpStorageGold21.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold21.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 612 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_22") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold22 = new ModalFormData();

				uiMainXpStorageGold22.title("XP Options : Total levels stored: 22/60");
				uiMainXpStorageGold22.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold22.toggle("Collect all", false);
				uiMainXpStorageGold22.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold22.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 679 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_23") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold23 = new ModalFormData();

				uiMainXpStorageGold23.title("XP Options : Total levels stored: 23/60");
				uiMainXpStorageGold23.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold23.toggle("Collect all", false);
				uiMainXpStorageGold23.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold23.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 751 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_24") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold24 = new ModalFormData();

				uiMainXpStorageGold24.title("XP Options : Total levels stored: 24/60");
				uiMainXpStorageGold24.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold24.toggle("Collect all", false);
				uiMainXpStorageGold24.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold24.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 828 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_25") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold25 = new ModalFormData();

				uiMainXpStorageGold25.title("XP Options : Total levels stored: 25/60");
				uiMainXpStorageGold25.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold25.toggle("Collect all", false);
				uiMainXpStorageGold25.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold25.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 910 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_26") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold26 = new ModalFormData();

				uiMainXpStorageGold26.title("XP Options : Total levels stored: 26/60");
				uiMainXpStorageGold26.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold26.toggle("Collect all", false);
				uiMainXpStorageGold26.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold26.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 997 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_27") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold27 = new ModalFormData();

				uiMainXpStorageGold27.title("XP Options : Total levels stored: 27/60");
				uiMainXpStorageGold27.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold27.toggle("Collect all", false);
				uiMainXpStorageGold27.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold27.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 1089 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_28") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold28 = new ModalFormData();

				uiMainXpStorageGold28.title("XP Options : Total levels stored: 28/60");
				uiMainXpStorageGold28.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold28.toggle("Collect all", false);
				uiMainXpStorageGold28.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold28.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 1186 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_29") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold29 = new ModalFormData();

				uiMainXpStorageGold29.title("XP Options : Total levels stored: 29/60");
				uiMainXpStorageGold29.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold29.toggle("Collect all", false);
				uiMainXpStorageGold29.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold29.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 1288 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_30") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold30 = new ModalFormData();

				uiMainXpStorageGold30.title("XP Options : Total levels stored: 30/60");
				uiMainXpStorageGold30.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold30.toggle("Collect all", false);
				uiMainXpStorageGold30.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold30.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 1395 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_31") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold31 = new ModalFormData();

				uiMainXpStorageGold31.title("XP Options : Total levels stored: 31/60");
				uiMainXpStorageGold31.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold31.toggle("Collect all", false);
				uiMainXpStorageGold31.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold31.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 1507 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_32") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold32 = new ModalFormData();

				uiMainXpStorageGold32.title("XP Options : Total levels stored: 32/60");
				uiMainXpStorageGold32.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold32.toggle("Collect all", false);
				uiMainXpStorageGold32.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold32.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 1628 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_33") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold33 = new ModalFormData();

				uiMainXpStorageGold33.title("XP Options : Total levels stored: 33/60");
				uiMainXpStorageGold33.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold33.toggle("Collect all", false);
				uiMainXpStorageGold33.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold33.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 1758 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_34") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold34 = new ModalFormData();

				uiMainXpStorageGold34.title("XP Options : Total levels stored: 34/60");
				uiMainXpStorageGold34.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold34.toggle("Collect all", false);
				uiMainXpStorageGold34.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold34.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 1897 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_35") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold35 = new ModalFormData();

				uiMainXpStorageGold35.title("XP Options : Total levels stored: 35/60");
				uiMainXpStorageGold35.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold35.toggle("Collect all", false);
				uiMainXpStorageGold35.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold35.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 2045 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_36") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold36 = new ModalFormData();

				uiMainXpStorageGold36.title("XP Options : Total levels stored: 36/60");
				uiMainXpStorageGold36.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold36.toggle("Collect all", false);
				uiMainXpStorageGold36.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold36.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 2202 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_37") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold37 = new ModalFormData();

				uiMainXpStorageGold37.title("XP Options : Total levels stored: 37/60");
				uiMainXpStorageGold37.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold37.toggle("Collect all", false);
				uiMainXpStorageGold37.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold37.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 2368 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_38") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold38 = new ModalFormData();

				uiMainXpStorageGold38.title("XP Options : Total levels stored: 38/60");
				uiMainXpStorageGold38.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold38.toggle("Collect all", false);
				uiMainXpStorageGold38.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold38.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 2543 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_39") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold39 = new ModalFormData();

				uiMainXpStorageGold39.title("XP Options : Total levels stored: 39/60");
				uiMainXpStorageGold39.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold39.toggle("Collect all", false);
				uiMainXpStorageGold39.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold39.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 2727 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_40") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold40 = new ModalFormData();

				uiMainXpStorageGold40.title("XP Options : Total levels stored: 40/60");
				uiMainXpStorageGold40.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold40.toggle("Collect all", false);
				uiMainXpStorageGold40.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold40.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 2920 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_41") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold41 = new ModalFormData();

				uiMainXpStorageGold41.title("XP Options : Total levels stored: 41/60");
				uiMainXpStorageGold41.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold41.toggle("Collect all", false);
				uiMainXpStorageGold41.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold41.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 3122 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_42") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold42 = new ModalFormData();

				uiMainXpStorageGold42.title("XP Options : Total levels stored: 42/60");
				uiMainXpStorageGold42.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold42.toggle("Collect all", false);
				uiMainXpStorageGold42.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold42.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 3333 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_43") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold43 = new ModalFormData();

				uiMainXpStorageGold43.title("XP Options : Total levels stored: 43/60");
				uiMainXpStorageGold43.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold43.toggle("Collect all", false);
				uiMainXpStorageGold43.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold43.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 3553 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_44") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold44 = new ModalFormData();

				uiMainXpStorageGold44.title("XP Options : Total levels stored: 44/60");
				uiMainXpStorageGold44.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold44.toggle("Collect all", false);
				uiMainXpStorageGold44.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold44.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 3782 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_45") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold45 = new ModalFormData();

				uiMainXpStorageGold45.title("XP Options : Total levels stored: 45/60");
				uiMainXpStorageGold45.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold45.toggle("Collect all", false);
				uiMainXpStorageGold45.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold45.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 4020 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_46") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold46 = new ModalFormData();

				uiMainXpStorageGold46.title("XP Options : Total levels stored: 46/60");
				uiMainXpStorageGold46.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold46.toggle("Collect all", false);
				uiMainXpStorageGold46.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold46.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 4267 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_47") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold47 = new ModalFormData();

				uiMainXpStorageGold47.title("XP Options : Total levels stored: 47/60");
				uiMainXpStorageGold47.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold47.toggle("Collect all", false);
				uiMainXpStorageGold47.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold47.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 4523 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_48") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold48 = new ModalFormData();

				uiMainXpStorageGold48.title("XP Options : Total levels stored: 48/60");
				uiMainXpStorageGold48.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold48.toggle("Collect all", false);
				uiMainXpStorageGold48.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold48.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 4788 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_49") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold49 = new ModalFormData();

				uiMainXpStorageGold49.title("XP Options : Total levels stored: 49/60");
				uiMainXpStorageGold49.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold49.toggle("Collect all", false);
				uiMainXpStorageGold49.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold49.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 5062 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_50") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold50 = new ModalFormData();

				uiMainXpStorageGold50.title("XP Options : Total levels stored: 50/60");
				uiMainXpStorageGold50.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold50.toggle("Collect all", false);
				uiMainXpStorageGold50.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold50.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 5345 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_51") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold51 = new ModalFormData();

				uiMainXpStorageGold51.title("XP Options : Total levels stored: 51/60");
				uiMainXpStorageGold51.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold51.toggle("Collect all", false);
				uiMainXpStorageGold51.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold51.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 5637 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_52") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold52 = new ModalFormData();

				uiMainXpStorageGold52.title("XP Options : Total levels stored: 52/60");
				uiMainXpStorageGold52.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold52.toggle("Collect all", false);
				uiMainXpStorageGold52.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold52.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 5938 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_53") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold53 = new ModalFormData();

				uiMainXpStorageGold53.title("XP Options : Total levels stored: 53/60");
				uiMainXpStorageGold53.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold53.toggle("Collect all", false);
				uiMainXpStorageGold53.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold53.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 6248 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_54") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold54 = new ModalFormData();

				uiMainXpStorageGold54.title("XP Options : Total levels stored: 54/60");
				uiMainXpStorageGold54.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold54.toggle("Collect all", false);
				uiMainXpStorageGold54.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold54.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 6567 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_55") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold55 = new ModalFormData();

				uiMainXpStorageGold55.title("XP Options : Total levels stored: 55/60");
				uiMainXpStorageGold55.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold55.toggle("Collect all", false);
				uiMainXpStorageGold55.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold55.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 6895 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_56") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold56 = new ModalFormData();

				uiMainXpStorageGold56.title("XP Options : Total levels stored: 56/60");
				uiMainXpStorageGold56.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold56.toggle("Collect all", false);
				uiMainXpStorageGold56.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold56.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 7232 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_57") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold57 = new ModalFormData();

				uiMainXpStorageGold57.title("XP Options : Total levels stored: 57/60");
				uiMainXpStorageGold57.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold57.toggle("Collect all", false);
				uiMainXpStorageGold57.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold57.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 7578 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_58") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold58 = new ModalFormData();

				uiMainXpStorageGold58.title("XP Options : Total levels stored: 58/60");
				uiMainXpStorageGold58.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold58.toggle("Collect all", false);
				uiMainXpStorageGold58.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold58.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 7933 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_59") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold59 = new ModalFormData();

				uiMainXpStorageGold59.title("XP Options : Total levels stored: 59/60");
				uiMainXpStorageGold59.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold59.toggle("Collect all", false);
				uiMainXpStorageGold59.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold59.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 8297 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_60") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold60 = new ModalFormData();

				uiMainXpStorageGold60.title("XP Options : Total levels stored: 60/60");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Witch", "Slime", "Guardian", "Zombie Pigman", "Creeper", "Iron Golem"], indexEntities);

				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
						playerForm.runCommandAsync(`xp 8670 @s`);
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} 















			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_0") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);

				const uiMainXpStorageGold60 = new ModalFormData();

				uiMainXpStorageGold60.title("XP Options : Total levels stored: 0/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);

				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}

					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}

					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
					}

					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;

					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_1") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 1/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 7 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_2") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 2/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 16 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_3") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 3/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 27 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_4") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 4/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 40 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_5") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 5/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 55 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_6") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 6/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 72 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_7") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 7/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 91 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_8") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 8/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 112 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_9") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 9/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 135 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_10") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 10/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 160 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_11") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 11/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 187 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_12") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 12/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 216 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_13") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 13/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 247 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_14") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 14/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 280 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_15") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 15/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 315 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_16") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 16/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 352 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_17") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 17/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 394 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_18") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 18/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 441 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_19") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 19/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 493 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_20") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 20/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 550 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_21") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 21/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 612 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_22") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 22/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 679 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_23") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 23/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 751 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_24") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 24/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 828 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_25") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 25/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 910 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_26") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 26/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 997 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_27") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 27/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 1089 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_28") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 28/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 1186 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_29") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 29/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 1288 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_30") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 30/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 1395 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_31") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 31/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 1507 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_32") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 32/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 1628 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_33") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 33/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 1758 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_34") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 34/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 1897 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_35") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 35/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 2045 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_36") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 36/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 2202 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_37") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 37/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 2368 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_38") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 38/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 2543 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_39") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 39/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 2727 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_40") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 40/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 2920 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_41") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 41/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 3122 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_42") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 42/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 3333 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_43") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 43/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 3553 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_44") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 44/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 3782 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_45") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 45/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 4020 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_46") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 46/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 4267 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_47") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 47/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 4523 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_48") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 48/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 4788 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_49") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 49/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 5062 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_50") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 50/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 5345 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_51") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 51/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 5637 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_52") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 52/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 5938 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_53") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 53/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 6248 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_54") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 54/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 6567 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_55") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 55/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 6895 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_56") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 56/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 7232 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_57") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 57/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 7578 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_58") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 58/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 7933 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_59") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 59/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 8297 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_60") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 60/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 8670 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_61") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 61/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 9052 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_62") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 62/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 9443 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_63") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 63/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 9843 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_64") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 64/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 10252 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_65") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 65/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 10670 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_66") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 66/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 11097 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_67") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 67/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 11533 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_68") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 68/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 11978 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_69") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 69/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 12432 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_70") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 70/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 12895 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_71") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 71/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 13367 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_72") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 72/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 13848 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_73") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 73/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 14338 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_74") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 74/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 14837 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_75") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 75/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 15345 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_76") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 76/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 15862 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_77") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 77/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 16388 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_78") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 78/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 16923 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_79") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 79/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 17467 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_80") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 80/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 18020 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_81") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 81/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 18582 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_82") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 82/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 19153 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_83") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 83/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 19733 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_84") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 84/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 20322 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_85") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 85/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 20920 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_86") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 86/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 21527 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_87") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 87/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 22143 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_88") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 88/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 22768 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_89") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 89/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 23402 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_90") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 90/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 24045 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_91") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 91/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 24697 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_92") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 92/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 25358 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_93") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 93/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 26028 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_94") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 94/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 26707 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_95") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 95/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 27395 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_96") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 96/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 28092 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_97") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 97/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 28798 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_98") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 98/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 29513 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_99") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 99/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 30237 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (
				(mainXpStorage !== undefined && mainXpStorage !== null) &&
				item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_100") &&
				blockBelowPlayer.x === mainXpStorage.x &&
				blockBelowPlayer.y === mainXpStorage.y &&
				blockBelowPlayer.z === mainXpStorage.z) {
				openForms.set(locationKey, true);
			
				const uiMainXpStorageGold60 = new ModalFormData();
			
				uiMainXpStorageGold60.title("XP Options : Total levels stored: 100/100");
				uiMainXpStorageGold60.toggle("Turn Off/On", toggleButton);
				uiMainXpStorageGold60.toggle("Collect all", false);
				uiMainXpStorageGold60.dropdown("Mob spawner options", ["Wither Skeleton", "Blaze - Drops only on player kill", "Pillager Raid"], indexEntities);
			
				uiMainXpStorageGold60.show(playerForm).then((formData) => {
					if (formData.canceled) {
						openForms.delete(locationKey);
						return;
					}
			
					if (formData.formValues[0] === false) {
						toggleButton = false;
						entityChecker.stopMobSpawner();
					} else {
						toggleButton = true;
						entityChecker.runMobSpawner();
					}
			
					if (formData.formValues[1] === false) {
						toggleButtonCollectAll = false;
					} else {
						toggleButtonCollectAll = true;
						playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
						playerForm.runCommandAsync(`xp 30970 @s`);
					}
			
					const selectedOption = formData.formValues[2];
					indexEntities = selectedOption;
			
					openForms.delete(locationKey);
				}).catch((e) => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			}
			
			
			
			
			




			
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_0")) {

				openForms.set(locationKey, true);

				
				const uiXpStorage0 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 0/30")
					.button("Collect All")

				uiXpStorage0.show(playerForm).then(baseForm => {
					if (baseForm.canceled) {
						openForms.delete(locationKey);
						return;
					}

					let response = baseForm.selection;
					switch (response) {
						case 0:
							break;
					}

					
					openForms.delete(locationKey);
				}).catch(e => {
					console.error(e, e.stack);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_1")) {
				openForms.set(locationKey, true);

				
				const uiXpStorage1 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 1/30")
					.button("Collect All");
				
				uiXpStorage1.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 7 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_2")) {
				openForms.set(locationKey, true);

				
				const uiXpStorage2 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 2/30")
					.button("Collect All");
				
				uiXpStorage2.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 16 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_3")) {
				openForms.set(locationKey, true);

				const uiXpStorage3 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 3/30")
					.button("Collect All");
				
				uiXpStorage3.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 27 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_4")) {
				openForms.set(locationKey, true);

				const uiXpStorage4 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 4/30")
					.button("Collect All");
				
				uiXpStorage4.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 40 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_5")) {
				openForms.set(locationKey, true);

				const uiXpStorage5 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 5/30")
					.button("Collect All");
				
				uiXpStorage5.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 55 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_6")) {
				openForms.set(locationKey, true);

				const uiXpStorage6 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 6/30")
					.button("Collect All");
				
				uiXpStorage6.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 72 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_7")) {
				openForms.set(locationKey, true);

				const uiXpStorage7 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 7/30")
					.button("Collect All");
				
				uiXpStorage7.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 91 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_8")) {
				openForms.set(locationKey, true);

				const uiXpStorage8 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 8/30")
					.button("Collect All");
				
				uiXpStorage8.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 112 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_9")) {
				openForms.set(locationKey, true);

				const uiXpStorage9 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 9/30")
					.button("Collect All");
				
				uiXpStorage9.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 135 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_10")) {
				openForms.set(locationKey, true);

				0
				const uiXpStorage10 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 10/30")
					.button("Collect All");
				
				uiXpStorage10.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 160 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_11")) {
				openForms.set(locationKey, true);

				1
				const uiXpStorage11 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 11/30")
					.button("Collect All");
				
				uiXpStorage11.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 187 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_12")) {
				openForms.set(locationKey, true);

				2
				const uiXpStorage12 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 12/30")
					.button("Collect All");
				
				uiXpStorage12.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 216 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_13")) {
				openForms.set(locationKey, true);

				3
				const uiXpStorage13 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 13/30")
					.button("Collect All");
				
				uiXpStorage13.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 247 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_14")) {
				openForms.set(locationKey, true);

				4
				const uiXpStorage14 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 14/30")
					.button("Collect All");
				
				uiXpStorage14.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 280 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_15")) {
				openForms.set(locationKey, true);

				5
				const uiXpStorage15 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 15/30")
					.button("Collect All");
				
				uiXpStorage15.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 315 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_16")) {
				openForms.set(locationKey, true);

				6
				const uiXpStorage16 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 16/30")
					.button("Collect All");
				
				uiXpStorage16.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 352 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_17")) {
				openForms.set(locationKey, true);

				7
				const uiXpStorage17 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 17/30")
					.button("Collect All");
				
				uiXpStorage17.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					openForms.delete(locationKey);
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 394 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_18")) {
				openForms.set(locationKey, true);

				8
				const uiXpStorage18 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 18/30")
					.button("Collect All");
				
				uiXpStorage18.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 441 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_19")) {
				openForms.set(locationKey, true);

				9
				const uiXpStorage19 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 19/30")
					.button("Collect All");
				
				uiXpStorage19.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 493 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_20")) {
				openForms.set(locationKey, true);

				0
				const uiXpStorage20 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 20/30")
					.button("Collect All");
				
				uiXpStorage20.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 550 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_21")) {
				openForms.set(locationKey, true);

				1
				const uiXpStorage21 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 21/30")
					.button("Collect All");
				
				uiXpStorage21.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 612 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_22")) {
				openForms.set(locationKey, true);

				2
				const uiXpStorage22 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 22/30")
					.button("Collect All");
				
				uiXpStorage22.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 679 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_23")) {
				openForms.set(locationKey, true);

				3
				const uiXpStorage23 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 23/30")
					.button("Collect All");
				
				uiXpStorage23.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 751 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_24")) {
				openForms.set(locationKey, true);

				4
				const uiXpStorage24 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 24/30")
					.button("Collect All");
				
				uiXpStorage24.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 828 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_25")) {
				openForms.set(locationKey, true);

				5
				const uiXpStorage25 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 25/30")
					.button("Collect All");
				
				uiXpStorage25.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 910 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_26")) {
				openForms.set(locationKey, true);

				6
				const uiXpStorage26 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 26/30")
					.button("Collect All");
				
				uiXpStorage26.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 997 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_27")) {
				openForms.set(locationKey, true);

				7
				const uiXpStorage27 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 27/30")
					.button("Collect All");
				
				uiXpStorage27.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 1089 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_28")) {
				openForms.set(locationKey, true);

				8
				const uiXpStorage28 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 28/30")
					.button("Collect All");
				
				uiXpStorage28.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 1186 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_29")) {
				openForms.set(locationKey, true);

				9
				const uiXpStorage29 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 29/30")
					.button("Collect All");
				
				uiXpStorage29.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 1288 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_30")) {
				openForms.set(locationKey, true);

				const uiXpStorage30 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 30/30")
					.button("Collect All");
				
				uiXpStorage30.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_iron_xp_storage_0`);
							playerForm.runCommandAsync(`xp 1395 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} 
			
			
			
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" &&
				blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_0")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold0 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 0/60")
					.button("Collect All");
				
				uiXpStorageGold0.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_1")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold1 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 1/60")
					.button("Collect All");
				
				uiXpStorageGold1.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 7 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_2")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold2 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 2/60")
					.button("Collect All");
				
				uiXpStorageGold2.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 16 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_3")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold3 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 3/60")
					.button("Collect All");
				
				uiXpStorageGold3.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 27 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_4")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold4 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 4/60")
					.button("Collect All");
				
				uiXpStorageGold4.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 40 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_5")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold5 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 5/60")
					.button("Collect All");
				
				uiXpStorageGold5.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 55 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_6")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold6 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 6/60")
					.button("Collect All");
				
				uiXpStorageGold6.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 72 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_7")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold7 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 7/60")
					.button("Collect All");
				
				uiXpStorageGold7.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 91 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_8")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold8 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 8/60")
					.button("Collect All");
				
				uiXpStorageGold8.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 112 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_9")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold9 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 9/60")
					.button("Collect All");
				
				uiXpStorageGold9.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 135 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_10")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold10 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 10/60")
					.button("Collect All");
				
				uiXpStorageGold10.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 160 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_11")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold11 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 11/60")
					.button("Collect All");
				
				uiXpStorageGold11.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 187 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_12")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold12 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 12/60")
					.button("Collect All");
				
				uiXpStorageGold12.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 216 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_13")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold13 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 13/60")
					.button("Collect All");
				
				uiXpStorageGold13.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 247 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_14")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold14 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 14/60")
					.button("Collect All");
				
				uiXpStorageGold14.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 280 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_15")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold15 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 15/60")
					.button("Collect All");
				
				uiXpStorageGold15.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 315 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_16")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold16 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 16/60")
					.button("Collect All");
				
				uiXpStorageGold16.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 352 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_17")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold17 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 17/60")
					.button("Collect All");
				
				uiXpStorageGold17.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 394 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_18")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold18 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 18/60")
					.button("Collect All");
				
				uiXpStorageGold18.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 441 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_19")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold19 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 19/60")
					.button("Collect All");
				
				uiXpStorageGold19.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 493 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_20")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold20 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 20/60")
					.button("Collect All");
				
				uiXpStorageGold20.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 550 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_21")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold21 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 21/60")
					.button("Collect All");
				
				uiXpStorageGold21.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 612 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_22")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold22 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 22/60")
					.button("Collect All");
				
				uiXpStorageGold22.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 679 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_23")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold23 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 23/60")
					.button("Collect All");
				
				uiXpStorageGold23.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 751 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_24")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold24 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 24/60")
					.button("Collect All");
				
				uiXpStorageGold24.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 828 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_25")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold25 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 25/60")
					.button("Collect All");
				
				uiXpStorageGold25.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 910 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_26")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold26 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 26/60")
					.button("Collect All");
				
				uiXpStorageGold26.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 997 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_27")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold27 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 27/60")
					.button("Collect All");
				
				uiXpStorageGold27.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 1089 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_28")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold28 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 28/60")
					.button("Collect All");
				
				uiXpStorageGold28.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 1186 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_29")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold29 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 29/60")
					.button("Collect All");
				
				uiXpStorageGold29.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 1288 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_30")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold30 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 30/60")
					.button("Collect All");
				
				uiXpStorageGold30.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 1395 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_31")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold31 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 31/60")
					.button("Collect All");
				
				uiXpStorageGold31.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 1507 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_32")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold32 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 32/60")
					.button("Collect All");
				
				uiXpStorageGold32.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 1628 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_33")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold33 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 33/60")
					.button("Collect All");
				
				uiXpStorageGold33.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 1758 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_34")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold34 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 34/60")
					.button("Collect All");
				
				uiXpStorageGold34.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 1897 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_35")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold35 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 35/60")
					.button("Collect All");
				
				uiXpStorageGold35.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 2045 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_36")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold36 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 36/60")
					.button("Collect All");
				
				uiXpStorageGold36.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 2202 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_37")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold37 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 37/60")
					.button("Collect All");
				
				uiXpStorageGold37.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 2368 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_38")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold38 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 38/60")
					.button("Collect All");
				
				uiXpStorageGold38.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 2543 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_39")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold39 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 39/60")
					.button("Collect All");
				
				uiXpStorageGold39.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 2727 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_40")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold40 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 40/60")
					.button("Collect All");
				
				uiXpStorageGold40.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 2920 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_41")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold41 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 41/60")
					.button("Collect All");
				
				uiXpStorageGold41.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 3122 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_42")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold42 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 42/60")
					.button("Collect All");
				
				uiXpStorageGold42.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 3333 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_43")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold43 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 43/60")
					.button("Collect All");
				
				uiXpStorageGold43.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 3553 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_44")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold44 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 44/60")
					.button("Collect All");
				
				uiXpStorageGold44.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 3782 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_45")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold45 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 45/60")
					.button("Collect All");
				
				uiXpStorageGold45.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 4020 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_46")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold46 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 46/60")
					.button("Collect All");
				
				uiXpStorageGold46.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 4267 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_47")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold47 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 47/60")
					.button("Collect All");
				
				uiXpStorageGold47.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 4523 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_48")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold48 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 48/60")
					.button("Collect All");
				
				uiXpStorageGold48.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 4788 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_49")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold49 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 49/60")
					.button("Collect All");
				
				uiXpStorageGold49.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 5062 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_50")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold50 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 50/60")
					.button("Collect All");
				
				uiXpStorageGold50.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 5345 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_51")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold51 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 51/60")
					.button("Collect All");
				
				uiXpStorageGold51.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 5637 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_52")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold52 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 52/60")
					.button("Collect All");
				
				uiXpStorageGold52.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 5938 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_53")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold53 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 53/60")
					.button("Collect All");
				
				uiXpStorageGold53.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 6248 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_54")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold54 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 54/60")
					.button("Collect All");
				
				uiXpStorageGold54.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 6567 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_55")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold55 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 55/60")
					.button("Collect All");
				
				uiXpStorageGold55.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 6895 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_56")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold56 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 56/60")
					.button("Collect All");
				
				uiXpStorageGold56.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 7232 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_57")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold57 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 57/60")
					.button("Collect All");
				
				uiXpStorageGold57.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 7578 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_58")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold58 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 58/60")
					.button("Collect All");
				
				uiXpStorageGold58.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 7933 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_59")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold59 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 59/60")
					.button("Collect All");
				
				uiXpStorageGold59.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 8297 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_60")) {
				openForms.set(locationKey, true);

				const uiXpStorageGold60 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 60/60")
					.button("Collect All");
				
				uiXpStorageGold60.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_gold_xp_storage_0`);
							playerForm.runCommandAsync(`xp 8670 @s`);
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}












			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_0")) {
				openForms.set(locationKey, true);

				const uiXpStorageNetherite0 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 0/100")
					.button("Collect All");
				
				uiXpStorageNetherite0.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							break;
							
						default:
							
							break;
					}

					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_1")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite1 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 1/100")
					.button("Collect All");
				
				uiXpStorageNetherite1.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 7 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_2")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite2 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 2/100")
					.button("Collect All");
				
				uiXpStorageNetherite2.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 16 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_3")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite3 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 3/100")
					.button("Collect All");
				
				uiXpStorageNetherite3.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 27 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_4")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite4 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 4/100")
					.button("Collect All");
				
				uiXpStorageNetherite4.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 40 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_5")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite5 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 5/100")
					.button("Collect All");
				
				uiXpStorageNetherite5.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 55 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_6")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite6 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 6/100")
					.button("Collect All");
				
				uiXpStorageNetherite6.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 72 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_7")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite7 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 7/100")
					.button("Collect All");
				
				uiXpStorageNetherite7.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 91 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_8")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite8 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 8/100")
					.button("Collect All");
				
				uiXpStorageNetherite8.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 112 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_9")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite9 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 9/100")
					.button("Collect All");
				
				uiXpStorageNetherite9.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 135 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_10")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite10 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 10/100")
					.button("Collect All");
				
				uiXpStorageNetherite10.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 160 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_11")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite11 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 11/100")
					.button("Collect All");
				
				uiXpStorageNetherite11.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 187 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_12")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite12 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 12/100")
					.button("Collect All");
				
				uiXpStorageNetherite12.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 216 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_13")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite13 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 13/100")
					.button("Collect All");
				
				uiXpStorageNetherite13.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 247 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_14")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite14 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 14/100")
					.button("Collect All");
				
				uiXpStorageNetherite14.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 280 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_15")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite15 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 15/100")
					.button("Collect All");
				
				uiXpStorageNetherite15.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 315 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_16")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite16 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 16/100")
					.button("Collect All");
				
				uiXpStorageNetherite16.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 352 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_17")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite17 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 17/100")
					.button("Collect All");
				
				uiXpStorageNetherite17.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 394 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_18")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite18 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 18/100")
					.button("Collect All");
				
				uiXpStorageNetherite18.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 441 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_19")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite19 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 19/100")
					.button("Collect All");
				
				uiXpStorageNetherite19.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 493 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_20")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite20 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 20/100")
					.button("Collect All");
				
				uiXpStorageNetherite20.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 550 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_21")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite21 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 21/100")
					.button("Collect All");
				
				uiXpStorageNetherite21.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 612 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_22")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite22 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 22/100")
					.button("Collect All");
				
				uiXpStorageNetherite22.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 679 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_23")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite23 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 23/100")
					.button("Collect All");
				
				uiXpStorageNetherite23.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 751 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_24")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite24 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 24/100")
					.button("Collect All");
				
				uiXpStorageNetherite24.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 828 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_25")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite25 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 25/100")
					.button("Collect All");
				
				uiXpStorageNetherite25.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 910 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_26")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite26 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 26/100")
					.button("Collect All");
				
				uiXpStorageNetherite26.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 997 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_27")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite27 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 27/100")
					.button("Collect All");
				
				uiXpStorageNetherite27.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 1089 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_28")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite28 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 28/100")
					.button("Collect All");
				
				uiXpStorageNetherite28.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 1186 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_29")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite29 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 29/100")
					.button("Collect All");
				
				uiXpStorageNetherite29.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 1288 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_30")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite30 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 30/100")
					.button("Collect All");
				
				uiXpStorageNetherite30.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 1395 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_31")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite31 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 31/100")
					.button("Collect All");
				
				uiXpStorageNetherite31.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 1507 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_32")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite32 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 32/100")
					.button("Collect All");
				
				uiXpStorageNetherite32.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 1628 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_33")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite33 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 33/100")
					.button("Collect All");
				
				uiXpStorageNetherite33.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 1758 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_34")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite34 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 34/100")
					.button("Collect All");
				
				uiXpStorageNetherite34.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 1897 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_35")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite35 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 35/100")
					.button("Collect All");
				
				uiXpStorageNetherite35.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 2045 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_36")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite36 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 36/100")
					.button("Collect All");
				
				uiXpStorageNetherite36.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 2202 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_37")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite37 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 37/100")
					.button("Collect All");
				
				uiXpStorageNetherite37.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 2368 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_38")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite38 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 38/100")
					.button("Collect All");
				
				uiXpStorageNetherite38.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 2543 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_39")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite39 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 39/100")
					.button("Collect All");
				
				uiXpStorageNetherite39.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 2727 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_40")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite40 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 40/100")
					.button("Collect All");
				
				uiXpStorageNetherite40.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 2920 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_41")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite41 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 41/100")
					.button("Collect All");
				
				uiXpStorageNetherite41.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 3122 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_42")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite42 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 42/100")
					.button("Collect All");
				
				uiXpStorageNetherite42.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 3333 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_43")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite43 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 43/100")
					.button("Collect All");
				
				uiXpStorageNetherite43.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 3553 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_44")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite44 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 44/100")
					.button("Collect All");
				
				uiXpStorageNetherite44.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 3782 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_45")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite45 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 45/100")
					.button("Collect All");
				
				uiXpStorageNetherite45.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 4020 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_46")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite46 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 46/100")
					.button("Collect All");
				
				uiXpStorageNetherite46.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 4267 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_47")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite47 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 47/100")
					.button("Collect All");
				
				uiXpStorageNetherite47.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 4523 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_48")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite48 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 48/100")
					.button("Collect All");
				
				uiXpStorageNetherite48.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 4788 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_49")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite49 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 49/100")
					.button("Collect All");
				
				uiXpStorageNetherite49.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 5062 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_50")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite50 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 50/100")
					.button("Collect All");
				
				uiXpStorageNetherite50.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 5345 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_51")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite51 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 51/100")
					.button("Collect All");
				
				uiXpStorageNetherite51.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 5637 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_52")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite52 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 52/100")
					.button("Collect All");
				
				uiXpStorageNetherite52.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 5938 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_53")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite53 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 53/100")
					.button("Collect All");
				
				uiXpStorageNetherite53.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 6248 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_54")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite54 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 54/100")
					.button("Collect All");
				
				uiXpStorageNetherite54.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 6567 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_55")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite55 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 55/100")
					.button("Collect All");
				
				uiXpStorageNetherite55.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 6895 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_56")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite56 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 56/100")
					.button("Collect All");
				
				uiXpStorageNetherite56.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 7232 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_57")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite57 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 57/100")
					.button("Collect All");
				
				uiXpStorageNetherite57.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 7578 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_58")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite58 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 58/100")
					.button("Collect All");
				
				uiXpStorageNetherite58.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 7933 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_59")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite59 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 59/100")
					.button("Collect All");
				
				uiXpStorageNetherite59.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 8297 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_60")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite60 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 60/100")
					.button("Collect All");
				
				uiXpStorageNetherite60.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 8670 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_61")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite61 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 61/100")
					.button("Collect All");
				
				uiXpStorageNetherite61.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 9052 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_62")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite62 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 62/100")
					.button("Collect All");
				
				uiXpStorageNetherite62.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 9443 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_63")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite63 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 63/100")
					.button("Collect All");
				
				uiXpStorageNetherite63.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 9843 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_64")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite64 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 64/100")
					.button("Collect All");
				
				uiXpStorageNetherite64.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 10252 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_65")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite65 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 65/100")
					.button("Collect All");
				
				uiXpStorageNetherite65.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 10670 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_66")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite66 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 66/100")
					.button("Collect All");
				
				uiXpStorageNetherite66.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 11097 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_67")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite67 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 67/100")
					.button("Collect All");
				
				uiXpStorageNetherite67.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 11533 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_68")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite68 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 68/100")
					.button("Collect All");
				
				uiXpStorageNetherite68.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 11978 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_69")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite69 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 69/100")
					.button("Collect All");
				
				uiXpStorageNetherite69.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 12432 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_70")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite70 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 70/100")
					.button("Collect All");
				
				uiXpStorageNetherite70.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 12895 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_71")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite71 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 71/100")
					.button("Collect All");
				
				uiXpStorageNetherite71.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 13367 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_72")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite72 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 72/100")
					.button("Collect All");
				
				uiXpStorageNetherite72.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 13848 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_73")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite73 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 73/100")
					.button("Collect All");
				
				uiXpStorageNetherite73.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 14338 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_74")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite74 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 74/100")
					.button("Collect All");
				
				uiXpStorageNetherite74.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 14837 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_75")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite75 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 75/100")
					.button("Collect All");
				
				uiXpStorageNetherite75.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 15345 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_76")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite76 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 76/100")
					.button("Collect All");
				
				uiXpStorageNetherite76.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 15862 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_77")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite77 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 77/100")
					.button("Collect All");
				
				uiXpStorageNetherite77.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 16388 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_78")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite78 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 78/100")
					.button("Collect All");
				
				uiXpStorageNetherite78.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 16923 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_79")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite79 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 79/100")
					.button("Collect All");
				
				uiXpStorageNetherite79.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 17467 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_80")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite80 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 80/100")
					.button("Collect All");
				
				uiXpStorageNetherite80.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 18020 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			} else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_81")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite81 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 81/100")
					.button("Collect All");
				
				uiXpStorageNetherite81.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 18582 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_82")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite82 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 82/100")
					.button("Collect All");
				
				uiXpStorageNetherite82.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 19153 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_83")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite83 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 83/100")
					.button("Collect All");
				
				uiXpStorageNetherite83.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 19733 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_84")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite84 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 84/100")
					.button("Collect All");
				
				uiXpStorageNetherite84.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 20322 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_85")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite85 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 85/100")
					.button("Collect All");
				
				uiXpStorageNetherite85.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 20920 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_86")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite86 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 86/100")
					.button("Collect All");
				
				uiXpStorageNetherite86.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 21527 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_87")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite87 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 87/100")
					.button("Collect All");
				
				uiXpStorageNetherite87.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 22143 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_88")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite88 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 88/100")
					.button("Collect All");
				
				uiXpStorageNetherite88.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 22768 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_89")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite89 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 89/100")
					.button("Collect All");
				
				uiXpStorageNetherite89.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 23402 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_90")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite90 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 90/100")
					.button("Collect All");
				
				uiXpStorageNetherite90.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 24045 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_91")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite91 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 91/100")
					.button("Collect All");
				
				uiXpStorageNetherite91.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 24697 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_92")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite92 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 92/100")
					.button("Collect All");
				
				uiXpStorageNetherite92.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 25358 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_93")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite93 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 93/100")
					.button("Collect All");
				
				uiXpStorageNetherite93.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 26028 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_94")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite94 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 94/100")
					.button("Collect All");
				
				uiXpStorageNetherite94.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 26707 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_95")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite95 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 95/100")
					.button("Collect All");
				
				uiXpStorageNetherite95.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 27395 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_96")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite96 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 96/100")
					.button("Collect All");
				
				uiXpStorageNetherite96.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 28092 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_97")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite97 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 97/100")
					.button("Collect All");
				
				uiXpStorageNetherite97.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 28798 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_98")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite98 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 98/100")
					.button("Collect All");
				
				uiXpStorageNetherite98.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 29513 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_99")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite99 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 99/100")
					.button("Collect All");
				
				uiXpStorageNetherite99.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 30237 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
			
			
			else if (item?.typeId == "snailstudios_xp:xp_wrench" && blockBelowPlayer.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_100")) {
				openForms.set(locationKey, true);
			
				const uiXpStorageNetherite100 = new ActionFormData()
					.title("XP Storage")
					.body("Total levels stored: 100/100")
					.button("Collect All");
				
				uiXpStorageNetherite100.show(playerForm).then((baseForm) => {
					
					if (baseForm.canceled) {
						openForms.delete(locationKey);
					}
					switch (baseForm.selection) {
						case 0:
							playerForm.runCommandAsync(`setblock ${blockBelowPlayer.x} ${blockBelowPlayer.y} ${blockBelowPlayer.z} snailstudios_xp:snailstudios_netherite_xp_storage_0`);
							playerForm.runCommandAsync(`xp 30970 @s`);
							break;
							
						default:
							
							break;
					}
			
					
					openForms.delete(locationKey);
				}).catch((error) => {
					console.error("Error showing modal form:", error);
					openForms.delete(locationKey);
				});
			}
		}
	});




















//Handle all world events


const blockHandler = new BlockHandler();
const xpStoragePlacedHandler = new XpStoragePlacedHandler(blockHandler);
const xpFanAndGrinderMax = new XPFanAndGrinderMax(blockHandler);
const entityChecker = new EntityChecker(blockHandler, xpStoragePlacedHandler, toggleButton, indexEntities, toggleButtonFalse, toggleButtonTrue, returnindexEntites);


system.afterEvents.scriptEventReceive.subscribe(event => {
    const { id, message } = event;

    // Check if the event ID and message match
    if (id === "snailstudios:reset" && message === "addon") {
		xpFanAndGrinderMax.resetLocationForGrindersAndFans()
		xpStoragePlacedHandler.resetLocationOfMainXp()
		blockHandler.resetLocationOfMainSmartSpawner()

		world.sendMessage("Smart spawner setup reset!");
    }
});

world.afterEvents.playerSpawn.subscribe(blockHandler.handlePlayerJoin.bind(blockHandler));
world.afterEvents.playerSpawn.subscribe(xpStoragePlacedHandler.handlePlayerJoinXp.bind(xpStoragePlacedHandler));
world.afterEvents.playerSpawn.subscribe(xpFanAndGrinderMax.handlePlayerJoinSetGrinderAndFan.bind(xpFanAndGrinderMax));

// Subscribe to the block break event
world.afterEvents.playerBreakBlock.subscribe(blockHandler.handleBreakBlock.bind(blockHandler), {
	blockTypes: ["snailstudios_xp:snailstudios_xp_grinder_brain"]
});


world.afterEvents.playerBreakBlock.subscribe(xpFanAndGrinderMax.handleBreakFanAndGrinder.bind(xpFanAndGrinderMax), {
	blockTypes: [
		"snailstudios_xp:fan_block",
		"snailstudios_xp:grinder_block",
		"snailstudios_xp:grinder_block_gold",
		"snailstudios_xp:grinder_block_netherite"
	]
});

world.afterEvents.playerBreakBlock.subscribe(xpStoragePlacedHandler.handleMainXpBreak.bind(xpStoragePlacedHandler), {
	blockTypes: [
		"snailstudios_xp:snailstudios_iron_xp_storage_0",
		"snailstudios_xp:snailstudios_iron_xp_storage_1",
		"snailstudios_xp:snailstudios_iron_xp_storage_2",
		"snailstudios_xp:snailstudios_iron_xp_storage_3",
		"snailstudios_xp:snailstudios_iron_xp_storage_4",
		"snailstudios_xp:snailstudios_iron_xp_storage_5",
		"snailstudios_xp:snailstudios_iron_xp_storage_6",
		"snailstudios_xp:snailstudios_iron_xp_storage_7",
		"snailstudios_xp:snailstudios_iron_xp_storage_8",
		"snailstudios_xp:snailstudios_iron_xp_storage_9",
		"snailstudios_xp:snailstudios_iron_xp_storage_10",
		"snailstudios_xp:snailstudios_iron_xp_storage_11",
		"snailstudios_xp:snailstudios_iron_xp_storage_12",
		"snailstudios_xp:snailstudios_iron_xp_storage_13",
		"snailstudios_xp:snailstudios_iron_xp_storage_14",
		"snailstudios_xp:snailstudios_iron_xp_storage_15",
		"snailstudios_xp:snailstudios_iron_xp_storage_16",
		"snailstudios_xp:snailstudios_iron_xp_storage_17",
		"snailstudios_xp:snailstudios_iron_xp_storage_18",
		"snailstudios_xp:snailstudios_iron_xp_storage_19",
		"snailstudios_xp:snailstudios_iron_xp_storage_20",
		"snailstudios_xp:snailstudios_iron_xp_storage_21",
		"snailstudios_xp:snailstudios_iron_xp_storage_22",
		"snailstudios_xp:snailstudios_iron_xp_storage_23",
		"snailstudios_xp:snailstudios_iron_xp_storage_24",
		"snailstudios_xp:snailstudios_iron_xp_storage_25",
		"snailstudios_xp:snailstudios_iron_xp_storage_26",
		"snailstudios_xp:snailstudios_iron_xp_storage_27",
		"snailstudios_xp:snailstudios_iron_xp_storage_28",
		"snailstudios_xp:snailstudios_iron_xp_storage_29",
		"snailstudios_xp:snailstudios_iron_xp_storage_30",
		"snailstudios_xp:snailstudios_gold_xp_storage_0",
		"snailstudios_xp:snailstudios_gold_xp_storage_1",
		"snailstudios_xp:snailstudios_gold_xp_storage_2",
		"snailstudios_xp:snailstudios_gold_xp_storage_3",
		"snailstudios_xp:snailstudios_gold_xp_storage_4",
		"snailstudios_xp:snailstudios_gold_xp_storage_5",
		"snailstudios_xp:snailstudios_gold_xp_storage_6",
		"snailstudios_xp:snailstudios_gold_xp_storage_7",
		"snailstudios_xp:snailstudios_gold_xp_storage_8",
		"snailstudios_xp:snailstudios_gold_xp_storage_9",
		"snailstudios_xp:snailstudios_gold_xp_storage_10",
		"snailstudios_xp:snailstudios_gold_xp_storage_11",
		"snailstudios_xp:snailstudios_gold_xp_storage_12",
		"snailstudios_xp:snailstudios_gold_xp_storage_13",
		"snailstudios_xp:snailstudios_gold_xp_storage_14",
		"snailstudios_xp:snailstudios_gold_xp_storage_15",
		"snailstudios_xp:snailstudios_gold_xp_storage_16",
		"snailstudios_xp:snailstudios_gold_xp_storage_17",
		"snailstudios_xp:snailstudios_gold_xp_storage_18",
		"snailstudios_xp:snailstudios_gold_xp_storage_19",
		"snailstudios_xp:snailstudios_gold_xp_storage_20",
		"snailstudios_xp:snailstudios_gold_xp_storage_21",
		"snailstudios_xp:snailstudios_gold_xp_storage_22",
		"snailstudios_xp:snailstudios_gold_xp_storage_23",
		"snailstudios_xp:snailstudios_gold_xp_storage_24",
		"snailstudios_xp:snailstudios_gold_xp_storage_25",
		"snailstudios_xp:snailstudios_gold_xp_storage_26",
		"snailstudios_xp:snailstudios_gold_xp_storage_27",
		"snailstudios_xp:snailstudios_gold_xp_storage_28",
		"snailstudios_xp:snailstudios_gold_xp_storage_29",
		"snailstudios_xp:snailstudios_gold_xp_storage_30",
		"snailstudios_xp:snailstudios_gold_xp_storage_31",
		"snailstudios_xp:snailstudios_gold_xp_storage_32",
		"snailstudios_xp:snailstudios_gold_xp_storage_33",
		"snailstudios_xp:snailstudios_gold_xp_storage_34",
		"snailstudios_xp:snailstudios_gold_xp_storage_35",
		"snailstudios_xp:snailstudios_gold_xp_storage_36",
		"snailstudios_xp:snailstudios_gold_xp_storage_37",
		"snailstudios_xp:snailstudios_gold_xp_storage_38",
		"snailstudios_xp:snailstudios_gold_xp_storage_39",
		"snailstudios_xp:snailstudios_gold_xp_storage_40",
		"snailstudios_xp:snailstudios_gold_xp_storage_41",
		"snailstudios_xp:snailstudios_gold_xp_storage_42",
		"snailstudios_xp:snailstudios_gold_xp_storage_43",
		"snailstudios_xp:snailstudios_gold_xp_storage_44",
		"snailstudios_xp:snailstudios_gold_xp_storage_45",
		"snailstudios_xp:snailstudios_gold_xp_storage_46",
		"snailstudios_xp:snailstudios_gold_xp_storage_47",
		"snailstudios_xp:snailstudios_gold_xp_storage_48",
		"snailstudios_xp:snailstudios_gold_xp_storage_49",
		"snailstudios_xp:snailstudios_gold_xp_storage_50",
		"snailstudios_xp:snailstudios_gold_xp_storage_51",
		"snailstudios_xp:snailstudios_gold_xp_storage_52",
		"snailstudios_xp:snailstudios_gold_xp_storage_53",
		"snailstudios_xp:snailstudios_gold_xp_storage_54",
		"snailstudios_xp:snailstudios_gold_xp_storage_55",
		"snailstudios_xp:snailstudios_gold_xp_storage_56",
		"snailstudios_xp:snailstudios_gold_xp_storage_57",
		"snailstudios_xp:snailstudios_gold_xp_storage_58",
		"snailstudios_xp:snailstudios_gold_xp_storage_59",
		"snailstudios_xp:snailstudios_gold_xp_storage_60",
		"snailstudios_xp:snailstudios_netherite_xp_storage_0",
		"snailstudios_xp:snailstudios_netherite_xp_storage_1",
		"snailstudios_xp:snailstudios_netherite_xp_storage_2",
		"snailstudios_xp:snailstudios_netherite_xp_storage_3",
		"snailstudios_xp:snailstudios_netherite_xp_storage_4",
		"snailstudios_xp:snailstudios_netherite_xp_storage_5",
		"snailstudios_xp:snailstudios_netherite_xp_storage_6",
		"snailstudios_xp:snailstudios_netherite_xp_storage_7",
		"snailstudios_xp:snailstudios_netherite_xp_storage_8",
		"snailstudios_xp:snailstudios_netherite_xp_storage_9",
		"snailstudios_xp:snailstudios_netherite_xp_storage_10",
		"snailstudios_xp:snailstudios_netherite_xp_storage_11",
		"snailstudios_xp:snailstudios_netherite_xp_storage_12",
		"snailstudios_xp:snailstudios_netherite_xp_storage_13",
		"snailstudios_xp:snailstudios_netherite_xp_storage_14",
		"snailstudios_xp:snailstudios_netherite_xp_storage_15",
		"snailstudios_xp:snailstudios_netherite_xp_storage_16",
		"snailstudios_xp:snailstudios_netherite_xp_storage_17",
		"snailstudios_xp:snailstudios_netherite_xp_storage_18",
		"snailstudios_xp:snailstudios_netherite_xp_storage_19",
		"snailstudios_xp:snailstudios_netherite_xp_storage_20",
		"snailstudios_xp:snailstudios_netherite_xp_storage_21",
		"snailstudios_xp:snailstudios_netherite_xp_storage_22",
		"snailstudios_xp:snailstudios_netherite_xp_storage_23",
		"snailstudios_xp:snailstudios_netherite_xp_storage_24",
		"snailstudios_xp:snailstudios_netherite_xp_storage_25",
		"snailstudios_xp:snailstudios_netherite_xp_storage_26",
		"snailstudios_xp:snailstudios_netherite_xp_storage_27",
		"snailstudios_xp:snailstudios_netherite_xp_storage_28",
		"snailstudios_xp:snailstudios_netherite_xp_storage_29",
		"snailstudios_xp:snailstudios_netherite_xp_storage_30",
		"snailstudios_xp:snailstudios_netherite_xp_storage_31",
		"snailstudios_xp:snailstudios_netherite_xp_storage_32",
		"snailstudios_xp:snailstudios_netherite_xp_storage_33",
		"snailstudios_xp:snailstudios_netherite_xp_storage_34",
		"snailstudios_xp:snailstudios_netherite_xp_storage_35",
		"snailstudios_xp:snailstudios_netherite_xp_storage_36",
		"snailstudios_xp:snailstudios_netherite_xp_storage_37",
		"snailstudios_xp:snailstudios_netherite_xp_storage_38",
		"snailstudios_xp:snailstudios_netherite_xp_storage_39",
		"snailstudios_xp:snailstudios_netherite_xp_storage_40",
		"snailstudios_xp:snailstudios_netherite_xp_storage_41",
		"snailstudios_xp:snailstudios_netherite_xp_storage_42",
		"snailstudios_xp:snailstudios_netherite_xp_storage_43",
		"snailstudios_xp:snailstudios_netherite_xp_storage_44",
		"snailstudios_xp:snailstudios_netherite_xp_storage_45",
		"snailstudios_xp:snailstudios_netherite_xp_storage_46",
		"snailstudios_xp:snailstudios_netherite_xp_storage_47",
		"snailstudios_xp:snailstudios_netherite_xp_storage_48",
		"snailstudios_xp:snailstudios_netherite_xp_storage_49",
		"snailstudios_xp:snailstudios_netherite_xp_storage_50",
		"snailstudios_xp:snailstudios_netherite_xp_storage_51",
		"snailstudios_xp:snailstudios_netherite_xp_storage_52",
		"snailstudios_xp:snailstudios_netherite_xp_storage_53",
		"snailstudios_xp:snailstudios_netherite_xp_storage_54",
		"snailstudios_xp:snailstudios_netherite_xp_storage_55",
		"snailstudios_xp:snailstudios_netherite_xp_storage_56",
		"snailstudios_xp:snailstudios_netherite_xp_storage_57",
		"snailstudios_xp:snailstudios_netherite_xp_storage_58",
		"snailstudios_xp:snailstudios_netherite_xp_storage_59",
		"snailstudios_xp:snailstudios_netherite_xp_storage_60",
		"snailstudios_xp:snailstudios_netherite_xp_storage_61",
		"snailstudios_xp:snailstudios_netherite_xp_storage_62",
		"snailstudios_xp:snailstudios_netherite_xp_storage_63",
		"snailstudios_xp:snailstudios_netherite_xp_storage_64",
		"snailstudios_xp:snailstudios_netherite_xp_storage_65",
		"snailstudios_xp:snailstudios_netherite_xp_storage_66",
		"snailstudios_xp:snailstudios_netherite_xp_storage_67",
		"snailstudios_xp:snailstudios_netherite_xp_storage_68",
		"snailstudios_xp:snailstudios_netherite_xp_storage_69",
		"snailstudios_xp:snailstudios_netherite_xp_storage_70",
		"snailstudios_xp:snailstudios_netherite_xp_storage_71",
		"snailstudios_xp:snailstudios_netherite_xp_storage_72",
		"snailstudios_xp:snailstudios_netherite_xp_storage_73",
		"snailstudios_xp:snailstudios_netherite_xp_storage_74",
		"snailstudios_xp:snailstudios_netherite_xp_storage_75",
		"snailstudios_xp:snailstudios_netherite_xp_storage_76",
		"snailstudios_xp:snailstudios_netherite_xp_storage_77",
		"snailstudios_xp:snailstudios_netherite_xp_storage_78",
		"snailstudios_xp:snailstudios_netherite_xp_storage_79",
		"snailstudios_xp:snailstudios_netherite_xp_storage_80",
		"snailstudios_xp:snailstudios_netherite_xp_storage_81",
		"snailstudios_xp:snailstudios_netherite_xp_storage_82",
		"snailstudios_xp:snailstudios_netherite_xp_storage_83",
		"snailstudios_xp:snailstudios_netherite_xp_storage_84",
		"snailstudios_xp:snailstudios_netherite_xp_storage_85",
		"snailstudios_xp:snailstudios_netherite_xp_storage_86",
		"snailstudios_xp:snailstudios_netherite_xp_storage_87",
		"snailstudios_xp:snailstudios_netherite_xp_storage_88",
		"snailstudios_xp:snailstudios_netherite_xp_storage_89",
		"snailstudios_xp:snailstudios_netherite_xp_storage_90",
		"snailstudios_xp:snailstudios_netherite_xp_storage_91",
		"snailstudios_xp:snailstudios_netherite_xp_storage_92",
		"snailstudios_xp:snailstudios_netherite_xp_storage_93",
		"snailstudios_xp:snailstudios_netherite_xp_storage_94",
		"snailstudios_xp:snailstudios_netherite_xp_storage_95",
		"snailstudios_xp:snailstudios_netherite_xp_storage_96",
		"snailstudios_xp:snailstudios_netherite_xp_storage_97",
		"snailstudios_xp:snailstudios_netherite_xp_storage_98",
		"snailstudios_xp:snailstudios_netherite_xp_storage_99",
		"snailstudios_xp:snailstudios_netherite_xp_storage_100",

	]
});

world.afterEvents.playerPlaceBlock.subscribe(xpStoragePlacedHandler.onBlockPlaced.bind(xpStoragePlacedHandler), {
	blockTypes: [
		"snailstudios_xp:snailstudios_iron_xp_storage_0",
		"snailstudios_xp:snailstudios_iron_xp_storage_1",
		"snailstudios_xp:snailstudios_iron_xp_storage_2",
		"snailstudios_xp:snailstudios_iron_xp_storage_3",
		"snailstudios_xp:snailstudios_iron_xp_storage_4",
		"snailstudios_xp:snailstudios_iron_xp_storage_5",
		"snailstudios_xp:snailstudios_iron_xp_storage_6",
		"snailstudios_xp:snailstudios_iron_xp_storage_7",
		"snailstudios_xp:snailstudios_iron_xp_storage_8",
		"snailstudios_xp:snailstudios_iron_xp_storage_9",
		"snailstudios_xp:snailstudios_iron_xp_storage_10",
		"snailstudios_xp:snailstudios_iron_xp_storage_11",
		"snailstudios_xp:snailstudios_iron_xp_storage_12",
		"snailstudios_xp:snailstudios_iron_xp_storage_13",
		"snailstudios_xp:snailstudios_iron_xp_storage_14",
		"snailstudios_xp:snailstudios_iron_xp_storage_15",
		"snailstudios_xp:snailstudios_iron_xp_storage_16",
		"snailstudios_xp:snailstudios_iron_xp_storage_17",
		"snailstudios_xp:snailstudios_iron_xp_storage_18",
		"snailstudios_xp:snailstudios_iron_xp_storage_19",
		"snailstudios_xp:snailstudios_iron_xp_storage_20",
		"snailstudios_xp:snailstudios_iron_xp_storage_21",
		"snailstudios_xp:snailstudios_iron_xp_storage_22",
		"snailstudios_xp:snailstudios_iron_xp_storage_23",
		"snailstudios_xp:snailstudios_iron_xp_storage_24",
		"snailstudios_xp:snailstudios_iron_xp_storage_25",
		"snailstudios_xp:snailstudios_iron_xp_storage_26",
		"snailstudios_xp:snailstudios_iron_xp_storage_27",
		"snailstudios_xp:snailstudios_iron_xp_storage_28",
		"snailstudios_xp:snailstudios_iron_xp_storage_29",
		"snailstudios_xp:snailstudios_iron_xp_storage_30",
		"snailstudios_xp:snailstudios_gold_xp_storage_0",
		"snailstudios_xp:snailstudios_gold_xp_storage_1",
		"snailstudios_xp:snailstudios_gold_xp_storage_2",
		"snailstudios_xp:snailstudios_gold_xp_storage_3",
		"snailstudios_xp:snailstudios_gold_xp_storage_4",
		"snailstudios_xp:snailstudios_gold_xp_storage_5",
		"snailstudios_xp:snailstudios_gold_xp_storage_6",
		"snailstudios_xp:snailstudios_gold_xp_storage_7",
		"snailstudios_xp:snailstudios_gold_xp_storage_8",
		"snailstudios_xp:snailstudios_gold_xp_storage_9",
		"snailstudios_xp:snailstudios_gold_xp_storage_10",
		"snailstudios_xp:snailstudios_gold_xp_storage_11",
		"snailstudios_xp:snailstudios_gold_xp_storage_12",
		"snailstudios_xp:snailstudios_gold_xp_storage_13",
		"snailstudios_xp:snailstudios_gold_xp_storage_14",
		"snailstudios_xp:snailstudios_gold_xp_storage_15",
		"snailstudios_xp:snailstudios_gold_xp_storage_16",
		"snailstudios_xp:snailstudios_gold_xp_storage_17",
		"snailstudios_xp:snailstudios_gold_xp_storage_18",
		"snailstudios_xp:snailstudios_gold_xp_storage_19",
		"snailstudios_xp:snailstudios_gold_xp_storage_20",
		"snailstudios_xp:snailstudios_gold_xp_storage_21",
		"snailstudios_xp:snailstudios_gold_xp_storage_22",
		"snailstudios_xp:snailstudios_gold_xp_storage_23",
		"snailstudios_xp:snailstudios_gold_xp_storage_24",
		"snailstudios_xp:snailstudios_gold_xp_storage_25",
		"snailstudios_xp:snailstudios_gold_xp_storage_26",
		"snailstudios_xp:snailstudios_gold_xp_storage_27",
		"snailstudios_xp:snailstudios_gold_xp_storage_28",
		"snailstudios_xp:snailstudios_gold_xp_storage_29",
		"snailstudios_xp:snailstudios_gold_xp_storage_30",
		"snailstudios_xp:snailstudios_gold_xp_storage_31",
		"snailstudios_xp:snailstudios_gold_xp_storage_32",
		"snailstudios_xp:snailstudios_gold_xp_storage_33",
		"snailstudios_xp:snailstudios_gold_xp_storage_34",
		"snailstudios_xp:snailstudios_gold_xp_storage_35",
		"snailstudios_xp:snailstudios_gold_xp_storage_36",
		"snailstudios_xp:snailstudios_gold_xp_storage_37",
		"snailstudios_xp:snailstudios_gold_xp_storage_38",
		"snailstudios_xp:snailstudios_gold_xp_storage_39",
		"snailstudios_xp:snailstudios_gold_xp_storage_40",
		"snailstudios_xp:snailstudios_gold_xp_storage_41",
		"snailstudios_xp:snailstudios_gold_xp_storage_42",
		"snailstudios_xp:snailstudios_gold_xp_storage_43",
		"snailstudios_xp:snailstudios_gold_xp_storage_44",
		"snailstudios_xp:snailstudios_gold_xp_storage_45",
		"snailstudios_xp:snailstudios_gold_xp_storage_46",
		"snailstudios_xp:snailstudios_gold_xp_storage_47",
		"snailstudios_xp:snailstudios_gold_xp_storage_48",
		"snailstudios_xp:snailstudios_gold_xp_storage_49",
		"snailstudios_xp:snailstudios_gold_xp_storage_50",
		"snailstudios_xp:snailstudios_gold_xp_storage_51",
		"snailstudios_xp:snailstudios_gold_xp_storage_52",
		"snailstudios_xp:snailstudios_gold_xp_storage_53",
		"snailstudios_xp:snailstudios_gold_xp_storage_54",
		"snailstudios_xp:snailstudios_gold_xp_storage_55",
		"snailstudios_xp:snailstudios_gold_xp_storage_56",
		"snailstudios_xp:snailstudios_gold_xp_storage_57",
		"snailstudios_xp:snailstudios_gold_xp_storage_58",
		"snailstudios_xp:snailstudios_gold_xp_storage_59",
		"snailstudios_xp:snailstudios_gold_xp_storage_60",
		"snailstudios_xp:snailstudios_netherite_xp_storage_0",
		"snailstudios_xp:snailstudios_netherite_xp_storage_1",
		"snailstudios_xp:snailstudios_netherite_xp_storage_2",
		"snailstudios_xp:snailstudios_netherite_xp_storage_3",
		"snailstudios_xp:snailstudios_netherite_xp_storage_4",
		"snailstudios_xp:snailstudios_netherite_xp_storage_5",
		"snailstudios_xp:snailstudios_netherite_xp_storage_6",
		"snailstudios_xp:snailstudios_netherite_xp_storage_7",
		"snailstudios_xp:snailstudios_netherite_xp_storage_8",
		"snailstudios_xp:snailstudios_netherite_xp_storage_9",
		"snailstudios_xp:snailstudios_netherite_xp_storage_10",
		"snailstudios_xp:snailstudios_netherite_xp_storage_11",
		"snailstudios_xp:snailstudios_netherite_xp_storage_12",
		"snailstudios_xp:snailstudios_netherite_xp_storage_13",
		"snailstudios_xp:snailstudios_netherite_xp_storage_14",
		"snailstudios_xp:snailstudios_netherite_xp_storage_15",
		"snailstudios_xp:snailstudios_netherite_xp_storage_16",
		"snailstudios_xp:snailstudios_netherite_xp_storage_17",
		"snailstudios_xp:snailstudios_netherite_xp_storage_18",
		"snailstudios_xp:snailstudios_netherite_xp_storage_19",
		"snailstudios_xp:snailstudios_netherite_xp_storage_20",
		"snailstudios_xp:snailstudios_netherite_xp_storage_21",
		"snailstudios_xp:snailstudios_netherite_xp_storage_22",
		"snailstudios_xp:snailstudios_netherite_xp_storage_23",
		"snailstudios_xp:snailstudios_netherite_xp_storage_24",
		"snailstudios_xp:snailstudios_netherite_xp_storage_25",
		"snailstudios_xp:snailstudios_netherite_xp_storage_26",
		"snailstudios_xp:snailstudios_netherite_xp_storage_27",
		"snailstudios_xp:snailstudios_netherite_xp_storage_28",
		"snailstudios_xp:snailstudios_netherite_xp_storage_29",
		"snailstudios_xp:snailstudios_netherite_xp_storage_30",
		"snailstudios_xp:snailstudios_netherite_xp_storage_31",
		"snailstudios_xp:snailstudios_netherite_xp_storage_32",
		"snailstudios_xp:snailstudios_netherite_xp_storage_33",
		"snailstudios_xp:snailstudios_netherite_xp_storage_34",
		"snailstudios_xp:snailstudios_netherite_xp_storage_35",
		"snailstudios_xp:snailstudios_netherite_xp_storage_36",
		"snailstudios_xp:snailstudios_netherite_xp_storage_37",
		"snailstudios_xp:snailstudios_netherite_xp_storage_38",
		"snailstudios_xp:snailstudios_netherite_xp_storage_39",
		"snailstudios_xp:snailstudios_netherite_xp_storage_40",
		"snailstudios_xp:snailstudios_netherite_xp_storage_41",
		"snailstudios_xp:snailstudios_netherite_xp_storage_42",
		"snailstudios_xp:snailstudios_netherite_xp_storage_43",
		"snailstudios_xp:snailstudios_netherite_xp_storage_44",
		"snailstudios_xp:snailstudios_netherite_xp_storage_45",
		"snailstudios_xp:snailstudios_netherite_xp_storage_46",
		"snailstudios_xp:snailstudios_netherite_xp_storage_47",
		"snailstudios_xp:snailstudios_netherite_xp_storage_48",
		"snailstudios_xp:snailstudios_netherite_xp_storage_49",
		"snailstudios_xp:snailstudios_netherite_xp_storage_50",
		"snailstudios_xp:snailstudios_netherite_xp_storage_51",
		"snailstudios_xp:snailstudios_netherite_xp_storage_52",
		"snailstudios_xp:snailstudios_netherite_xp_storage_53",
		"snailstudios_xp:snailstudios_netherite_xp_storage_54",
		"snailstudios_xp:snailstudios_netherite_xp_storage_55",
		"snailstudios_xp:snailstudios_netherite_xp_storage_56",
		"snailstudios_xp:snailstudios_netherite_xp_storage_57",
		"snailstudios_xp:snailstudios_netherite_xp_storage_58",
		"snailstudios_xp:snailstudios_netherite_xp_storage_59",
		"snailstudios_xp:snailstudios_netherite_xp_storage_60",
		"snailstudios_xp:snailstudios_netherite_xp_storage_61",
		"snailstudios_xp:snailstudios_netherite_xp_storage_62",
		"snailstudios_xp:snailstudios_netherite_xp_storage_63",
		"snailstudios_xp:snailstudios_netherite_xp_storage_64",
		"snailstudios_xp:snailstudios_netherite_xp_storage_65",
		"snailstudios_xp:snailstudios_netherite_xp_storage_66",
		"snailstudios_xp:snailstudios_netherite_xp_storage_67",
		"snailstudios_xp:snailstudios_netherite_xp_storage_68",
		"snailstudios_xp:snailstudios_netherite_xp_storage_69",
		"snailstudios_xp:snailstudios_netherite_xp_storage_70",
		"snailstudios_xp:snailstudios_netherite_xp_storage_71",
		"snailstudios_xp:snailstudios_netherite_xp_storage_72",
		"snailstudios_xp:snailstudios_netherite_xp_storage_73",
		"snailstudios_xp:snailstudios_netherite_xp_storage_74",
		"snailstudios_xp:snailstudios_netherite_xp_storage_75",
		"snailstudios_xp:snailstudios_netherite_xp_storage_76",
		"snailstudios_xp:snailstudios_netherite_xp_storage_77",
		"snailstudios_xp:snailstudios_netherite_xp_storage_78",
		"snailstudios_xp:snailstudios_netherite_xp_storage_79",
		"snailstudios_xp:snailstudios_netherite_xp_storage_80",
		"snailstudios_xp:snailstudios_netherite_xp_storage_81",
		"snailstudios_xp:snailstudios_netherite_xp_storage_82",
		"snailstudios_xp:snailstudios_netherite_xp_storage_83",
		"snailstudios_xp:snailstudios_netherite_xp_storage_84",
		"snailstudios_xp:snailstudios_netherite_xp_storage_85",
		"snailstudios_xp:snailstudios_netherite_xp_storage_86",
		"snailstudios_xp:snailstudios_netherite_xp_storage_87",
		"snailstudios_xp:snailstudios_netherite_xp_storage_88",
		"snailstudios_xp:snailstudios_netherite_xp_storage_89",
		"snailstudios_xp:snailstudios_netherite_xp_storage_90",
		"snailstudios_xp:snailstudios_netherite_xp_storage_91",
		"snailstudios_xp:snailstudios_netherite_xp_storage_92",
		"snailstudios_xp:snailstudios_netherite_xp_storage_93",
		"snailstudios_xp:snailstudios_netherite_xp_storage_94",
		"snailstudios_xp:snailstudios_netherite_xp_storage_95",
		"snailstudios_xp:snailstudios_netherite_xp_storage_96",
		"snailstudios_xp:snailstudios_netherite_xp_storage_97",
		"snailstudios_xp:snailstudios_netherite_xp_storage_98",
		"snailstudios_xp:snailstudios_netherite_xp_storage_99",
		"snailstudios_xp:snailstudios_netherite_xp_storage_100",
	]
});


// Subscribe to the block placement event
world.afterEvents.playerPlaceBlock.subscribe(blockHandler.handlePlaceBlock.bind(blockHandler), {
	blockTypes: ["snailstudios_xp:snailstudios_xp_grinder_brain"]
});

// Subscribe to the block placement event
world.afterEvents.playerPlaceBlock.subscribe(xpFanAndGrinderMax.handlePlaceFanAndGrinder.bind(xpFanAndGrinderMax), {
	blockTypes: [
		"snailstudios_xp:fan_block",
		"snailstudios_xp:grinder_block",
		"snailstudios_xp:grinder_block_gold",
		"snailstudios_xp:grinder_block_netherite"
	]
});
