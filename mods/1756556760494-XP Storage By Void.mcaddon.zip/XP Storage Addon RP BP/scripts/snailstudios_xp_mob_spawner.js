import { system, world } from "@minecraft/server";
import { BlockHandler, XpStoragePlacedHandler } from './snailstudios_xp_storage.js';
import { toggleButton, indexEntities } from "./snailstudios_xp_storage.js";

class EntityChecker {
	constructor(blockHandler, XpStoragePlacedHandler, toggleButton, indexEntities, toggleButtonFalse, toggleButtonTrue, returnindexEntites) {
		this.entityCount = 0;
		this.blockHandler = blockHandler; // Store the BlockHandler instance
		this.XpStoragePlacedHandler = XpStoragePlacedHandler; // Store the BlockHandler instance
		this.toggleButton = toggleButton;
		this.indexEntities = indexEntities;
		this.toggleButtonFalse = toggleButtonFalse;
		this.toggleButtonTrue = toggleButtonTrue;
		this.returnindexEntites = returnindexEntites;

		const xpMainBrain = this.blockHandler.getStoredLocation();
		const xpMainDimension = this.blockHandler.getStoredDimension();
		const xpMainStorage = this.XpStoragePlacedHandler.getStoredLocationOfXp();

		this.systemRunner = null;

		// Check if either xpMainBrain or xpMainStorage is null
		if (xpMainBrain === null || xpMainStorage === null) {
			// Log a message or handle as needed, and exit the constructor
			this.stopMobSpawner();
		}

		if (this.toggleButton) {
			this.runMobSpawner();
		}



		world.afterEvents.entityDie.subscribe(({
			deadEntity
		}) => {
			this.checkEntityDeath(deadEntity);
		});
	}

	checkEntityDeath(deadEntity) {

		if (
		deadEntity.typeId === 'minecraft:sheep' ||
		deadEntity.typeId === 'minecraft:cow' ||
		deadEntity.typeId === 'minecraft:pig' ||
		deadEntity.typeId === 'minecraft:chicken'||
		deadEntity.typeId === 'minecraft:zombie' ||
		deadEntity.typeId === 'minecraft:guardian' ||
		deadEntity.typeId === 'minecraft:skeleton' ||
		deadEntity.typeId === 'minecraft:spider' ||
		deadEntity.typeId === 'minecraft:cave_spider' ||
		deadEntity.typeId === 'minecraft:witch' ||
		deadEntity.typeId === 'minecraft:wither_skeleton' ||
		deadEntity.typeId === 'minecraft:vindicator' ||
		deadEntity.typeId === 'minecraft:creeper'||
		deadEntity.typeId === 'minecraft:zombie_pigman'||
		deadEntity.typeId === 'minecraft:enderman'||
		deadEntity.typeId === 'minecraft:blaze' ||
		deadEntity.typeId === 'minecraft:evocation_illager' ||
		deadEntity.typeId === 'minecraft:pillager' ||
		deadEntity.typeId === 'minecraft:ravager') {
		const xpEntity = deadEntity.location;
		const xpGrinderLocation = this.blockHandler.getStoredLocation(); // Access stored location using the shared BlockHandler instance

		const xpMainStorageLocation = this.XpStoragePlacedHandler.getStoredLocationOfXp(); // Access stored location using the shared BlockHandler instance

		if (xpMainStorageLocation !== null) {
			const xpMainDimension = this.blockHandler.getStoredDimension();
			const blockXpLocationSet = world.getDimension(xpMainDimension).getBlock(xpMainStorageLocation);

			const distanceX = Math.abs(xpEntity.x - xpGrinderLocation.x);
			const distanceY = Math.abs(xpEntity.y - xpGrinderLocation.y);
			const distanceZ = Math.abs(xpEntity.z - xpGrinderLocation.z);

			// Calculate distance between sheep death location and xp grinder
			const distance = Math.sqrt(distanceX * distanceX + distanceY * distanceY + distanceZ * distanceZ);


			if (distance <= 5 &&
				(deadEntity.typeId === 'minecraft:slime')) {
				this.entityCount += 1;
			}

			if (distance <= 5 &&
				(deadEntity.typeId === 'minecraft:sheep' ||
					deadEntity.typeId === 'minecraft:cow' ||
					deadEntity.typeId === 'minecraft:pig' ||
					deadEntity.typeId === 'minecraft:chicken')) {
				this.entityCount += 2;
			}

			if (distance <= 5 &&
				(deadEntity.typeId === 'minecraft:zombie' ||
					deadEntity.typeId === 'minecraft:guardian' ||
					deadEntity.typeId === 'minecraft:skeleton' ||
					deadEntity.typeId === 'minecraft:spider' ||
					deadEntity.typeId === 'minecraft:cave_spider' ||
					deadEntity.typeId === 'minecraft:witch' ||
					deadEntity.typeId === 'minecraft:wither_skeleton' ||
					deadEntity.typeId === 'minecraft:vindicator' ||
					deadEntity.typeId === 'minecraft:creeper')) {
				this.entityCount += 5;
			}

			if (distance <= 5 &&
				(deadEntity.typeId === 'minecraft:zombie_pigman')) {
				this.entityCount += 6;
			}

			if (distance <= 5 &&
				(deadEntity.typeId === 'minecraft:enderman')) {
				this.entityCount += 8;
			}

			if (distance <= 5 &&
				(deadEntity.typeId === 'minecraft:blaze' ||
				deadEntity.typeId === 'minecraft:evocation_illager' ||
				deadEntity.typeId === 'minecraft:pillager')) {
				this.entityCount += 10;
			}

			if (distance <= 5 &&
				(deadEntity.typeId === 'minecraft:ravager')) {
				this.entityCount += 20;
			}

			if (distance <= 5) {

				//run setting block per level
				if (this.entityCount >= 7 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_0")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_1`);
					this.entityCount -= 7;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 9 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_1")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_2`);
					this.entityCount -= 9;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 11 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_2")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_3`);
					this.entityCount -= 11;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 13 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_3")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_4`);
					this.entityCount -= 13;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 15 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_4")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_5`);
					this.entityCount -= 15;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 17 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_5")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_6`);
					this.entityCount -= 17;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 19 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_6")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_7`);
					this.entityCount -= 19;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 21 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_7")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_8`);
					this.entityCount -= 21;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 23 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_8")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_9`);
					this.entityCount -= 23;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 25 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_9")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_10`);
					this.entityCount -= 25;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 27 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_10")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_11`);
					this.entityCount -= 27;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 29 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_11")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_12`);
					this.entityCount -= 29;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 31 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_12")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_13`);
					this.entityCount -= 31;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 33 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_13")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_14`);
					this.entityCount -= 33;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 35 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_14")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_15`);
					this.entityCount -= 35;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 37 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_15")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_16`);
					this.entityCount -= 37;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 42 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_16")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_17`);
					this.entityCount -= 42;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 47 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_17")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_18`);
					this.entityCount -= 47;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 52 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_18")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_19`);
					this.entityCount -= 52;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 57 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_19")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_20`);
					this.entityCount -= 57;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 62 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_20")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_21`);
					this.entityCount -= 62;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 67 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_21")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_22`);
					this.entityCount -= 67;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 72 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_22")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_23`);
					this.entityCount -= 72;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 77 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_23")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_24`);
					this.entityCount -= 77;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 82 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_24")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_25`);
					this.entityCount -= 82;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 87 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_25")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_26`);
					this.entityCount -= 87;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 92 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_26")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_27`);
					this.entityCount -= 92;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 97 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_27")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_28`);
					this.entityCount -= 97;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 102 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_28")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_29`);
					this.entityCount -= 102;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 107 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_29")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_iron_xp_storage_30`);
					this.entityCount -= 107;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_30")) {
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 7 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_0")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_1`);
					this.entityCount -= 7;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 9 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_1")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_2`);
					this.entityCount -= 9;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}else if (this.entityCount >= 11 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_2")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_3`);
					this.entityCount -= 11;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 13 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_3")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_4`);
					this.entityCount -= 13;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 15 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_4")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_5`);
					this.entityCount -= 15;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 17 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_5")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_6`);
					this.entityCount -= 17;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 19 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_6")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_7`);
					this.entityCount -= 19;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 21 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_7")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_8`);
					this.entityCount -= 21;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 23 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_8")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_9`);
					this.entityCount -= 23;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 25 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_9")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_10`);
					this.entityCount -= 25;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 27 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_10")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_11`);
					this.entityCount -= 27;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 29 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_11")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_12`);
					this.entityCount -= 29;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 31 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_12")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_13`);
					this.entityCount -= 31;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 33 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_13")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_14`);
					this.entityCount -= 33;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 35 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_14")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_15`);
					this.entityCount -= 35;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 37 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_15")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_16`);
					this.entityCount -= 37;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 42 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_16")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_17`);
					this.entityCount -= 42;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 47 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_17")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_18`);
					this.entityCount -= 47;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 52 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_18")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_19`);
					this.entityCount -= 52;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 57 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_19")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_20`);
					this.entityCount -= 57;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 62 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_20")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_21`);
					this.entityCount -= 62;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 67 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_21")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_22`);
					this.entityCount -= 67;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 72 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_22")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_23`);
					this.entityCount -= 72;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 77 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_23")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_24`);
					this.entityCount -= 77;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 82 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_24")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_25`);
					this.entityCount -= 82;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 87 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_25")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_26`);
					this.entityCount -= 87;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 92 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_26")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_27`);
					this.entityCount -= 92;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 97 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_27")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_28`);
					this.entityCount -= 97;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 102 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_28")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_29`);
					this.entityCount -= 102;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 107 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_29")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_30`);
					this.entityCount -= 107;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 112 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_30")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_31`);
					this.entityCount -= 112;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 121 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_31")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_32`);
					this.entityCount -= 121;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 130 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_32")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_33`);
					this.entityCount -= 130;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 139 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_33")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_34`);
					this.entityCount -= 139;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 148 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_34")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_35`);
					this.entityCount -= 148;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 157 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_35")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_36`);
					this.entityCount -= 157;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 166 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_36")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_37`);
					this.entityCount -= 166;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 175 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_37")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_38`);
					this.entityCount -= 175;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 184 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_38")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_39`);
					this.entityCount -= 184;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 193 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_39")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_40`);
					this.entityCount -= 193;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 202 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_40")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_41`);
					this.entityCount -= 202;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 211 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_41")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_42`);
					this.entityCount -= 211;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 220 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_42")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_43`);
					this.entityCount -= 220;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 229 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_43")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_44`);
					this.entityCount -= 229;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 238 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_44")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_45`);
					this.entityCount -= 238;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 247 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_45")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_46`);
					this.entityCount -= 247;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 256 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_46")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_47`);
					this.entityCount -= 256;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 265 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_47")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_48`);
					this.entityCount -= 265;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 274 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_48")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_49`);
					this.entityCount -= 274;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 283 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_49")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_50`);
					this.entityCount -= 283;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 292 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_50")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_51`);
					this.entityCount -= 292;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 301 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_51")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_52`);
					this.entityCount -= 301;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 310 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_52")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_53`);
					this.entityCount -= 310;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 319 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_53")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_54`);
					this.entityCount -= 319;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 328 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_54")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_55`);
					this.entityCount -= 328;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 337 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_55")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_56`);
					this.entityCount -= 337;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 346 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_56")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_57`);
					this.entityCount -= 346;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 355 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_57")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_58`);
					this.entityCount -= 355;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 364 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_58")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_59`);
					this.entityCount -= 364;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 373 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_59")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_gold_xp_storage_60`);
					this.entityCount -= 373;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_60")) {
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 7 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_0")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_1`);
					this.entityCount -= 7;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}  else if (this.entityCount >= 9 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_1")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_2`);
					this.entityCount -= 9;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 11 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_2")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_3`);
					this.entityCount -= 11;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 13 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_3")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_4`);
					this.entityCount -= 13;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 15 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_4")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_5`);
					this.entityCount -= 15;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 17 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_5")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_6`);
					this.entityCount -= 17;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 19 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_6")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_7`);
					this.entityCount -= 19;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 21 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_7")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_8`);
					this.entityCount -= 21;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 23 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_8")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_9`);
					this.entityCount -= 23;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 25 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_9")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_10`);
					this.entityCount -= 25;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 27 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_10")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_11`);
					this.entityCount -= 27;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 29 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_11")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_12`);
					this.entityCount -= 29;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 31 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_12")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_13`);
					this.entityCount -= 31;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 33 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_13")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_14`);
					this.entityCount -= 33;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 35 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_14")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_15`);
					this.entityCount -= 35;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 37 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_15")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_16`);
					this.entityCount -= 37;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 42 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_16")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_17`);
					this.entityCount -= 42;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 47 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_17")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_18`);
					this.entityCount -= 47;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 52 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_18")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_19`);
					this.entityCount -= 52;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 57 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_19")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_20`);
					this.entityCount -= 57;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 62 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_20")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_21`);
					this.entityCount -= 62;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 67 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_21")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_22`);
					this.entityCount -= 67;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 72 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_22")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_23`);
					this.entityCount -= 72;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 77 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_23")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_24`);
					this.entityCount -= 77;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 82 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_24")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_25`);
					this.entityCount -= 82;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 87 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_25")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_26`);
					this.entityCount -= 87;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 92 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_26")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_27`);
					this.entityCount -= 92;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 97 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_27")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_28`);
					this.entityCount -= 97;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 102 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_28")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_29`);
					this.entityCount -= 102;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 107 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_29")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_30`);
					this.entityCount -= 107;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 112 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_30")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_31`);
					this.entityCount -= 112;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 121 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_31")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_32`);
					this.entityCount -= 121;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 130 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_32")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_33`);
					this.entityCount -= 130;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 139 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_33")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_34`);
					this.entityCount -= 139;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 148 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_34")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_35`);
					this.entityCount -= 148;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 157 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_35")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_36`);
					this.entityCount -= 157;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 166 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_36")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_37`);
					this.entityCount -= 166;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 175 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_37")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_38`);
					this.entityCount -= 175;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 184 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_38")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_39`);
					this.entityCount -= 184;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 193 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_39")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_40`);
					this.entityCount -= 193;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 202 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_40")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_41`);
					this.entityCount -= 202;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 211 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_41")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_42`);
					this.entityCount -= 211;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 220 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_42")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_43`);
					this.entityCount -= 220;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 229 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_43")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_44`);
					this.entityCount -= 229;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 238 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_44")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_45`);
					this.entityCount -= 238;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 247 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_45")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_46`);
					this.entityCount -= 247;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 256 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_46")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_47`);
					this.entityCount -= 256;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 265 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_47")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_48`);
					this.entityCount -= 265;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 274 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_48")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_49`);
					this.entityCount -= 274;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 283 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_49")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_50`);
					this.entityCount -= 283;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 292 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_50")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_51`);
					this.entityCount -= 292;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 301 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_51")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_52`);
					this.entityCount -= 301;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 310 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_52")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_53`);
					this.entityCount -= 310;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 319 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_53")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_54`);
					this.entityCount -= 319;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 328 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_54")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_55`);
					this.entityCount -= 328;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 337 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_55")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_56`);
					this.entityCount -= 337;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 346 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_56")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_57`);
					this.entityCount -= 346;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 355 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_57")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_58`);
					this.entityCount -= 355;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 364 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_58")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_59`);
					this.entityCount -= 364;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 373 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_59")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_60`);
					this.entityCount -= 373;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 382 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_60")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_61`);
					this.entityCount -= 382;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 391 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_61")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_62`);
					this.entityCount -= 391;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 400 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_62")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_63`);
					this.entityCount -= 400;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 409 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_63")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_64`);
					this.entityCount -= 409;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 418 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_64")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_65`);
					this.entityCount -= 418;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 427 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_65")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_66`);
					this.entityCount -= 427;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 436 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_66")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_67`);
					this.entityCount -= 436;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 445 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_67")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_68`);
					this.entityCount -= 445;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 454 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_68")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_69`);
					this.entityCount -= 454;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 463 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_69")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_70`);
					this.entityCount -= 463;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 472 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_70")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_71`);
					this.entityCount -= 472;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 481 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_71")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_72`);
					this.entityCount -= 481;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 490 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_72")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_73`);
					this.entityCount -= 490;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 499 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_73")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_74`);
					this.entityCount -= 499;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 508 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_74")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_75`);
					this.entityCount -= 508;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 517 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_75")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_76`);
					this.entityCount -= 517;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 526 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_76")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_77`);
					this.entityCount -= 526;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 535 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_77")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_78`);
					this.entityCount -= 535;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 544 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_78")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_79`);
					this.entityCount -= 544;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 553 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_79")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_80`);
					this.entityCount -= 553;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 562 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_80")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_81`);
					this.entityCount -= 562;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				} else if (this.entityCount >= 571 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_81")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_82`);
					this.entityCount -= 571;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 580 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_82")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_83`);
					this.entityCount -= 580;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 589 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_83")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_84`);
					this.entityCount -= 589;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 598 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_84")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_85`);
					this.entityCount -= 598;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 607 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_85")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_86`);
					this.entityCount -= 607;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 616 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_86")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_87`);
					this.entityCount -= 616;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 625 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_87")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_88`);
					this.entityCount -= 625;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 634 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_88")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_89`);
					this.entityCount -= 634;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 643 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_89")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_90`);
					this.entityCount -= 643;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 652 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_90")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_91`);
					this.entityCount -= 652;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 661 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_91")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_92`);
					this.entityCount -= 661;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 670 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_92")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_93`);
					this.entityCount -= 670;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 679 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_93")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_94`);
					this.entityCount -= 679;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 688 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_94")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_95`);
					this.entityCount -= 688;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 697 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_95")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_96`);
					this.entityCount -= 697;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 706 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_96")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_97`);
					this.entityCount -= 706;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 715 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_97")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_98`);
					this.entityCount -= 715;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 724 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_98")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_99`);
					this.entityCount -= 724;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (this.entityCount >= 733 && blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_99")) {
					world.getDimension(xpMainDimension).runCommandAsync(`setblock ${xpMainStorageLocation.x} ${xpMainStorageLocation.y} ${xpMainStorageLocation.z} snailstudios_xp:snailstudios_netherite_xp_storage_100`);
					this.entityCount -= 733;
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
				
				
				else if (blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_100")) {
					if (toggleButton) {
						this.toggleButtonTrue();
					} else {
					}
				}
			}
		}
	}
}

    MobSpawner() {

		const xpMainStorageLocation = this.XpStoragePlacedHandler.getStoredLocationOfXp();
		const xpGrinderLocation = this.blockHandler.getStoredLocation();
		if (xpMainStorageLocation !== null && xpGrinderLocation !== null) {

		const xpMainDimension = this.blockHandler.getStoredDimension();
        const xpGrinderLocation = this.blockHandler.getStoredLocation();
        const xpMainStorageLocation = this.XpStoragePlacedHandler.getStoredLocationOfXp();

		const blockXpLocationSet = world.getDimension(xpMainDimension).getBlock(xpMainStorageLocation);
    
        // Define the entity types in an array
        const entityTypesIron = ['minecraft:cow', 'minecraft:sheep', 'minecraft:chicken', 'minecraft:pig', 'minecraft:skeleton', 'minecraft:zombie'];
        const entityTypesGold = ['minecraft:witch', 'minecraft:slime', 'minecraft:guardian', 'minecraft:zombie_pigman', 'minecraft:creeper', 'minecraft:iron_golem'];
		const entityTypesNetherite = ['minecraft:wither_skeleton', 'minecraft:blaze'];
		



        const selectedEntityTypeIron = entityTypesIron[this.returnindexEntites()];
        const selectedEntityTypeGold = entityTypesGold[this.returnindexEntites()];
		const selectedEntityTypeNetherite = entityTypesNetherite[this.returnindexEntites()];

		const netheriteSelectionNumber = this.returnindexEntites();
    
        // Check if the spawner toggle button is off
        if (!toggleButton) {
            this.stopMobSpawner();
            this.systemRunner = null;
            return;
        }
    
        
            const numberOfEntities = 4; // Spawn 4 cows
            const maxCowsNearby = 1; // Maximum number of cows allowed near the grinder
    
            const spawnEntities = (count) => {
                if (count <= 0) {
                    return;
                }
    
                // Calculate random spawn positions around the provided coordinates
                const spawnPositions = [];
                for (let i = 0; i < numberOfEntities; i++) {
                    const spawnX = xpGrinderLocation.x + Math.floor(Math.random() * 5) - 2; // Random x within +/- 2 of the grinder's x
                    const spawnZ = xpGrinderLocation.z + Math.floor(Math.random() * 5) - 2; // Random z within +/- 2 of the grinder's z
                    const spawnY = xpGrinderLocation.y + 1; // Fixed y position
                    spawnPositions.push({ x: spawnX, y: spawnY, z: spawnZ });
                }
            
                // Check if there are any entities with tags within the specified area
                const entitiesWithTags = this.getEntitiesWithTags(xpGrinderLocation, 3);
                
                // Spawn entities only if there are no entities with tags nearby
                if (entitiesWithTags.length === 0 &&
                    (blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_0") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_1") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_2") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_3") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_4") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_5") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_6") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_7") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_8") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_9") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_10") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_11") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_12") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_13") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_14") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_15") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_16") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_17") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_18") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_19") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_20") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_21") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_22") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_23") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_24") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_25") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_26") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_27") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_28") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_29") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_iron_xp_storage_30"))) {

                    // Spawn entities at the calculated positions
                    for (const spawnPosition of spawnPositions) {
                        // Spawn the entity
                        const spawnedEntity = world.getDimension(xpMainDimension).spawnEntity(selectedEntityTypeIron, spawnPosition);
            
                        // Check if the entity was successfully spawned
                        if (spawnedEntity !== null) {
                            // Add the unique tag to the spawned entity
                            this.addCustomTagToEntity(spawnedEntity, "snailstudios_xp_mobs");
                        } else {
                            // Handle if the entity couldn't be spawned
                        }
                    }
                } else if (entitiesWithTags.length === 0 &&
                    (blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_0") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_1") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_2") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_3") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_4") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_5") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_6") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_7") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_8") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_9") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_10") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_11") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_12") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_13") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_14") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_15") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_16") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_17") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_18") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_19") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_20") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_21") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_22") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_23") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_24") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_25") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_26") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_27") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_28") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_29") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_30") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_31") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_32") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_33") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_34") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_35") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_36") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_37") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_38") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_39") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_40") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_41") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_42") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_43") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_44") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_45") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_46") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_47") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_48") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_49") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_50") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_51") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_52") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_53") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_54") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_55") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_56") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_57") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_58") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_59") ||
                    blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_gold_xp_storage_60"))) {
                    // Spawn entities at the calculated positions
                    for (const spawnPosition of spawnPositions) {
                        // Spawn the entity
                        const spawnedEntity = world.getDimension(xpMainDimension).spawnEntity(selectedEntityTypeGold, spawnPosition);
            
                        // Check if the entity was successfully spawned
                        if (spawnedEntity !== null) {
                            // Add the unique tag to the spawned entity
                            this.addCustomTagToEntity(spawnedEntity, "snailstudios_xp_mobs");
                        } else {
                            // Handle if the entity couldn't be spawned
                        }
                    }
                }  else if (entitiesWithTags.length === 0 &&
                    (blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_0") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_1") || 
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_2") || 
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_3") || 
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_4") || 
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_5") || 
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_6") || 
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_7") || 
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_8") || 
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_9") || 
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_10") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_11") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_12") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_13") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_14") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_15") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_16") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_17") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_18") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_19") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_20") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_21") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_22") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_23") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_24") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_25") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_26") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_27") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_28") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_29") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_30") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_31") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_32") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_33") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_34") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_35") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_36") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_37") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_38") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_39") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_40") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_41") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_42") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_43") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_44") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_45") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_46") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_47") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_48") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_49") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_50") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_51") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_52") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_53") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_54") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_55") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_56") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_57") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_58") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_59") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_60") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_61") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_62") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_63") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_64") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_65") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_66") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_67") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_68") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_69") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_70") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_71") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_72") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_73") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_74") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_75") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_76") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_77") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_78") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_79") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_80") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_81") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_82") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_83") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_84") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_85") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_86") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_87") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_88") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_89") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_90") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_91") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_92") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_93") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_94") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_95") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_96") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_97") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_98") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_99") ||
					blockXpLocationSet.permutation.matches("snailstudios_xp:snailstudios_netherite_xp_storage_100"))) {
					if ( netheriteSelectionNumber <= 1) {
                    // Spawn entities at the calculated positions
                    for (const spawnPosition of spawnPositions) {
                        // Spawn the entity
                        const spawnedEntity = world.getDimension(xpMainDimension).spawnEntity(selectedEntityTypeNetherite, spawnPosition);
            
                        // Check if the entity was successfully spawned
                        if (spawnedEntity !== null) {
                            // Add the unique tag to the spawned entity
                            this.addCustomTagToEntity(spawnedEntity, "snailstudios_xp_mobs");
                        } else {
                            // Handle if the entity couldn't be spawned
                        }
                    }
                } else {
					const generateRandomNumber = () => Math.floor(Math.random() * 101);
					let random = generateRandomNumber();
					for (const spawnPosition of spawnPositions) {

						if (random >= 25 && random <= 100) {
							random = generateRandomNumber();
							const spawnedEntity = world.getDimension(xpMainDimension).spawnEntity("minecraft:pillager", spawnPosition);

							 // Check if the entity was successfully spawned
                        	if (spawnedEntity !== null) {
                            	// Add the unique tag to the spawned entity
								spawnedEntity.triggerEvent('minecraft:spawn_for_raid');
                            	this.addCustomTagToEntity(spawnedEntity, "snailstudios_xp_mobs");
                        } 	else {
                            	// Handle if the entity couldn't be spawned
                        } 
					} else if (random >= 15 && random <= 24) {
							random = generateRandomNumber();
							const spawnedEntity = world.getDimension(xpMainDimension).spawnEntity("minecraft:vindicator", spawnPosition);

							 // Check if the entity was successfully spawned
                        	if (spawnedEntity !== null) {
                            	// Add the unique tag to the spawned entity
								spawnedEntity.triggerEvent('minecraft:spawn_for_raid');
                            	this.addCustomTagToEntity(spawnedEntity, "snailstudios_xp_mobs");
                        } 	else {
                            	// Handle if the entity couldn't be spawned
                        }
					} else if (random >= 5 && random <= 14) {
							random = generateRandomNumber();
							const spawnedEntity = world.getDimension(xpMainDimension).spawnEntity("minecraft:evocation_illager", spawnPosition);

							 // Check if the entity was successfully spawned
                        	if (spawnedEntity !== null) {
                            	// Add the unique tag to the spawned entity
                            	this.addCustomTagToEntity(spawnedEntity, "snailstudios_xp_mobs");
                        } 	else {
                            	// Handle if the entity couldn't be spawned
                        }
					}  else if (random >= 0 && random <= 4) {
						random = generateRandomNumber();
						const spawnedEntity = world.getDimension(xpMainDimension).spawnEntity("minecraft:ravager", spawnPosition);

						 // Check if the entity was successfully spawned
						if (spawnedEntity !== null) {
							// Add the unique tag to the spawned entity
							this.addCustomTagToEntity(spawnedEntity, "snailstudios_xp_mobs");
					} 	else {
							// Handle if the entity couldn't be spawned
					}
				}
                }
			}
		}
                
                else {
                }
                
                // Call the function recursively only if necessary
                if (entitiesWithTags.length === 0) {
					const xpMainDimension = this.blockHandler.getStoredDimension();
					const xpGrinderLocation = this.blockHandler.getStoredLocation();
                }
            };
    
            spawnEntities(); // Call the function initially with count = 1
        } else {
            this.toggleButtonFalse();
            this.stopMobSpawner();
            this.systemRunner = null;
        }
    }
    
    // Custom method to get entities with tags within a certain radius from a location
    getEntitiesWithTags(location, maxDistance) {
		const xpMainDimension = this.blockHandler.getStoredDimension();
        const nearbyEntities = world.getDimension(xpMainDimension).getEntities({
            location: location,
            maxDistance: maxDistance
        });
        return nearbyEntities.filter(entity => entity.getTags().length > 0);
    }
    
    // Custom method to add a custom tag to an entity
    addCustomTagToEntity(entity, tag) {
        entity.addTag(tag);
    }

    runMobSpawner() {
		this.stopMobSpawner();
        // Start the interval and store the interval ID in systemRunner
        this.systemRunner = system.runInterval(() => this.MobSpawner(), 170);
    }

    stopMobSpawner() {
        // Clear the interval to stop the timer
		if (this.systemRunner !== null) {
            system.clearRun(this.systemRunner); // Clear the system runner
            this.systemRunner = null;
		}
    }

}
export default EntityChecker;

//finish
