effect @s resistance 1 200 true
enchant @s sharpness 5
enchant @s fire_aspect 2
enchant @s knockback 2
enchant @s unbreaking 3
enchant @s looting 3
enchant @s fortune 3
enchant @s efficiency 5
enchant @s unbreaking 3
enchant @s mending
enchant @s protection 4
enchant @s thorns 3
enchant @s power 4
enchant @s flame 1
enchant @s punch 2
enchant @s unbreaking 3
enchant @s channeling 1
enchant @s impaling 4
enchant @s unbreaking 3
enchant @s loyalty 3
enchant @s depth_strider 3
enchant @s soul_speed 3
enchant @s feather_falling
execute @e[name="iron ore",r=4] ~ ~ ~ give @p iron_ingot 2
execute @e[name="iron ore",r=4] ~ ~ ~ kill @e[name="iron ore"]
execute @e[name="iron ore",r=4] ~ ~ ~ xp 100 @p
execute @e[name="diamond ore",r=4] ~ ~ ~ give @p diamond 2
execute @e[name="diamond ore",r=4] ~ ~ ~ xp 100 @p
execute @e[name="diamond ore",r=4] ~ ~ ~ kill @e[name="diamond ore"]
execute @e[name="gold ore",r=4] ~ ~ ~ give @p gold_ingot 2
execute @e[name="gold ore",r=4] ~ ~ ~ kill @e[name="gold ore"]
execute @e[name="gold ore",r=4] ~ ~ ~ xp 100 @p
execute @e[name="ancient debris",r=4] ~ ~ ~ give @p netherite_ingot
execute @e[name="ancient debris",r=4] ~ ~ ~ kill @e[name="ancient debris"]
execute @e[name="ancient debris",r=4] ~ ~ ~ xp 100 @p