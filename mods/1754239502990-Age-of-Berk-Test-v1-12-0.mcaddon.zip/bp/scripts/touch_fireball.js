import { system } from '@minecraft/server'

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.message == 'hitAir') {
        const player = event.sourceEntity
        if (!player.hasTag('touch')) {
            player.runCommandAsync('function dragon_shoot_test')
        }
    }
})