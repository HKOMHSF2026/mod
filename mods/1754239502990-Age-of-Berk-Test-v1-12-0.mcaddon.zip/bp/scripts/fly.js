import { system, world } from "@minecraft/server";
import Utils from "./fly_util";

system.runInterval(() => {
    const dim = world.getDimension('overworld');
    for (const entity of dim.getEntities({ type: "httyd:nadder", excludeTags: ["chicken"] })) {
        const utils = new Utils(entity);
        utils.flySystem(0.09, 0.07, 0.03, 12);
    }
    for (const entity of dim.getEntities({ type: "httyd:nadder", tags: ["chicken"] })) {
        const utils = new Utils(entity);
        utils.flySystem(0.09, 0.07, 0.03, 12);
    }
    for (const entity of dim.getEntities({ type: "httyd:gronckle" })) {
        const utils = new Utils(entity);
        utils.flySystem(0.09, 0.07, 0.03, 8);
    }
    for (const entity of dim.getEntities({ type: "httyd:zippleback" })) {
        const utils = new Utils(entity);
        utils.flySystem(0.09, 0.07, 0.03, 16);
    }
    for (const entity of dim.getEntities({ type: "httyd:nightmare" })) {
        const utils = new Utils(entity);
        utils.flySystem(0.09, 0.07, 0.03, 20);
    }
    for (const entity of dim.getEntities({ type: "httyd:night_fury" })) {
        const utils = new Utils(entity);
        utils.flySystem(0.09, 0.07, 0.03, 24);
    }
    for (const entity of dim.getEntities({ type: "httyd:light_fury" })) {
        const utils = new Utils(entity);
        utils.flySystem(0.09, 0.07, 0.03, 24);
    }
    for (const entity of dim.getEntities({ type: "httyd:whispering_death" })) {
        const utils = new Utils(entity);
        utils.flySystem(0.09, 0.07, 0.03, 14);
    }
    for (const entity of dim.getEntities({ type: "httyd:sand_wraith" })) {
        const utils = new Utils(entity);
        utils.flySystem(0.09, 0.07, 0.03, 14);
    }
    for (const entity of dim.getEntities({ type: "httyd:thunderdrum" })) {
        const utils = new Utils(entity);
        utils.flySystem(0.09, 0.07, 0.03, 14);
    }
    for (const entity of dim.getEntities({ type: "httyd:timberjack" })) {
        const utils = new Utils(entity);
        utils.flySystem(0.09, 0.07, 0.03, 16);
    }
    for (const entity of dim.getEntities({ type: "httyd:flamewhipper" })) {
        const utils = new Utils(entity);
        utils.flySystem(0.09, 0.07, 0.03, 10);
    }
    for (const entity of dim.getEntities({ type: "httyd:skrill" })) {
        const utils = new Utils(entity);
        utils.flySystem(0.09, 0.07, 0.03, 22);
    }
    for (const entity of dim.getEntities({ type: "httyd:snow_wraith" })) {
        const utils = new Utils(entity);
        utils.flySystem(0.09, 0.07, 0.03, 20);
    }
    for (const entity of dim.getEntities({ type: "httyd:rumblehorn" })) {
        const utils = new Utils(entity);
        utils.flySystem(0.09, 0.07, 0.03, 16);
    }
    for (const entity of dim.getEntities({ type: "httyd:hobblegrunt" })) {
        const utils = new Utils(entity);
        utils.flySystem(0.09, 0.07, 0.03, 12);
    }
});