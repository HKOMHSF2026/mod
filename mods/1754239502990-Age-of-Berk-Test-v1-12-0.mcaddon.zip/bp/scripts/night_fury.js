import { world, system } from '@minecraft/server';

function getRandom(min, max) {
    return Math.random() * (max - min) + min;
}

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.id == 'httyd:night_fury_spawn') {
        const randomChance = Math.floor(getRandom(0, 10000))
        if (world.getTimeOfDay() <= 12000) return;
        if (randomChance != 1) return
        world.scoreboard.getObjective('night_fury').addScore('world', 1)
        event.sourceEntity.runCommandAsync('execute as @e[type=httyd:night_fury,has_property={httyd:trained=false},c=1] run scoreboard objectives add night_fury_spawned dummy')
        event.sourceEntity.runCommandAsync('execute as @e[type=httyd:night_fury,has_property={httyd:trained=false},c=1] run scoreboard players set world night_fury_spawned 0')
        const playerLocation = event.sourceEntity.location
        const randomXFromPlayerLocation = getRandom(-48, 48) + playerLocation.x
        const randomZFromPlayerLocation = getRandom(-48, 48) + playerLocation.z
        event.sourceEntity.dimension.spawnEntity('httyd:night_fury', { x: randomXFromPlayerLocation, y: 320, z: randomZFromPlayerLocation }).triggerEvent('httyd:start_wandering_air')
    }
})

world.afterEvents.entityDie.subscribe(event => {
    if (event.deadEntity.typeId == 'httyd:night_fury' && event.deadEntity.getProperty('httyd:trained') == false) {
        event.deadEntity.runCommandAsync('function night_fury_spawn')
        event.deadEntity.runCommandAsync('scoreboard objectives remove night_fury_spawned')
    }
})