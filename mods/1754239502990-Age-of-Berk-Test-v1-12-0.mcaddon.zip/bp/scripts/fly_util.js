import { Entity, world } from "@minecraft/server";
class Utils {
    /**
     * @param {Entity} entity
     */
    constructor(entity) {
        this.entity = entity;
        this.rideable = entity?.getComponent("rideable");
        this.player = this.rideable?.getRiders()[0];
        this.riding = this.player?.hasTag('riding_dragon')
        this.rotation = this.player?.getRotation().x
        this.diving = this.rotation >= 65
        this.sitting = this.entity.getProperty('httyd:sitting')
    };


    /**
* @param {number} flySpeed
* @param {number} fallSpeed
* @param {number} XZspeed
* @param {number} diveSpeed
*/
    flySystem(flySpeed, fallSpeed, diveSpeed, XZspeed) {
        if (!this.riding) return;
        if (this.sitting) return;
        const direction = {
            x: 0,
            y: this.player.isJumping ? flySpeed : this.diving ? -diveSpeed / 5 : fallSpeed,
            z: 0,
        };
        this.entity.addEffect("speed", 5, {
            showParticles: false,
            amplifier: XZspeed,
        });
        this.entity.applyImpulse(direction);
        if (this.entity.isOnGround || this.entity.isInWater && this.entity.typeId != 'httyd:thunderdrum') {
            this.entity.removeEffect('speed')
        }
        if (!this.player.isJumping && this.diving) {
            this.entity.setProperty('httyd:diving', true)
        } else {
            this.entity.setProperty('httyd:diving', false)
        }
    }
}

export default Utils;