import { ModalFormData } from "@minecraft/server-ui";
import { world, system } from "@minecraft/server";

function formui(player) {
    let form = new ModalFormData();

    var defaultCamera = 0
    if (player.hasTag('third_person')) { var defaultCamera = 0 }
    if (player.hasTag('first_person')) { var defaultCamera = 1 }

    form.title({ translate: 'item.httyd:settings' })
    form.dropdown({ translate: 'options.thirdperson' }, [{ translate: 'options.thirdperson.thirdpersonback' }, { translate: 'options.thirdperson.firstperson' }], defaultCamera);
    form.show(player).then(r => {

        if (r.canceled) {
            if (player.hasTag('first_person')) return;
            if (player.hasTag('third_person')) return;
            player.runCommandAsync('scriptevent httyd:dragon settings')
            return
        }

        let [camera] = r.formValues;


        if (camera == 0) {
            player.removeTag('first_person')
            player.addTag('third_person')
        };
        if (camera == 1) {
            player.removeTag('third_person')
            player.addTag('first_person')
            player.triggerEvent('httyd:stop_riding_dragon')
        };


    }).catch(e => {
        console.error(e, e.stack);
    });
}

world.afterEvents.playerSpawn.subscribe(event => {
    const player = event.player;
    const { platformType, memoryTier, maxRenderDistance: maxRender } = player.clientSystemInfo;
    if (player.hasComponent('riding')) {
        const isRiding = player.getComponent('minecraft:riding')?.entityRidingOn.target
        if (isRiding) {
            if (player.hasTag('third_person')) {
                player.triggerEvent("httyd:start_riding_dragon")
                player.addTag('riding_dragon')
            }
        }
        if (!isRiding) {
            if (player.hasTag('third_person')) {
                player.triggerEvent("httyd:stop_riding_dragon")
                player.removeTag('riding_dragon')
            }
        }
    }

    if (platformType === 'Desktop' && !player.hasTag('keyboard')) {
        player.addTag('keyboard')
        player.removeTag('controller')
        player.removeTag('touch')
    }
    if (platformType === 'Console' && !player.hasTag('controller')) {
        if (player.hasTag('touch')) return
        player.removeTag('keyboard')
        player.addTag('controller')
        player.removeTag('touch')
    }
    if (platformType === 'Mobile' && !player.hasTag('touch')) {
        if (player.hasTag('touch')) return
        player.removeTag('keyboard')
        player.removeTag('controller')
        player.addTag('touch')
        player.runCommand('give @s httyd:dragon_shoot_command')
    }

    if (player.hasTag('first_person')) return;
    if (player.hasTag('third_person')) return;

    player.sendMessage({ translate: 'custom.string.settings' })
    player.runCommandAsync('give @s httyd:settings')
    player.runCommandAsync('scriptevent httyd:dragon settings')
})

system.afterEvents.scriptEventReceive.subscribe(event => {
    const player = event.sourceEntity;
    if (event.message == 'settings') {
        formui(player)
    }
})