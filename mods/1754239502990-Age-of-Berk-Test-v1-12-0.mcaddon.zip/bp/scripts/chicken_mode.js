import { world, system } from '@minecraft/server'

world.beforeEvents.itemUse.subscribe(event => {
    const player = event.source;
    for (const facingEntity of player.getEntitiesFromViewDirection({ maxDistance: 10, })) {
        if (event.itemStack.typeId == 'minecraft:cooked_chicken') {
            if (facingEntity.entity.typeId != 'httyd:nadder') return
            if (facingEntity.entity.hasTag('chicken')) return
            event.cancel = true
            facingEntity.entity.runCommandAsync('scriptevent httyd:dragon chicken_mode')
        }
    }
})

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.message == 'chicken_mode') {
        const nadder = event.sourceEntity
        nadder.triggerEvent('httyd:chicken')

    }
})