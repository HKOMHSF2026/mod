import { BlockPermutation, world, system } from '@minecraft/server';

var directions = [0, 90, 180, -90]
const randomDirection = directions[Math.floor(Math.random() * directions.length)];

world.beforeEvents.worldInitialize.subscribe(eventData => {

	//Spawners
	eventData.blockComponentRegistry.registerCustomComponent('httyd:dragon_hunter_spawn', {
		onTick(e) {
			const { block } = e;
			const { x, y, z } = block.location;

			block.dimension.setBlockType({ x: x, y: y, z: z }, 'air')
			block.dimension.spawnEntity('httyd:dragon_hunter', { x: x, y: y, z: z })
		}
	})
	eventData.blockComponentRegistry.registerCustomComponent('httyd:dragon_cage_ship_spawn', {
		onTick(e) {
			const { block } = e;
			const { x, y, z } = block.location;

			block.dimension.setBlockType({ x: x, y: y, z: z }, 'air')
			block.dimension.spawnEntity('httyd:dragon_cage', { x: x, y: y, z: z }).triggerEvent('httyd:ship')
		}
	})
	eventData.blockComponentRegistry.registerCustomComponent('httyd:dragon_cage_tower_spawn', {
		onTick(e) {
			const { block } = e;
			const { x, y, z } = block.location;

			block.dimension.setBlockType({ x: x, y: y, z: z }, 'air')
			block.dimension.spawnEntity('httyd:dragon_cage', { x: x, y: y, z: z }).triggerEvent('httyd:default')
		}
	})
	eventData.blockComponentRegistry.registerCustomComponent('httyd:wild_dragon_spawn', {
		onTick(e) {
			const { block } = e;
			const { x, y, z } = block.location;

			function getRandom(min, max) {
				return Math.random() * (max - min) + min;
			}
			const randomChance = Math.floor(getRandom(0, 27))
			if (randomChance >= 0 && randomChance <= 9) {
				block.dimension.spawnEntity('httyd:nadder', { x: x, y: y, z: z }).triggerEvent('httyd:become_persistent')
			}
			if (randomChance >= 10 && randomChance <= 17) {
				block.dimension.spawnEntity('httyd:gronckle', { x: x, y: y, z: z }).triggerEvent('httyd:become_persistent')
			}
			if (randomChance >= 18 && randomChance <= 22) {
				block.dimension.spawnEntity('httyd:hobblegrunt', { x: x, y: y, z: z }).triggerEvent('httyd:become_persistent')
			}
			if (randomChance >= 23 && randomChance <= 24) {
				block.dimension.spawnEntity('httyd:flamewhipper', { x: x, y: y, z: z }).triggerEvent('httyd:become_persistent')
			}
			if (randomChance >= 25 && randomChance <= 26) {
				block.dimension.spawnEntity('httyd:snow_wraith', { x: x, y: y, z: z }).triggerEvent('httyd:become_persistent')
			}
			if (randomChance == 27) {
				block.dimension.spawnEntity('httyd:light_fury', { x: x, y: y, z: z }).triggerEvent('httyd:become_persistent')
			}
			block.dimension.setBlockType({ x: x, y: y, z: z }, 'air')
		},
	})


	//Eggs
	eventData.blockComponentRegistry.registerCustomComponent('httyd:gronckle_egg', {
		onTick(e) {
			const { block } = e;
			const { x, y, z } = block.location;

			block.dimension.runCommand(`summon httyd:gronckle ${x} ${y} ${z} ${randomDirection} 0 httyd:hatched`);
			block.dimension.runCommand(`summon httyd:egg_explosion ${x} ${y} ${z}`);
			block.dimension.runCommand(`setblock ${x} ${y} ${z} air`);
		}
	})
	eventData.blockComponentRegistry.registerCustomComponent('httyd:nadder_egg', {
		onTick(e) {
			const { block } = e;
			const { x, y, z } = block.location;

			block.dimension.runCommand(`summon httyd:nadder ${x} ${y} ${z} ${randomDirection} 0 httyd:hatched`);
			block.dimension.runCommand(`setblock ${x} ${y} ${z} air`);
		}
	})
	eventData.blockComponentRegistry.registerCustomComponent('httyd:nightmare_egg', {
		onTick(e) {
			const { block } = e;
			const { x, y, z } = block.location;

			block.dimension.runCommand(`summon httyd:nightmare ${x} ${y} ${z} ${randomDirection} 0 httyd:hatched`);
			block.dimension.runCommand(`setblock ${x} ${y} ${z} air`);
		}
	})
	eventData.blockComponentRegistry.registerCustomComponent('httyd:zippleback_egg', {
		onTick(e) {
			const { block } = e;
			const { x, y, z } = block.location;

			block.dimension.runCommand(`summon httyd:zippleback ${x} ${y} ${z} ${randomDirection} 0 httyd:hatched`);
			block.dimension.runCommand(`setblock ${x} ${y} ${z} air`);
		}
	})
	eventData.blockComponentRegistry.registerCustomComponent('httyd:whispering_death_egg', {
		onTick(e) {
			const { block } = e;
			const { x, y, z } = block.location;

			block.dimension.runCommand(`summon httyd:whispering_death ${x} ${y} ${z} ${randomDirection} 0 httyd:hatched`);
			block.dimension.runCommand(`setblock ${x} ${y} ${z} air`);
		}
	})
	eventData.blockComponentRegistry.registerCustomComponent('httyd:sand_wraith_egg', {
		onTick(e) {
			const { block } = e;
			const { x, y, z } = block.location;

			block.dimension.runCommand(`summon httyd:sand_wraith ${x} ${y} ${z} ${randomDirection} 0 httyd:hatched`);
			block.dimension.runCommand(`setblock ${x} ${y} ${z} air`);
		}
	})
	eventData.blockComponentRegistry.registerCustomComponent('httyd:thunderdrum_egg', {
		onTick(e) {
			const { block } = e;
			const { x, y, z } = block.location;

			block.dimension.runCommand(`summon httyd:thunderdrum ${x} ${y} ${z} ${randomDirection} 0 httyd:hatched`);
			block.dimension.createExplosion(block.location, 4, { breaksBlocks: false })
			block.dimension.runCommand(`setblock ${x} ${y} ${z} air`);
		}
	})
	eventData.blockComponentRegistry.registerCustomComponent('httyd:timberjack_egg', {
		onTick(e) {
			const { block } = e;
			const { x, y, z } = block.location;

			block.dimension.runCommand(`summon httyd:timberjack ${x} ${y} ${z} ${randomDirection} 0 httyd:hatched`);
			block.dimension.runCommand(`setblock ${x} ${y} ${z} air`);
		}
	})
	eventData.blockComponentRegistry.registerCustomComponent('httyd:night_fury_egg', {
		onTick(e) {
			const { block } = e;
			const { x, y, z } = block.location;

			block.dimension.runCommand(`summon httyd:night_fury ${x} ${y} ${z} ${randomDirection} 0 httyd:hatched`);
			block.dimension.runCommand(`setblock ${x} ${y} ${z} air`);
		}
	})
	eventData.blockComponentRegistry.registerCustomComponent('httyd:light_fury_egg', {
		onTick(e) {
			const { block } = e;
			const { x, y, z } = block.location;

			block.dimension.runCommand(`summon httyd:light_fury ${x} ${y} ${z} ${randomDirection} 0 httyd:hatched`);
			block.dimension.runCommand(`setblock ${x} ${y} ${z} air`);
		}
	})
	eventData.blockComponentRegistry.registerCustomComponent('httyd:night_light_egg', {
		onTick(e) {
			const { block } = e;
			const { x, y, z } = block.location;

			block.dimension.runCommand(`summon httyd:night_light ${x} ${y} ${z} ${randomDirection} 0 httyd:hatched`);
			block.dimension.runCommand(`setblock ${x} ${y} ${z} air`);
		}
	})
	eventData.blockComponentRegistry.registerCustomComponent('httyd:flamewhipper_egg', {
		onTick(e) {
			const { block } = e;
			const { x, y, z } = block.location;

			block.dimension.runCommand(`summon httyd:flamewhipper ${x} ${y} ${z} ${randomDirection} 0 httyd:hatched`);
			block.dimension.runCommand(`setblock ${x} ${y} ${z} air`);
		}
	})
	eventData.blockComponentRegistry.registerCustomComponent('httyd:skrill_egg', {
		onTick(e) {
			const { block } = e;
			const { x, y, z } = block.location;

			block.dimension.runCommand(`summon httyd:skrill ${x} ${y} ${z} ${randomDirection} 0 httyd:hatched`);
			block.dimension.runCommand(`setblock ${x} ${y} ${z} air`);
		}
	})
	eventData.blockComponentRegistry.registerCustomComponent('httyd:snow_wraith_egg', {
		onTick(e) {
			const { block } = e;
			const { x, y, z } = block.location;

			block.dimension.runCommand(`summon httyd:snow_wraith ${x} ${y} ${z} ${randomDirection} 0 httyd:hatched`);
			block.dimension.runCommand(`setblock ${x} ${y} ${z} air`);
		}
	})
	eventData.blockComponentRegistry.registerCustomComponent('httyd:hobblegrunt_egg', {
		onTick(e) {
			const { block } = e;
			const { x, y, z } = block.location;

			block.dimension.runCommand(`summon httyd:hobblegrunt ${x} ${y} ${z} ${randomDirection} 0 httyd:hatched`);
			block.dimension.runCommand(`setblock ${x} ${y} ${z} air`);
		}
	})
	eventData.blockComponentRegistry.registerCustomComponent('httyd:rumblehorn_egg', {
		onTick(e) {
			const { block } = e;
			const { x, y, z } = block.location;

			block.dimension.runCommand(`summon httyd:rumblehorn ${x} ${y} ${z} ${randomDirection} 0 httyd:hatched`);
			block.dimension.runCommand(`setblock ${x} ${y} ${z} air`);
		}
	})

});