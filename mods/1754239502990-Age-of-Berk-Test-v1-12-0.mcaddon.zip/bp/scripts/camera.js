import { world, system, EntityComponentTypes } from '@minecraft/server'



system.runInterval(function () {
    const dimensions = ["overworld", "nether", "the_end"];
    dimensions.forEach(dimension => {
        world.getDimension(dimension).getEntities().forEach(entity => {
            if (entity.typeId === "minecraft:player") {
                const ridingComp = entity.getComponent(EntityComponentTypes.Riding);
                if (!ridingComp) {
                    entity.removeTag('riding_dragon')
                    entity.triggerEvent('httyd:stop_riding_dragon')
                };
                if (ridingComp) {
                    entity.addTag('riding_dragon')
                    if (entity.hasTag('third_person')) {
                        entity.triggerEvent('httyd:start_riding_dragon')
                    }
                };
            };
        });
    });
}, 5);