import { world, system } from '@minecraft/server';

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.message == 'sit') {
        const dragon = event.sourceEntity;

        if (dragon.hasTag('sitting')) {
            dragon.removeTag('sitting');
            dragon.setProperty('httyd:sitting', false);
            dragon.removeEffect('slowness');
            for (const player of dragon.dimension.getPlayers({ closest: true })) {
                player.sendMessage({ translate: 'custom.string.stand' });
            }
            return;
        }
        if (!dragon.hasTag('sitting')) {
            dragon.addTag('sitting');
            dragon.setProperty('httyd:sitting', true);
            dragon.addEffect('slowness', 20000000, { amplifier: 255, showParticles: false });
            for (const player of dragon.dimension.getPlayers({ closest: true })) {
                player.sendMessage({ translate: 'custom.string.sit' });
            }
        }
    }
});