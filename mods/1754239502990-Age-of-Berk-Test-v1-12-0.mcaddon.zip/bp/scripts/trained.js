import { world, system, EntityTypeFamilyComponent } from '@minecraft/server';
import { ModalFormData } from '@minecraft/server-ui';

world.afterEvents.playerSpawn.subscribe(event => {
    if (!event.player.getDynamicProperty('dragonsTrained') > 0) {
        event.player.setDynamicProperty('dragonsTrained', 0)
    }
})

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.message == 'achievementReset') {
        event.sourceEntity.setDynamicProperty('dragonsTrained', 0)
    }
    if (event.message == 'trained') {
        const dragon = event.sourceEntity
        const dragonLocation = dragon.location
        dragon.triggerEvent('httyd:become_persistent')
        if (dragon.typeId == 'httyd:night_fury') {
            event.sourceEntity.runCommandAsync('scoreboard objectives remove night_fury_spawned')
        }
        for (const player of dragon.dimension.getPlayers({ closest: true, location: dragonLocation })) {
            dragon.setProperty('httyd:trained', true)
            dragon.removeTag('untrained')
            dragon.addTag(`${player.name}_owned`)
            player.setDynamicProperty('dragonsTrained', 0)
            player.runCommandAsync('scriptevent achievements:complete_achievement achievements:train_dragon')
            player.runCommandAsync('give @s[tag=touch] httyd:dragon_shoot_command 1 0 {"minecraft:keep_on_death":{}}')
            let dragonsTrained = player.getDynamicProperty('dragonsTrained');
            let newDragonsTrained = dragonsTrained + 1;
            player.setDynamicProperty('dragonsTrained', newDragonsTrained)
            if (dragonsTrained >= 10) {
                player.runCommandAsync('scriptevent achievements:complete_achievement achievements:train_dragon_10')
            }
            const modalForm = new ModalFormData().title({ translate: 'custom.string.dragon_name1' })
            modalForm.textField({ translate: 'custom.string.dragon_name2' }, { translate: 'custom.string.dragon_name1' })
            modalForm.show(player).then(formData => {
                if (formData.canceled) {
                    dragon.runCommandAsync('scriptevent httyd:dragon trained')
                    return
                }
                const name = formData.formValues
                dragon.nameTag = `${name}`
                player.sendMessage({ translate: 'custom.string.dragon_name3', with: name })
                player.sendMessage({ translate: 'custom.string.dragon_name4' })
            }).catch(e => {
                console.error(e, e.stack);
            });
        }
    }
})

world.afterEvents.entitySpawn.subscribe(event => {
    const dragon = event.entity;
    if (!dragon.hasComponent('minecraft:type_family')) return
    if (!dragon.getProperty('httyd:trained') && dragon.getComponent('minecraft:type_family').hasTypeFamily('httyd:dragon')) {
        dragon.addTag('untrained');
    }
});