import { world, system } from '@minecraft/server'

system.afterEvents.scriptEventReceive.subscribe(event => {
    const dragon = event.sourceEntity
    const { x, y, z } = dragon.getHeadLocation();
    const { x: dx, y: dy, z: dz } = dragon.getViewDirection();
    if (event.id == 'httyd:fireball') {
        //Gronckle
        if (event.message == 'gronckle') {
            const existingVelocity = dragon.getVelocity()
            const dragonDirection = dragon.getViewDirection()
            dragon.dimension.spawnEntity('httyd:lava_blast', { x: x + dx * 5, y: y + dy * 5, z: z + dz * 5 }).applyImpulse({ x: existingVelocity.x + dragonDirection.x, y: existingVelocity.y + dragonDirection.y, z: existingVelocity.z + dragonDirection.z })
            dragon.playAnimation('animation.gronckle.fire_ball')
        }
        // Deadly Nadder
        if (event.message == 'nadder') {
            dragon.playAnimation('animation.nadder.blast', { blendOutTime: 4 })
            const callbackId = system.runInterval(() => {
                const existingVelocity = dragon.getVelocity()
                const dragonDirection = dragon.getViewDirection()
                const dragonRotation = dragon.getRotation()
                const { x, y, z } = dragon.getHeadLocation();
                const { x: dx, y: dy, z: dz } = dragon.getViewDirection();
                dragon.dimension.spawnEntity('httyd:fire_blast', { x: x + dx * 10, y: y + dy * 10, z: z + dz * 10 }).addTag(`${dragon.nameTag}`)
                for (const newFireballs of dragon.dimension.getEntities({ type: 'httyd:fire_blast', tags: [`${dragon.nameTag}`], location: { x: x + dx * 5, y: y + dy * 5, z: z + dz * 5 } })) {
                    newFireballs.setRotation(dragonRotation)
                    newFireballs.applyImpulse({ x: existingVelocity.x + dragonDirection.x * 2, y: existingVelocity.y + dragonDirection.y * 2, z: existingVelocity.z + dragonDirection.z * 2 })
                }
            }, 2);
            system.runTimeout(() => {
                dragon.runCommandAsync(`kill @e[tag=${dragon.nameTag},r=7]`)
                system.clearRun(callbackId)
            }, 41)
        }
        // Nightmare
        if (event.message == 'nightmare') {
            dragon.playAnimation('animation.nightmare.breath', { blendOutTime: 4 })
            const callbackId = system.runInterval(() => {
                const existingVelocity = dragon.getVelocity()
                const dragonDirection = dragon.getViewDirection()
                const dragonRotation = dragon.getRotation()
                const { x, y, z } = dragon.getHeadLocation();
                const { x: dx, y: dy, z: dz } = dragon.getViewDirection();
                dragon.dimension.spawnEntity('httyd:fire_blast', { x: x + dx * 10, y: y + dy * 10, z: z + dz * 10 }).addTag(`${dragon.nameTag}`)
                for (const newFireballs of dragon.dimension.getEntities({ type: 'httyd:fire_blast', tags: [`${dragon.nameTag}`], location: { x: x + dx * 5, y: y + dy * 5, z: z + dz * 5 } })) {
                    newFireballs.setRotation(dragonRotation)
                    newFireballs.applyImpulse({ x: existingVelocity.x + dragonDirection.x * 2, y: existingVelocity.y + dragonDirection.y * 2, z: existingVelocity.z + dragonDirection.z * 2 })
                }
            }, 2);
            system.runTimeout(() => {
                dragon.runCommandAsync(`kill @e[tag=${dragon.nameTag},r=7]`)
                system.clearRun(callbackId)
            }, 41)
        }
        //Zippleback
        if (event.message == 'zippleback') {
            const existingVelocity = dragon.getVelocity()
            const dragonDirection = dragon.getViewDirection()
            dragon.dimension.spawnEntity('httyd:zippleback_explosion', { x: x + dx * 5, y: y + dy * 5, z: z + dz * 5 }).applyImpulse({ x: existingVelocity.x + dragonDirection.x, y: existingVelocity.y + dragonDirection.y, z: existingVelocity.z + dragonDirection.z })
        }
        //Night Fury
        if (event.message == 'night_fury') {
            dragon.playAnimation('animation.night_fury.fire_ball')
            const existingVelocity = dragon.getVelocity()
            const dragonDirection = dragon.getViewDirection()
            dragon.dimension.spawnEntity('httyd:plasma_blast', { x: x + dx * 5, y: y + dy * 5, z: z + dz * 5 }).applyImpulse({ x: existingVelocity.x + dragonDirection.x, y: existingVelocity.y + dragonDirection.y, z: existingVelocity.z + dragonDirection.z })
        }
        //Light Fury
        if (event.message == 'light_fury') {
            dragon.playAnimation('animation.night_fury.fire_ball')
            const existingVelocity = dragon.getVelocity()
            const dragonDirection = dragon.getViewDirection()
            dragon.dimension.spawnEntity('httyd:plasma_blast', { x: x + dx * 5, y: y + dy * 5, z: z + dz * 5 }).applyImpulse({ x: existingVelocity.x + dragonDirection.x, y: existingVelocity.y + dragonDirection.y, z: existingVelocity.z + dragonDirection.z })
        }
        //Whispering Death
        if (event.message == 'whispering_death') {
            dragon.playAnimation('animation.whispering_death.breath')
            const existingVelocity = dragon.getVelocity()
            const dragonDirection = dragon.getViewDirection()
            dragon.dimension.spawnEntity('httyd:whispering_death_fireball', { x: x + dx * 5, y: y + dy * 5, z: z + dz * 5 }).applyImpulse({ x: existingVelocity.x + dragonDirection.x, y: existingVelocity.y + dragonDirection.y, z: existingVelocity.z + dragonDirection.z })
        }
        // Timberjack
        if (event.message == 'timberjack') {
            dragon.playAnimation('animation.timberjack.flamethrower', { blendOutTime: 4 })
            const callbackId = system.runInterval(() => {
                const existingVelocity = dragon.getVelocity()
                const dragonDirection = dragon.getViewDirection()
                const dragonRotation = dragon.getRotation()
                const { x, y, z } = dragon.getHeadLocation();
                const { x: dx, y: dy, z: dz } = dragon.getViewDirection();
                dragon.dimension.spawnEntity('httyd:fire_blast', { x: x + dx * 15, y: y + dy * 15, z: z + dz * 15 }).addTag(`${dragon.nameTag}`)
                for (const newFireballs of dragon.dimension.getEntities({ type: 'httyd:fire_blast', tags: [`${dragon.nameTag}`], location: { x: x + dx * 5, y: y + dy * 5, z: z + dz * 5 } })) {
                    newFireballs.setRotation(dragonRotation)
                    newFireballs.applyImpulse({ x: existingVelocity.x + dragonDirection.x * 2, y: existingVelocity.y + dragonDirection.y * 2, z: existingVelocity.z + dragonDirection.z * 2 })
                }
            }, 2);
            system.runTimeout(() => {
                dragon.runCommandAsync(`kill @e[tag=${dragon.nameTag},r=7]`)
                system.clearRun(callbackId)
            }, 41)
        }
        //Sand Wraith
        if (event.message == 'sand_wraith') {
            dragon.playAnimation('animation.sand_wraith.breath')
            const existingVelocity = dragon.getVelocity()
            const dragonDirection = dragon.getViewDirection()
            dragon.dimension.spawnEntity('httyd:sand_blast', { x: x + dx * 5, y: y + dy * 5, z: z + dz * 5 }).applyImpulse({ x: existingVelocity.x + dragonDirection.x, y: existingVelocity.y + dragonDirection.y, z: existingVelocity.z + dragonDirection.z })
        }
        //Flame Whipper
        if (event.message == 'flamewhipper') {
            dragon.playAnimation('animation.flamewhipper.blast')
            const existingVelocity = dragon.getVelocity()
            const dragonDirection = dragon.getViewDirection()
            dragon.dimension.spawnEntity('httyd:flamewhipper_fireball', { x: x + dx * 5, y: y + dy * 5, z: z + dz * 5 }).applyImpulse({ x: existingVelocity.x + dragonDirection.x, y: existingVelocity.y + dragonDirection.y, z: existingVelocity.z + dragonDirection.z })
        }
        //Skrill
        if (event.message == 'skrill') {
            dragon.playAnimation('animation.skrill.blast')
            const existingVelocity = dragon.getVelocity()
            const dragonDirection = dragon.getViewDirection()
            dragon.dimension.spawnEntity('httyd:lightning_blast', { x: x + dx * 5, y: y + dy * 5, z: z + dz * 5 }).applyImpulse({ x: existingVelocity.x + dragonDirection.x, y: existingVelocity.y + dragonDirection.y, z: existingVelocity.z + dragonDirection.z })
        }
        //Snow Wraith
        if (event.message == 'snow_wraith') {
            dragon.playAnimation('animation.snow_wraith.fire')
            const existingVelocity = dragon.getVelocity()
            const dragonDirection = dragon.getViewDirection()
            dragon.dimension.spawnEntity('httyd:ice_blast', { x: x + dx * 5, y: y + dy * 5, z: z + dz * 5 }).applyImpulse({ x: existingVelocity.x + dragonDirection.x, y: existingVelocity.y + dragonDirection.y, z: existingVelocity.z + dragonDirection.z })
        }
        // Hobblegrunt
        if (event.message == 'hobblegrunt') {
            dragon.playAnimation('animation.hobblegrunt.breath', { blendOutTime: 2 })
            const callbackId = system.runInterval(() => {
                const existingVelocity = dragon.getVelocity()
                const dragonDirection = dragon.getViewDirection()
                const dragonRotation = dragon.getRotation()
                const { x, y, z } = dragon.getHeadLocation();
                const { x: dx, y: dy, z: dz } = dragon.getViewDirection();
                dragon.dimension.spawnEntity('httyd:fire_blast', { x: x + dx * 15, y: y + dy * 15, z: z + dz * 15 }).addTag(`${dragon.nameTag}`)
                for (const newFireballs of dragon.dimension.getEntities({ type: 'httyd:fire_blast', tags: [`${dragon.nameTag}`], location: { x: x + dx * 5, y: y + dy * 5, z: z + dz * 5 } })) {
                    newFireballs.setRotation(dragonRotation)
                    newFireballs.applyImpulse({ x: existingVelocity.x + dragonDirection.x * 2, y: existingVelocity.y + dragonDirection.y * 2, z: existingVelocity.z + dragonDirection.z * 2 })
                }
            }, 2);
            system.runTimeout(() => {
                dragon.runCommandAsync(`kill @e[tag=${dragon.nameTag},r=7]`)
                system.clearRun(callbackId)
            }, 18)
        }
        //Rumblehorn
        if (event.message == 'rumblehorn') {
            dragon.playAnimation('animation.rumblehorn.breath')
            const existingVelocity = dragon.getVelocity()
            const dragonDirection = dragon.getViewDirection()
            dragon.dimension.spawnEntity('httyd:fire_blast', { x: x + dx * 5, y: y + dy * 5, z: z + dz * 5 }).applyImpulse({ x: existingVelocity.x + dragonDirection.x, y: existingVelocity.y + dragonDirection.y, z: existingVelocity.z + dragonDirection.z })
        }
    }
    //Thunderdrum
    if (event.id == 'httyd:thunderdrum_roar') {
        const dragonDirection = dragon.getViewDirection()
        dragon.playAnimation('animation.thunderdrum.roaring2')

        system.runTimeout(() => {
            dragon.dimension.spawnParticle('httyd:thunderdrum_boom', { x: x + dx * 5, y: y + dy * 5, z: z + dz * 5 })
            dragon.dimension.getEntities({ excludeFamilies: ['thunderdrum'], maxDistance: 15, location: { x: x + dx * 15, y: y + dy * 15, z: z + dz * 15 }, }).forEach(entity => {
                if (entity.typeId == 'minecraft:player') {
                    entity.applyKnockback(dragonDirection.x, dragonDirection.z, 5, 0.5)
                }
                if (entity.typeId != 'minecraft:player' && !entity.getProperty('httyd:trained')) {
                    entity.applyImpulse({ x: dragonDirection.x * 3, y: 0.5, z: dragonDirection.z * 3 })
                }
            })
        }, 15)
    }
})