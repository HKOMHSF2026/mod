import { world } from '@minecraft/server';


world.beforeEvents.itemUse.subscribe(event => {
    const itemType = event.itemStack.typeId;
    if (itemType == 'httyd:book_of_dragons') {
        event.source.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:book_of_dragons_pg0')
    }
    if (itemType == 'httyd:book_of_dragons_pg0') {
        event.source.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:book_of_dragons_pg1')
    }
    if (itemType == 'httyd:book_of_dragons_pg1') {
        event.source.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:book_of_dragons_pg2')
    }
    if (itemType == 'httyd:book_of_dragons_pg2') {
        event.source.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:book_of_dragons_pg3')
    }
    if (itemType == 'httyd:book_of_dragons_pg3') {
        event.source.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:book_of_dragons_pg4')
    }
    if (itemType == 'httyd:book_of_dragons_pg4') {
        event.source.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:book_of_dragons_pg5')
    }
    if (itemType == 'httyd:book_of_dragons_pg5') {
        event.source.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:book_of_dragons_pg6')
    }
    if (itemType == 'httyd:book_of_dragons_pg6') {
        event.source.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:book_of_dragons_pg7')
    }
    if (itemType == 'httyd:book_of_dragons_pg7') {
        event.source.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:book_of_dragons_pg8')
    }
    if (itemType == 'httyd:book_of_dragons_pg8') {
        event.source.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:book_of_dragons_pg9')
    }
    if (itemType == 'httyd:book_of_dragons_pg9') {
        event.source.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:book_of_dragons_pg10')
    }
    if (itemType == 'httyd:book_of_dragons_pg10') {
        event.source.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:book_of_dragons_pg11')
    }
    if (itemType == 'httyd:book_of_dragons_pg11') {
        event.source.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:book_of_dragons_pg12')
    }
    if (itemType == 'httyd:book_of_dragons_pg12') {
        event.source.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:book_of_dragons_pg13')
    }
    if (itemType == 'httyd:book_of_dragons_pg13') {
        event.source.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:book_of_dragons_pg14')
    }
    if (itemType == 'httyd:book_of_dragons_pg14') {
        event.source.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:book_of_dragons_pg15')
    }
    if (itemType == 'httyd:book_of_dragons_pg15') {
        event.source.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:book_of_dragons_pg16')
    }
    if (itemType == 'httyd:book_of_dragons_pg16') {
        event.source.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:book_of_dragons')
    }
});