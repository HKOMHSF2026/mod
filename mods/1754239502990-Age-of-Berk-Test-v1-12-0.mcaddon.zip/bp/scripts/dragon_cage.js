import { world, system } from '@minecraft/server'

world.beforeEvents.itemUse.subscribe(event => {
    const player = event.source;
    const location = player.getHeadLocation();
    const direction = player.getViewDirection();
    for (const facingEntity of player.dimension.getEntitiesFromRay(location, direction, { type: 'httyd:dragon_cage', maxDistance: 8 })) {
        if (event.itemStack.typeId == 'httyd:watchtower_key' && facingEntity.entity.typeId == 'httyd:dragon_cage' && facingEntity.entity.getProperty('httyd:open') == false) {
            player.runCommandAsync('scriptevent httyd:dragon open_cage')
            player.runCommandAsync('scriptevent achievements:complete_achievement achievements:open_cage')
            player.runCommandAsync('clear @s httyd:watchtower_key 1')
            break
        }
    }
})

system.afterEvents.scriptEventReceive.subscribe(event => {
    const player = event.sourceEntity
    const location = player.getHeadLocation();
    const direction = player.getViewDirection();
    for (const cage of player.dimension.getEntitiesFromRay(location, direction, { type: 'httyd:dragon_cage', maxDistance: 8, ignoreBlockCollision: true })) {
        for (const cagedDragon of cage.entity.dimension.getEntities({ closest: true, tags: ['caged'] })) {
            if (event.message == 'open_cage') {
                if (cage.entity.getProperty('httyd:caged_dragon') == 'gronckle') {
                    player.triggerEvent('httyd:spawn_tamed_gronckle')
                    cagedDragon.remove()
                }
                if (cage.entity.getProperty('httyd:caged_dragon') == 'nadder') {
                    player.triggerEvent('httyd:spawn_tamed_nadder')
                    cagedDragon.remove()
                }
                if (cage.entity.getProperty('httyd:caged_dragon') == 'sand_wraith') {
                    player.triggerEvent('httyd:spawn_tamed_sand_wraith')
                    cagedDragon.remove()
                }
                if (cage.entity.getProperty('httyd:caged_dragon') == 'skrill') {
                    player.triggerEvent('httyd:spawn_tamed_skrill')
                    cagedDragon.remove()
                }
                if (cage.entity.getProperty('httyd:caged_dragon') == 'light_fury') {
                    player.triggerEvent('httyd:spawn_tamed_light_fury')
                    cagedDragon.remove()
                }
                cage.entity.triggerEvent('httyd:open_cage')
                cage.entity.setProperty('httyd:open', true)
                cage.entity.playAnimation('animation.dragon_cage.open_animation')
                system.runTimeout(() => {
                    cage.entity.setProperty('httyd:open_animation_finished', true)
                }, 120)
                break
            }
        }
    }
})

world.afterEvents.entityLoad.subscribe((event) => {
    if (event.entity.typeId == 'httyd:dragon_cage') {
        if (event.entity.getProperty('httyd:cage_type') == 'thin') {
            event.entity.triggerEvent('httyd:thin_cage')
        }
        if (event.entity.getProperty('httyd:cage_type') == 'square') {
            event.entity.triggerEvent('httyd:square_cage')
        }
    }
})

system.afterEvents.scriptEventReceive.subscribe((event) => {
    if (event.sourceEntity.typeId == 'httyd:dragon_cage' && event.message == 'removeBarriers') {
        event.sourceEntity.runCommand('execute at @s run fill ~4 ~4 ~4 ~-4 ~ ~-4 air replace barrier')
        event.sourceEntity.remove()
    }
})