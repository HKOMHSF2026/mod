import { world, EntityComponentTypes, EquipmentSlot, ItemStack } from '@minecraft/server'

world.afterEvents.entitySpawn.subscribe(event => {
    const time = new Date();
    //Ice Gronckle
    if (event.entity.typeId == 'httyd:ice_gronckle') {
        event.entity.dimension.getPlayers({ location: event.entity.location, maxDistance: 7 }).forEach((player) => {
            const equipmentComponent = player.getComponent(EntityComponentTypes.Equippable)
            const mainHandItem = equipmentComponent.getEquipment(EquipmentSlot.Mainhand)
            if (mainHandItem.typeId == 'httyd:ice_gronckle_spawn_egg') return
        })
        //December
        if (time.getMonth() != 11) {
            event.entity.remove()
        }
    }
})