import { world } from "@minecraft/server";


world.beforeEvents.worldInitialize.subscribe(({ itemComponentRegistry }) => {
    itemComponentRegistry.registerCustomComponent('httyd:lit_dragon_blade', {
        onHitEntity(event) {
            event.hitEntity.setOnFire(2)
        },
        onUse(event) {
            event.source.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:dragon_blade')
        },
        onBeforeDurabilityDamage(event) {
            const durability = event.itemStack.getComponent('durability')
            if (durability.maxDurability - durability.damage <= 1) {
                event.attackingEntity.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:dragon_blade')
            }
        },
    })
    itemComponentRegistry.registerCustomComponent('httyd:unlit_dragon_blade', {
        onUse(event) {
            event.source.runCommandAsync('replaceitem entity @s slot.weapon.mainhand 0 httyd:lit_dragon_blade')
        },
    })
    itemComponentRegistry.registerCustomComponent('httyd:settings', {
        onUse(event) {
            const player = event.source;
            player.runCommandAsync('scriptevent httyd:dragon settings')

        },
    })
    itemComponentRegistry.registerCustomComponent('httyd:dragon_shoot_command', {
        onUse(event) {
            const player = event.source
            if (player.hasTag('touch')) {
                player.runCommandAsync('function dragon_shoot_test')
            }
        },
    })
    itemComponentRegistry.registerCustomComponent('httyd:dragon_horn', {
        onUse(event) {
            const player = event.source
            player.dimension.getEntities({ location: player.location, maxDistance: 64 }).forEach(dragon => {
                if (dragon.hasTag(`${player.name}_owned`) && dragon.getProperty('httyd:sitting') == false) {
                    dragon.teleport({ x: player.location.x, y: player.location.y + 2, z: player.location.z })
                }
            })
        },
    })
});