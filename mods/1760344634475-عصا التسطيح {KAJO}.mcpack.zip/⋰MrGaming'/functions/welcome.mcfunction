scoreboard players add @a welcome 1
scoreboard objectives add welcome dummy welcome
execute @a[scores={welcome=110..111}] ~~~ scoreboard objectives add has_gt dummy
execute @a[scores={welcome=110..111}] ~~~ scoreboard players set @s has_gt 0
execute @a[scores={welcome=120}] ~~~ function welcome_asset
execute @a[scores={welcomed=1}] ~~~ scoreboard players set @s welcome 0
scoreboard objectives add mrg dummy
execute @a[scores={mrg=1},tag=!mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~5 ~-1 ~5 ~-5 ~-1 ~-5 grass
execute @a[scores={mrg=1},tag=!mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~5 ~50 ~5 ~-5 ~ ~-5 air
execute @a[scores={mrg=2},tag=!mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~11 ~55 ~12 ~-11 ~ ~-11 air
execute @a[scores={mrg=2},tag=!mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~-1 ~15 ~-15 ~-1 ~-15 grass
execute @a[scores={mrg=4},tag=!mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~11 ~55 ~12 ~-11 ~ ~-11 air
execute @a[scores={mrg=4},tag=!mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~-1 ~15 ~-15 ~-1 ~-15 netherrack
execute @a[scores={mrg=5},tag=!mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~11 ~55 ~12 ~-11 ~ ~-11 air
execute @a[scores={mrg=5},tag=!mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~-1 ~15 ~-15 ~-1 ~-15 end_stone
execute @a[scores={mrg=6},tag=!mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~ ~15 ~-15 ~16 ~-15 air replace stone
execute @a[scores={mrg=6},tag=!mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~ ~15 ~-15 ~16 ~-15 air replace dirt
execute @a[scores={mrg=6},tag=!mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~ ~15 ~-15 ~16 ~-15 air replace gravel
execute @a[scores={mrg=6},tag=!mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~ ~15 ~-15 ~16 ~-15 air replace deepslate
execute @a[scores={mrg=6},tag=!mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~ ~15 ~-15 ~16 ~-15 air replace tuff
execute @a[scores={mrg=6},tag=!mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~ ~15 ~-15 ~16 ~-15 air replace netherrack
execute @a[scores={mrg=6},tag=!mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~ ~15 ~-15 ~16 ~-15 air replace lava
execute @a[scores={mrg=6},tag=!mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~ ~15 ~-15 ~16 ~-15 air replace flowing_lava
execute @a[scores={mrg=6},tag=!mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~ ~15 ~-15 ~16 ~-15 air replace crimson_nylium


execute @a[scores={mrg=1},tag=mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~5 ~-1 ~5 ~-5 ~-1 ~-5 grass
execute @a[scores={mrg=1},tag=mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~5 ~50 ~5 ~-5 ~ ~-5 air destroy
execute @a[scores={mrg=2},tag=mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~11 ~55 ~12 ~-11 ~ ~-11 air destroy
execute @a[scores={mrg=2},tag=mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~-1 ~15 ~-15 ~-1 ~-15 grass
execute @a[scores={mrg=4},tag=mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~11 ~55 ~12 ~-11 ~ ~-11 air destroy
execute @a[scores={mrg=4},tag=mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~-1 ~15 ~-15 ~-1 ~-15 netherrack
execute @a[scores={mrg=5},tag=mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~11 ~55 ~12 ~-11 ~ ~-11 air destroy
execute @a[scores={mrg=5},tag=mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~-1 ~15 ~-15 ~-1 ~-15 end_stone 
execute @a[scores={mrg=6},tag=mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~ ~15 ~-15 ~16 ~-15 air replace stone
execute @a[scores={mrg=6},tag=mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~ ~15 ~-15 ~16 ~-15 air replace dirt
execute @a[scores={mrg=6},tag=mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~ ~15 ~-15 ~16 ~-15 air replace gravel
execute @a[scores={mrg=6},tag=mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~ ~15 ~-15 ~16 ~-15 air replace deepslate
execute @a[scores={mrg=6},tag=mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~ ~15 ~-15 ~16 ~-15 air replace tuff
execute @a[scores={mrg=6},tag=mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~ ~15 ~-15 ~16 ~-15 air replace netherrack
execute @a[scores={mrg=6},tag=mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~ ~15 ~-15 ~16 ~-15 air replace lava
execute @a[scores={mrg=6},tag=mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~ ~15 ~-15 ~16 ~-15 air replace flowing_lava
execute @a[scores={mrg=6},tag=mrgdrop,hasitem={item=mrg:mrgamingisop_menu,location=slot.weapon.mainhand}] ~~~ fill ~15 ~ ~15 ~-15 ~16 ~-15 air replace crimson_nylium
