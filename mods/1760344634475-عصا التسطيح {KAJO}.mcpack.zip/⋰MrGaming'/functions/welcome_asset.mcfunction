execute @a[tag=!mrg] ~~~ playsound random.levelup @s ~~~ 2
execute @a[tag=!mrg] ~~~ title @s subtitle §dmrgamingisop
execute @a[tag=!mrg] ~~~ title @s title You§4Tube
execute @a[tag=!mrg] ~~~ tellraw @a {"rawtext":[{"text":"§¶§6MRG DISCORD ► §ddsc.gg/mrgamingisop §r§¶|| §bCreated by §2mrgamingisop"}]}
tag @a add mrg