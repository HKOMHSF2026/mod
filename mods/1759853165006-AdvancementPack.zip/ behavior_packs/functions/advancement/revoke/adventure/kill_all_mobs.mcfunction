tellraw @s[tag="adv59"] {"rawtext":[{"translate":"chat.advancement.revoke.success","with":{"rawtext":[{"selector":"@s"},{"translate":"advancements.adventure.kill_all_mob.title"}]}}]}
tellraw @s[tag=!"adv59"] {"rawtext":[{"text":"§c"},{"translate":"chat.advancement.revoke.fail","with":{"rawtext":[{"selector":"@s"},{"translate":"advancements.adventure.kill_all_mob.title"}]}}]}

tag @s remove killed_blaze
tag @s remove killed_cave_spider
tag @s remove killed_creeper
tag @s remove killed_drowned
tag @s remove killed_elder_guardian
tag @s remove killed_ender_dragon
tag @s remove killed_enderman
tag @s remove killed_endermite
tag @s remove killed_evocation_illager
tag @s remove killed_ghast
tag @s remove killed_guardian
tag @s remove killed_husk
tag @s remove killed_magma_cube
tag @s remove killed_phantom
tag @s remove killed_piglin
tag @s remove killed_piglin_brute
tag @s remove killed_pillager
tag @s remove killed_ravager
tag @s remove killed_shulker
tag @s remove killed_silverfish
tag @s remove killed_skeleton
tag @s remove killed_slime
tag @s remove killed_stray
tag @s remove killed_spider
tag @s remove killed_vex
tag @s remove killed_vindicator
tag @s remove killed_witch
tag @s remove killed_wither_skeleton
tag @s remove killed_wither
tag @s remove killed_zombie_pigman
tag @s remove killed_zombie_villager
tag @s remove killed_zombie
tag @s remove adv59