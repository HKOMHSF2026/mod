import { world, system} from "@minecraft/server";
import convert from './arabreverse'

const regex = /^[\u0601-\u06FF\u0020-\u0040\u005B-\u0060\u007B-\u007E\u00A1-\u00BF]/;
world.beforeEvents.chatSend.subscribe((eventData) => {
	let srcText = eventData.message;
	const firstChar = srcText.charAt(0);
	if (!regex.test(firstChar)) return;
	eventData.cancel = true;
	const player = eventData.sender;
	let message = `<${player.name}> ${convert(srcText)}`;
	world.sendMessage(message);
});

system.runInterval(() => {
  world.getPlayers().forEach((player) => {
	const block = player.getBlockFromViewDirection({ maxDistance: 6, includeLiquidBlocks: false, includePassableBlocks: true })?.block
	if (!block?.typeId?.includes("sign")) return;
	const signComponent = block.getComponent("minecraft:sign");
	const convertSignText = (side) => {
	const text = signComponent.getText(side);
	if (!text) return;
	const firstChar = text.charAt(0);
	if (!regex.test(firstChar)) return;
	const convertedText = "؀" + convert(text);
	signComponent.setText(convertedText, side);
	};
	convertSignText("Back");
	convertSignText("Front");
  })
});

system.runInterval(() => {
  world.getPlayers().forEach((player) => {
    let {container} = player.getComponent("minecraft:inventory")
    let Item = container.getItem(player.selectedSlot)
	if (!Item) return;
	let itemName = Item.nameTag;
	if (itemName == undefined) return;
	const firstChar = itemName.charAt(0);
	if (!regex.test(firstChar)) return;
	Item.nameTag = "؀" + convert(itemName);
	container.setItem(player.selectedSlot, Item)
  })
});