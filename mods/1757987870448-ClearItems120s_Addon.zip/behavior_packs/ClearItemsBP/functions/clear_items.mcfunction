kill @e[type=item]
say تم حذف جميع الآيتمات المرميّة!
