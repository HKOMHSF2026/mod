import { world, system } from "@minecraft/server";

function Vector(x, y, z) {
    return { x, y, z };
}

class veinMiner {
    constructor(startedBlock) {
        this.blocksQ = 0;
        this.sB = startedBlock.getItemStack().typeId;
        this.dM = startedBlock.dimension;
        this.savedLoc = [];
    }

    mine(player, dLock) {
        this._destroy(dLock);

        for (const loc of this.savedLoc) {
            if (this.dM.getBlock(loc)?.getItemStack().typeId === this.sB && this.blocksQ < 20) {
                this._destroy(loc);
                system.runTimeout(async () => {
                    if (this.blocksQ > 1) {
                        await player.addEffect("hunger", 0, { amplifier: this.blocksQ * 2, showParticles: true });
                    }
                }, 5);
            }
        }
    }

    _destroy(dLock) {
        this.dM.runCommandAsync(`setblock ${dLock.x} ${dLock.y} ${dLock.z} air [] destroy`);
        this.blocksQ++;

        // Generate coordinates for a 3x3x3 area around the block
        for (let x = -1; x <= 1; x++) {
            for (let y = -1; y <= 1; y++) {
                for (let z = -1; z <= 2; z++) {
                    const loc = new Vector(dLock.x + x, dLock.y + y, dLock.z + z);
                    const block = this.dM.getBlock(loc);
                    if (block?.getItemStack()?.typeId === this.sB) {
                        this.savedLoc.push(loc);
                    }
                }
            }
        }
    }
}

world.beforeEvents.playerBreakBlock.subscribe(async data => {
    if (data.player.isSneaking) {
        await new veinMiner(data.block).mine(data.player, data.block.location);
    }
});