import { EnchantmentList,EnchantmentType, MinecraftEnchantmentTypes, Enchantment, Items, EntityQueryOptions, world, BlockLocation, ItemStack, MinecraftItemTypes } from 'mojang-minecraft';
import { Enchantments } from "scripts/classes/Enchantments.js";    
	
const effectCallback = world.events.effectAdd;
const entityCallback = world.events.entityCreate;

//effectCallback.subscribe(effectFunction);
//entityCallback.subscribe(entityCreated);	

world.events.effectAdd.subscribe((effectData)=>{
world.getDimension('overworld').runCommand(`gamerule showtags false`);
if(effectData.effect.displayName == 'Nausea' && effectData.effect.amplifier == 11){
if(effectData.entity.id != "bps:container_entity") return;	
	let backpackEntity = effectData.entity;
	let backpackLocation = backpackEntity.location;
	let backpackDimension = backpackEntity.dimension;
	const entityQ = new EntityQueryOptions;
	let bpOwner = backpackEntity.getTags();
	bpOwner.splice(bpOwner.findIndex((tag)=>tag.includes('slot')),1);
	bpOwner.splice(bpOwner.findIndex((tag)=>tag.includes('bps')),1);
	
	entityQ.location = backpackLocation;
	entityQ.families = ['player'];
	entityQ.closest = 1;
	entityQ.name = bpOwner[0];
	let backpackOwner = Array.from(backpackDimension.getPlayers(entityQ));
	
	let bpInv = effectData.entity.getComponent(`inventory`).container;
	let bpLore = [];
	if(!backpackOwner[0] || !backpackOwner[0].hasTag("bps")) return;
	let idTagIndex = backpackOwner[0].getTags().findIndex((a)=>a.includes('id'));
	let idTag = (backpackOwner[0].getTags()[idTagIndex]).split('.')[0];
	let slotIndexTag = effectData.entity.getTags().findIndex((a)=>a.includes('slot'));
	let slot = parseInt((effectData.entity.getTags())[slotIndexTag].split(':')[1]);
	let bpItem = backpackOwner[0].getComponent('inventory').container.getItem(slot);
	bpLore.push(idTag);
	
		for(let slot=0; slot<bpInv.size; slot++){
			let item = bpInv.getItem(slot);
			if(!item) continue;
			let iNameId = item.id.split(':')[1];
			let iNameSp = item.id.split(':')[0].toLowerCase();
			//check for equipments armor
			if(iNameSp.includes('minecraft') && (iNameId.includes('chestplate') || iNameId.includes('helmet') || iNameId.includes('leggings') || iNameId.includes('boots') || iNameId.includes('elytra') || iNameId.includes('on_a_stick') || iNameId.includes('steel')) || iNameId.includes('backpack')){
				backpackDimension.spawnItem(item,backpackLocation);
				continue;
			}
			//check for equipments non-armor
			if(iNameSp.includes('minecraft') && (iNameId.includes('axolotl_bucket') || iNameId.includes('tropical_fish_bucket') || iNameId.includes('salmon_bucket') || iNameId.includes('pufferfish_bucket') || iNameId.includes('cod_bucket') || iNameId.includes('shulker_box') || iNameId.includes('map') || iNameId.includes('written_book') || iNameId.includes('writable_book') || iNameId.includes('sword') || iNameId.includes('hoe') || iNameId.includes('axe') || iNameId.includes('shovel') || iNameId.includes('bow') || iNameId.includes('shield') || iNameId.includes('shovel') || iNameId.includes('rod') || iNameId.includes('shears') || iNameId.includes('trident'))){
				backpackDimension.spawnItem(item,backpackLocation);
				continue;
			}
			//This is temporary until they add durability component for vanilla equipments
			//Checks for non-vanilla items that has durability
			/*if(item.hasComponent('durability')){ 
				backpackDimension.spawnItem(item,backpackLocation);
				continue;
			}*/
				let itemFormat = `§0${slot};§5` + item.id + ';§0' + item.data + ';§5' + item.amount + '§0';	
				if(item.nameTag){
				itemFormat = itemFormat + ';' + item.nameTag;
				}else{
				itemFormat = itemFormat + ';' + '0';	
				}
				//save enchants				
				let enchants = Enchantments.getEnchants(item);
				for(let enchant of enchants){
					itemFormat = itemFormat + ';' + `${setEnchantNick(enchant)}:${enchant.level}`;
				}
				if(item.hasComponent('durability')){ 
					itemFormat = itemFormat + ';' + `${item.getComponent('durability').damage}`;
				}	
				bpLore.push(itemFormat);
		}
		let newBp = bpItem;
		newBp.setLore(bpLore);
		newBp.nameTag = bpItem.nameTag;
		backpackOwner[0].getComponent('inventory').container.setItem(slot,newBp);
		
		for(let tag of backpackOwner[0].getTags()){
		if(tag.includes('id:')){
		backpackOwner[0].runCommand(`event entity @e[tag="${backpackOwner[0].name}",tag=bps] despawn2`);
		backpackOwner[0].removeTag(tag);
		backpackOwner[0].removeTag(`bps`);
		}
		}
}	
});

world.events.tick.subscribe((eventData)=>{
const players = Array.from(world.getPlayers());	
	for(let player of players){
		const invCompo = player.getComponent('inventory');
		const playerInv = invCompo.container;
		const holdItem = playerInv.getItem(player.selectedSlot);
		const playerTags = player.getTags();
		if(!holdItem || !(holdItem.id.includes('bps:backpack'))){
			if(!(player.hasTag('bps'))){
				continue;			
			}
				try{
				for(let tag of playerTags){
					if(tag.includes('id:')){
						const bpSlot = tag.split('.')[1];
						const oldBp = playerInv.getItem(parseInt(bpSlot));
						let newBp = new ItemStack(Items.get(oldBp.id),1,0);
						newBp.nameTag = oldBp.nameTag;
						newBp.setLore(oldBp.getLore());
						playerInv.setItem(parseInt(bpSlot),newBp);
						player.runCommand(`event entity @e[tag="${player.name}",tag=bps] despawn`);
						player.removeTag(tag);
						player.removeTag(`bps`);
						break;
					}
				}
				}catch(e){
					player.runCommand(`tag @s remove bps`);
					player.runCommand(`event entity @e[tag="${player.name}"] despawn2`);
					let idTag = player.getTags().find((a)=>a.includes('id'));	
					player.removeTag(idTag);
				}
		continue;	
		}
			if(player.hasTag('bps')){			
			let tagIdIndex = player.getTags().findIndex((tag)=>tag.includes('id:'));
				let tagSlot = (player.getTags())[tagIdIndex].split('.')[1];
				let tagId = (player.getTags())[tagIdIndex];
					if((tagSlot != player.selectedSlot)){
						const oldBp = playerInv.getItem(parseInt(tagSlot));
						let newBp = new ItemStack(Items.get(oldBp.id),1,0);
						newBp.nameTag = oldBp.nameTag;
						newBp.setLore(oldBp.getLore());
						playerInv.setItem(parseInt(tagSlot),newBp);
						player.runCommand(`event entity @e[tag="${player.name}",tag=bps] despawn`);
						player.removeTag(tagId);
						player.removeTag(`bps`);
					}
			try{
			//teleport entity bp
			saveItems(player,eventData);
			player.runCommand(`tp @e[tag="${player.name}",tag=bps] ~ ~1.5 ~`);
			}catch(e){
			//player.runCommand(`say ${e}`);
			try{
			player.runCommand(`tag @s remove bps`);
			let idTag = player.getTags().find((a)=>a.includes('id'));	
			player.removeTag(idTag);
			}catch(e){
			
			}
			}
			}else{
			const itemsDb =  holdItem.getLore();
			if(!itemsDb.length) {
				//sets up a new backpack id
				const id = Math.floor(Math.random() * 10000);
				const oldName = holdItem.nameTag;
				player.runCommand(`replaceitem entity @s slot.weapon.mainhand 0 ${holdItem.id} 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}`);
				let newItem = playerInv.getItem(player.selectedSlot);
				newItem.setLore([`id:${id}`]);
				newItem.nameTag = oldName;
				playerInv.setItem(player.selectedSlot,newItem);
				player.addTag(`id:${id}.${player.selectedSlot}`);
				player.addTag(`bps`);		
			}else{
				//already have an id
				const oldName = holdItem.nameTag;
				player.runCommand(`replaceitem entity @s slot.weapon.mainhand 0 ${holdItem.id} 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}`);
				let backpackItemBase = playerInv.getItem(player.selectedSlot);
				backpackItemBase.setLore(itemsDb);
				backpackItemBase.nameTag = oldName;
				playerInv.setItem(player.selectedSlot,backpackItemBase);
				player.addTag(`${itemsDb[0]}.${player.selectedSlot}`);
				player.addTag(`bps`);				
			}
			let bpEntity = player.dimension.spawnEntity('bps:container_entity',player.location);		
			//defines the storage space
			if(holdItem.id == 'bps:backpack_big'){
			bpEntity.triggerEvent('big');	
			}else if(holdItem.id == 'bps:backpack_medium'){
			bpEntity.triggerEvent('medium');	
			}else if(holdItem.id == 'bps:backpack'){
			bpEntity.triggerEvent('small');	
			}else{
			bpEntity.triggerEvent('xl');		
			}
			bpEntity.nameTag = 'Backpack';
			bpEntity.addTag(player.name);
			bpEntity.addTag('bps');
			bpEntity.addTag(`slot:${player.selectedSlot}`);
			let bpInv = bpEntity.getComponent('inventory').container;
			let bpItemLore = holdItem.getLore();
			for(let lore of bpItemLore){
				if(lore.includes('id:')) continue;
				let item = lore.replace(/§0/g,'').replace(/§5/g,'').split(';');
				let newItem = new ItemStack(Items.get(item[1]),parseInt(item[3]),parseInt(item[2]));
				if(item[4] != '0') newItem.nameTag = item[4];

				if(newItem.hasComponent('durability')){
					for(let c=5; c<item.length-1; c++){
					let enchantData = item[c].split(':');
					let enchantType = getEnchantNick(enchantData[0]);
					newItem = Enchantments.setEnchant(newItem,enchantType.id,parseInt(enchantData[1]));
					}	
					try{
					newItem.getComponent('durability').damage = parseInt(item[item.length-1]);
					}catch(e){
					newItem.getComponent('durability').damage = 0;	
					}
				}else{
				for(let c=5; c<item.length; c++){
					let enchantData = item[c].split(':');
					let enchantType = getEnchantNick(enchantData[0]);
					newItem = Enchantments.setEnchant(newItem,enchantType.id,parseInt(enchantData[1]));
				}	
				}
			bpInv.setItem(parseInt(item[0]),newItem);
			}
			
		}
	}
});

world.events.playerLeave.subscribe((eventData)=>{
	try{
	world.getDimension('overworld').runCommand(`event entity @e[tag="${eventData.playerName}"] despawn2`);
	}catch(e){}
	try{
	world.getDimension('the_end').runCommand(`event entity @e[tag="${eventData.playerName}"] despawn2`);
	}catch(e){}
	try{
	world.getDimension('nether').runCommand(`event entity @e[tag="${eventData.playerName}"] despawn2`);
	}catch(e){}
});

//Constantly saves item into lore when backpack is open
function saveItems(player,tick){
if(tick.currentTick%10 != 0) return;
const entityQ = new EntityQueryOptions;
entityQ.tags = ["open",`${player.name}`];
let backpacks = Array.from(player.dimension.getEntities(entityQ));
if(!backpacks[0]) return; 
	let loreDb = [];
	let bpInv = backpacks[0].getComponent('inventory').container;
	let playerInv = player.getComponent('inventory').container;
	let slotIndexTag = backpacks[0].getTags().findIndex((a)=>a.includes('slot'));
	let slot = parseInt((backpacks[0].getTags())[slotIndexTag].split(':')[1]); 
	let bpItem = playerInv.getItem(slot);
	for(let slot=0; slot<bpInv.size; slot++){
		let item = bpInv.getItem(slot);
		if(!item) continue;
		let iNameId = item.id.split(':')[1];
		let iNameSp = item.id.split(':')[0].toLowerCase();
			//check for equipments armor
			if(iNameSp.includes('minecraft') && (iNameId.includes('chestplate') || iNameId.includes('helmet') || iNameId.includes('leggings') || iNameId.includes('boots') || iNameId.includes('elytra') || iNameId.includes('on_a_stick') || iNameId.includes('steel')) || iNameId.includes('backpack')){
				player.dimension.spawnItem(item,player.location);
				backpacks[0].runCommand(`replaceitem entity @s slot.inventory ${slot} air 1 0`);
				continue;
			}
			//check for equipments non-armor
			if(iNameSp.includes('minecraft') && (iNameId.includes('axolotl_bucket') || iNameId.includes('tropical_fish_bucket') || iNameId.includes('salmon_bucket') || iNameId.includes('pufferfish_bucket') || iNameId.includes('cod_bucket') || iNameId.includes('shulker_box') || iNameId.includes('map') || iNameId.includes('written_book') || iNameId.includes('writable_book') || iNameId.includes('sword') || iNameId.includes('hoe') || iNameId.includes('axe') || iNameId.includes('shovel') || iNameId.includes('bow') || iNameId.includes('shield') || iNameId.includes('shovel') || iNameId.includes('rod') || iNameId.includes('shears') || iNameId.includes('trident'))){
				player.dimension.spawnItem(item,player.location);
				backpacks[0].runCommand(`replaceitem entity @s slot.inventory ${slot} air 1 0`);
				continue;
			}
			//This is temporary until they add durability component for vanilla equipments
			//Checks for non-vanilla items that has durability
			/*if(item.hasComponent('durability')){ 
				player.dimension.spawnItem(item,player.location);
				backpacks[0].runCommand(`replaceitem entity @s slot.inventory ${slot} air 1 0`);
				continue;
			}*/
		let itemFormat = `§0${slot};§5` + item.id + ';§0' + item.data + ';§5' + item.amount + '§0';	
			if(item.nameTag){
			itemFormat = itemFormat + ';' + item.nameTag;
			}else{
			itemFormat = itemFormat + ';' + '0';	
			}
			//save enchants
			let enchants = Enchantments.getEnchants(item);
			for(let enchant of enchants){
				itemFormat = itemFormat + ';' + `${setEnchantNick(enchant)}:${enchant.level}`;
			}
			if(item.hasComponent('durability')){ 
					itemFormat = itemFormat + ';' + `${item.getComponent('durability').damage}`;
			}
			loreDb.push(itemFormat);
	}
	loreDb.unshift((bpItem.getLore())[0]);
	bpItem.setLore(loreDb);
	playerInv.setItem(slot,bpItem);
}

function enchant(itemStack){
const eCompo = itemStack.getComponent("minecraft:enchantments");
const enchantments = eCompo.enchantments;
const enchant = enchantments.addEnchantment(new Enchantment(MinecraftEnchantmentTypes.sharpness,1));
eCompo.enchantments = enchantments;
return itemStack;	
}

function setEnchantNick(enchantType){
	let enchantId = enchantType.type.id;
	
	switch(enchantId){
		case 'aquaAffinity':
			return 'aa';
		break;
		
		case 'baneOfArthropods':
			return 'boa';
		break;
		
		case 'binding':
			return 'b';
		break;
		
		case 'blastProtection':
			return 'bp';
		break;
		
		case 'channeling':
			return 'c';
		break;
		
		case 'depthStrider':
			return 'ds';
		break;
		
		case 'efficiency':
			return 'ef';
		break;
		
		case 'featherFalling':
			return 'ff';
		break;
		
		case 'fireAspect':
			return 'fa';
		break;
		
		case 'fireProtection':
			return 'fp';
		break;

		case 'flame':
			return 'f';
		break;	
		
		case 'fortune':
			return 'fo';
		break;
		
		case 'frostWalker':
			return 'fw';
		break;
		
		case 'impailing':
			return 'i';
		break;
		
		case 'infinity':
			return 'in';
		break;
		
		case 'knockback':
			return 'kb';
		break;
		
		case 'looting':
			return 'l';
		break;
		
		case 'loyalty':
			return 'lo';
		break;
		
		case 'luckOfTheSea':
			return 'los';
		break;
		
		case 'lure':
			return 'lu';
		break;
		
		case 'mending':
			return 'm';
		break;
		
		case 'multishot':
			return 'ms';
		break;
		
		case 'piercing':
			return 'pi';
		break;
		
		case 'power':
			return 'po';
		break;
		
		case 'projectileProtection':
			return 'pp';
		break;
		
		case 'protection':
			return 'p';
		break;
		
		case 'punch':
			return 'pu';
		break;
		
		case 'quickCharge':
			return 'qc';
		break;
		
		case 'respiration':
			return 'r';
		break;
		
		case 'riptide':
			return 'rt';
		break;
		
		case 'sharpness':
			return 'sh';
		break;
		
		case 'silkTouch':
			return 'st';
		break;
		
		case 'smite':
			return 'sm';
		break;
		
		case 'soulSpeed':
			return 'ss';
		break;
		
		case 'thorns':
			return 't';
		break;
		
		case 'unbreaking':
			return 'u';
		break;
		
		case 'vanishing':
			return 'v';
		break;
		
		case 'swiftSneak':
			return 'ssk';
		break;
		
		default:
		throw 'Nick Error';
	}
}

function getEnchantNick(eNick){	
	switch(eNick){
				case 'aa':
			return MinecraftEnchantmentTypes.aquaAffinity;
		break;
		
		case 'boa':
			return MinecraftEnchantmentTypes.baneOfArthropods;
		break;
		
		case 'b':
			return MinecraftEnchantmentTypes.binding;
		break;
		
		case 'bp':
			return MinecraftEnchantmentTypes.blastProtection;
		break;
		
		case 'c':
			return MinecraftEnchantmentTypes.channeling;
		break;
		
		case 'ds':
			return MinecraftEnchantmentTypes.depthStrider;
		break;
		
		case 'ef':
			return MinecraftEnchantmentTypes.efficiency;
		break;
		
		case 'ff':
			return MinecraftEnchantmentTypes.featherFalling;
		break;
		
		case 'fa':
			return MinecraftEnchantmentTypes.fireAspect;
		break;
		
		case 'fp':
			return MinecraftEnchantmentTypes.fireProtection;
		break;

		case 'f':
			return MinecraftEnchantmentTypes.flame;
		break;	
		
		case 'fo':
			return MinecraftEnchantmentTypes.fortune;
		break;
		
		case 'fw':
			return MinecraftEnchantmentTypes.frostWalker;
		break;
		
		case 'i':
			return MinecraftEnchantmentTypes.impaling;
		break;
		
		case 'in':
			return MinecraftEnchantmentTypes.infinity;
		break;
		
		case 'kb':
			return MinecraftEnchantmentTypes.knockback;
		break;
		
		case 'l':
			return MinecraftEnchantmentTypes.looting;
		break;
		
		case 'lo':
			return MinecraftEnchantmentTypes.loyalty;
		break;
		
		case 'los':
			return MinecraftEnchantmentTypes.luckOfTheSea;
		break;
		
		case 'lu':
			return MinecraftEnchantmentTypes.lure;
		break;
		
		case 'm':
			return MinecraftEnchantmentTypes.mending;
		break;
		
		case 'ms':
			return MinecraftEnchantmentTypes.multishot;
		break;
		
		case 'pi':
			return MinecraftEnchantmentTypes.piercing;
		break;
		
		case 'po':
			return MinecraftEnchantmentTypes.power;
		break;
		
		case 'pp':
			return MinecraftEnchantmentTypes.projectileProtection;
		break;
		
		case 'p':
			return MinecraftEnchantmentTypes.protection;
		break;
		
		case 'pu':
			return MinecraftEnchantmentTypes.punch;
		break;
		
		case 'qc':
			return MinecraftEnchantmentTypes.quickCharge;
		break;
		
		case 'r':
			return MinecraftEnchantmentTypes.respiration;
		break;
		
		case 'rt':
			return MinecraftEnchantmentTypes.riptide;
		break;
		
		case 'sh':
			return MinecraftEnchantmentTypes.sharpness;
		break;
		
		case 'st':
			return MinecraftEnchantmentTypes.silkTouch;
		break;
		
		case 'sm':
			return MinecraftEnchantmentTypes.smite;
		break;
		
		case 'ss':
			return MinecraftEnchantmentTypes.soulSpeed;
		break;
		
		case 't':
			return MinecraftEnchantmentTypes.thorns;
		break;
		
		case 'u':
			return MinecraftEnchantmentTypes.unbreaking;
		break;
		
		case 'v':
			return MinecraftEnchantmentTypes.vanishing;
		break;
		
		case 'ssk':
			return MinecraftEnchantmentTypes.swiftSneak;
		break;
		
		default:
		throw 'Nick Error';
	}
}

function tagToJson(myJson){
myJson = myJson.replace(/28-/gi,'');	
myJson = myJson.replace(/zx/gi,'"');
myJson = myJson.replace(/xz/gi,',');	
return JSON.parse(myJson);
}

function jsonToTag(newTag){
newTag = JSON.stringify(newTag)
newTag = newTag.replace(/["]/gi,'zx');
newTag = newTag.replace(/[,]/gi,'xz');
newTag = "28-" + newTag;
return newTag;	
}